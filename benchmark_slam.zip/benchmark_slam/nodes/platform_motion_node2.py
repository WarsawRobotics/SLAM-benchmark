#!/usr/bin/env python
# vim:fileencoding=utf-8
import sys
import rospy
import math
import tf
import tf2_ros
import geometry_msgs.msg
import rostopic

# from rospkg import RosPack
from std_msgs.msg import Float32
from std_msgs.msg import Byte

import tests.util.ros_util as ros_util

_NODE_NAME = str('platform_motion_node2')
# orthogonally wrt. camera orientation
_DEFAULT_PLATFORM_ANGLE = 90.0
_DEFAULT_PLATFORM_COMMAND = 6

class LinearDriveControl(object):
  """docstring for LinearDriveControl"""
  def __init__(self):
    self._angle       = ros_util.getNodeParam("~angle",
                                               _DEFAULT_PLATFORM_ANGLE)
    self._command     = ros_util.getNodeParam("~command",
                                               _DEFAULT_PLATFORM_COMMAND)
    self._command_pub = rospy.Publisher("/linearDrive_command", Byte,
                                        latch=True, queue_size=100)
    rospy.Subscriber("/linearDrive_positionPV", Float32, self.positionCallback)

  def run(self):
    rate      = rospy.Rate(30) # ~33hz
    rostopic.publish_message(self._command_pub, Byte, [self._command],
                             once=True)

    while not rospy.is_shutdown():
      rate.sleep()

  def positionCallback(self, pos):
    br = tf2_ros.TransformBroadcaster()
    t = geometry_msgs.msg.TransformStamped()

    t.header.stamp = rospy.get_rostime()
    t.header.frame_id = "world"
    t.child_frame_id = "kinect"
    # pos.data is in meters already
    t.transform.translation.x = (-pos.data *
                                  math.cos(math.radians(self._angle)))
    t.transform.translation.y = (-pos.data *
                                  math.sin(math.radians(self._angle)))
    t.transform.translation.z = 0.0
    q = tf.transformations.quaternion_from_euler(float(0), float(0), float(0))
    t.transform.rotation.x = q[0]
    t.transform.rotation.y = q[1]
    t.transform.rotation.z = q[2]
    t.transform.rotation.w = q[3]

    rospy.loginfo('%f, %f, %f', t.transform.translation.x, 
                  t.transform.translation.y, t.transform.translation.z)
    br.sendTransform(t)

if __name__ == '__main__':
  rospy.init_node(_NODE_NAME, anonymous=True,
                  log_level=rospy.INFO)
                  # log_level=rospy.WARN)
                  # log_level=rospy.DEBUG)
  motion = LinearDriveControl()
  try:
    motion.run()
    # may be thrown by rospy.Rate.sleep() methods when Ctrl-C 
    # is pressed or your Node is otherwise shutdown
  except rospy.ROSInterruptException:
    pass
