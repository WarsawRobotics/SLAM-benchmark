#!/usr/bin/env python
# vim:fileencoding=utf-8
import sys
import os
import errno
import multiprocessing as mp

import rospy
import tf2_ros
import message_filters
from rospkg import RosPack
from geometry_msgs.msg import TransformStamped
from std_msgs.msg import Float32
from nav_msgs.msg import Odometry   
from tf2_msgs.msg import TFMessage

from err_metrics import evaluate_ate
from err_metrics import evaluate_rpe

from tests.util.json_logger import JsonLogger
from tests.util.statistics import TrajectoryErrorStatistics
from tests.util.statistics import TrajectoryErrStatJSONEncoder
import tests.util.ros_util as ros_util

class TrajectorySaver(object):

    def __init__(self, node_name, use_msg_filters=False, evaluate_stats=False):
        self._name = node_name
        # data containers
        self._est_pose_dict = dict()
        self._gndt_pose_dict = dict()

        # functionality parameters
        self._use_msg_filters = use_msg_filters
        self._evaluate_stats = evaluate_stats

        # other variables
        self._bag_filename = str()
        odom_topic = str()

        self._TRAJ_DIR = '/data/trajectories'
        self._STAT_DIR = '/data/stats'

        # to guard against simultaneous writing 
        self._traj_log_file_lock = mp.Lock()

        # ------- load node private parameters -------------------------------
        self._bag_filename = ros_util.getNodeParam('~bag_filename', self._name)
        self._filename_suffix = ros_util.getNodeParam('~filename_suffix',
                                                      self._name)
        speed_topic = ros_util.getNodeParam('~speed_topic', self._name,
                                            'linearDrive_speedSP')
        odom_topic  = ros_util.getNodeParam('~odom_topic', self._name)
        wrapper_ns  = ros_util.getNodeParam('~wrapper_ns', self._name)
        cfg_stat_log_filename = ros_util.getNodeParam('~cfg_stat_log_filename',
                                                      self._name)
        self._LOCAL_DIR = ros_util.getNodeParam('~local_dir', self._name,
                                                str())

        # ------- setup topic subscibers with respect to used policy ---------
        if self._use_msg_filters:
            self._odom_sub = rospy.Subscriber(odom_topic, Odometry, 
                                              self.odomCallback, queue_size=1)
            self._tf_sub = message_filters.Subscriber('tf', TFMessage)
            self._pvel_sub = message_filters.Subscriber(speed_topic, Float32)
            delay_time = 0.1   # [s]
            self._msg_sync = message_filters.ApproximateTimeSynchronizer(
                [self._pvel_sub, self._tf_sub], queue_size=1, slop=delay_time,
                allow_headerless=True)
            self._msg_sync.registerCallback(self.syncMsgReceivedCallback)
        else:
            self._tf_sub = rospy.Subscriber('tf', TFMessage, self.tfCallback, 
                                            queue_size=1)
            self._odom_sub = rospy.Subscriber(odom_topic, Odometry,
                                              self.odomCallback, queue_size=1)
        #  ------- configure absolute paths for storing and loading data -----
        rp = RosPack()
        self._pkg_path = str()
        try:
            self._pkg_path = rp.get_path('benchmark_slam')
        except ResourceNotFound as e:
            print 'Error!: {' + e.message() + '} Can\'t get package path!'
            raw_input('------press any key to exit------')
            sys.exit()

        traj_log_file_path = (self._pkg_path + self._TRAJ_DIR + '/' +
                              self._bag_filename + '/' + self._LOCAL_DIR + 
                              '/' + self._filename_suffix + '_' + 
                              wrapper_ns + '_trajectory.txt')
        cfg_stat_log_file_path = (self._pkg_path + self._STAT_DIR + '/' +
                                  self._bag_filename + '/' + self._LOCAL_DIR +
                                  '/' + cfg_stat_log_filename)
        # ------- make sure necessary directories exists ---------------------
        try:
            os.makedirs(os.path.dirname(traj_log_file_path))
            os.makedirs(os.path.dirname(cfg_stat_log_file_path))
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise

        rospy.logdebug('traj_log_file_path: %s', traj_log_file_path)
        rospy.logdebug('cfg_stat_log_file_path: %s', cfg_stat_log_file_path)

        # ------- open/create log files ---------------------------------------
        self._traj_log_file = open(traj_log_file_path, 'w')
        if self._evaluate_stats:
            self._cfg_log_stat = JsonLogger(cfg_stat_log_file_path)
            self._cfg_log_stat.load()

    def shutdownHook(self):
        """
            This method is responsible for flushing all written data and 
            if needed for calculating choosen error metrics and saving them to 
            log file. 
        """
        rospy.logdebug('"shutdownHook()" called!')
        self._traj_log_file.flush()
        self._traj_log_file.close()

        # Calculate absolute position error statistics (mean, median, stddev, 
        # max, min)
        if self._evaluate_stats:
            if len(self._gndt_pose_dict) > 0 and len(self._est_pose_dict) > 0:
                try:
                    self._cfg_log_stat.addTestStats(self._filename_suffix, 
                                                    self._evaluateStats())
                    self._cfg_log_stat.store()
                except ValueError as e:
                    rospy.logerr(str(e.args[0]))
            else:
                rospy.logwarn('[%s]: Not evaluating error '
                              'metrics due to empty poses collections.', 
                              self._name)

    def syncMsgReceivedCallback(self, pvel_msg, tf_msg):
        ts = self._parseGndtFromTf(tf_msg)
        if ts.header.frame_id == 'world':
            rospy.logdebug('-------- have world -> kinect transform! -------')
            self._logGndtTfExt(ts, pvel_msg)

    def odomCallback(self, msg):
        self._logOdomMsg(msg)

    def tfCallback(self, msg):
        ts = self._parseGndtFromTf(msg)
        if ts.header.frame_id == 'world':
            self._logGndtTf(ts)

    def _logOdomMsg(self, msg):
        sec = msg.header.stamp.secs
        nsec = msg.header.stamp.nsecs
        time = float(sec * 10**9 + nsec) / float(10**9)
        tx = msg.pose.pose.position.x
        ty = msg.pose.pose.position.y
        tz = msg.pose.pose.position.z
        qx = msg.pose.pose.orientation.x
        qy = msg.pose.pose.orientation.y
        qz = msg.pose.pose.orientation.z
        qw = msg.pose.pose.orientation.w

        log_str = ('{0: .4f} {1: .4f} {2: .4f} {3: .4f} {4: .4f}'
                   ' {5: .4f} {6: .4f} {7: .4f}').format(time, tx, ty, tz, qx, 
                    qy, qz, qw)
        rospy.logdebug('[odom]\t ' + log_str)
        self._traj_log_file_lock.acquire()
        self._traj_log_file.write('[odom]\t ' + log_str + '\n')
        self._traj_log_file_lock.release()
        self._est_pose_dict[time] = [tx, ty, tz, qx, qy, qz, qw]

    def _logGndtTf(self, ts):
        gt_sec = ts.header.stamp.secs
        gt_nsec = ts.header.stamp.nsecs
        gt_time = float(gt_sec * 10**9 + gt_nsec) / float(10**9)
        gt_tx = ts.transform.translation.x
        gt_ty = ts.transform.translation.y
        gt_tz = ts.transform.translation.z
        gt_qx = ts.transform.rotation.x
        gt_qy = ts.transform.rotation.y
        gt_qz = ts.transform.rotation.z
        gt_qw = ts.transform.rotation.w

        gndt_log_str = ('{0: .4f} {1: .4f} {2: .4f} {3: .4f} {4: .4f}'
                        ' {5: .4f} {6: .4f} {7: .4f}').format(gt_time, gt_tx, 
                        gt_ty, gt_tz, gt_qx, gt_qy, gt_qz, gt_qw)
        rospy.logdebug('[gndt]\t ' + gndt_log_str)
        self._traj_log_file_lock.acquire()
        self._traj_log_file.write('[gndt]\t ' + gndt_log_str + '\n')
        self._traj_log_file_lock.release()

        self._gndt_pose_dict[gt_time] = ([gt_tx, gt_ty, gt_tz, gt_qx, gt_qy,
                                          gt_qz, gt_qw])

    def _logGndtTfExt(self, ts, pvel):
        """
            Log ground truth transform ((x,y,z) position, (x,y,z,w) rotation) 
            as well as current platform velocity.
        """
        gt_sec = ts.header.stamp.secs
        gt_nsec = ts.header.stamp.nsecs
        gt_time = float(gt_sec * 10**9 + gt_nsec) / float(10**9)
        gt_tx = ts.transform.translation.x
        gt_ty = ts.transform.translation.y
        gt_tz = ts.transform.translation.z
        gt_qx = ts.transform.rotation.x
        gt_qy = ts.transform.rotation.y
        gt_qz = ts.transform.rotation.z
        gt_qw = ts.transform.rotation.w

        gndt_log_str = ('{0: .4f} {1: .4f} {2: .4f} {3: .4f} {4: .4f}'
                        ' {5: .4f} {6: .4f} {7: .4f} {8: .4f}').format(gt_time,
                        gt_tx, gt_ty, gt_tz, gt_qx, gt_qy, gt_qz, gt_qw,
                        pvel.data / 1000.0)
        rospy.logdebug('[gndt]\t ' + gndt_log_str)
        self._traj_log_file_lock.acquire()
        self._traj_log_file.write('[gndt]\t ' + gndt_log_str + '\n')
        self._traj_log_file_lock.release()

        self._gndt_pose_dict[gt_time] = ([gt_tx, gt_ty, gt_tz, gt_qx, gt_qy,
                                          gt_qz, gt_qw, pvel.data / 1000.0])

    def _parseGndtFromTf(self, tf_msg):
        for ts in tf_msg.transforms:
            if ts.header.frame_id == 'world' and ts.child_frame_id == 'kinect':
                return ts
        return TransformStamped()


    def _evaluateStats(self):
        return TrajectoryErrStatJSONEncoder().default(
                    TrajectoryErrorStatistics(self._est_pose_dict,
                                              self._gndt_pose_dict))

#----------------------------------------------------------------------------
# 
#       MAIN
# 
#----------------------------------------------------------------------------
if __name__ == '__main__':
    NODE_NAME = 'trajectory_saver_node'
    rospy.init_node(NODE_NAME, anonymous=True,
                    # log_level=rospy.INFO)
                    log_level=rospy.WARN)
                    # log_level=rospy.DEBUG)
    t_save = TrajectorySaver(NODE_NAME, use_msg_filters=True, 
                             evaluate_stats=True)
    rospy.on_shutdown(t_save.shutdownHook)
    rospy.spin()
