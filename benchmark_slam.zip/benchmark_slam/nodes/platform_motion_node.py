#!/usr/bin/env python
# vim:fileencoding=utf-8
import sys
import rospy
import math
import tf
import tf2_ros
import geometry_msgs.msg

# from rospkg import RosPack
from std_msgs.msg import String
from std_msgs.msg import Float32

_NODE_NAME = str('platform_motion_node')
_PLATFORM_MAX_X = 800

class Motion(object):
  def __init__(self):
    pass

  def getRunTime(self, t_offset):
    """Returns run time expressed in seconds (float) from t_offset"""
    # time - time = duration object!
    td = rospy.get_rostime() - t_offset
    return float(td.secs * 10**9 + td.nsecs) / float(10**9)

  def update(self, t_offset):
    raise NotImplementedError("Have to implement this method in sublcass!")

class SinMotion(Motion):
  def __init__(self):
    super(SinMotion, self).__init__()
    # FIXME: this code should be inside LinearDriveControl class!
    self.pos_offset_    = self.getNodeParam('~pos_offset')   # [m]
    self.a_             = self.getNodeParam('~a')            # [m] 
    self.omega_         = self.getNodeParam('~omega')        # [rad/s]
    self.speed_offset_  = self.getNodeParam('~speed_offset') # [mm/s]
    self._SCALE_FACTOR  = 1.1

  def getNodeParam(self, key):
    # FIXME: this code should be inside LinearDriveControl class!
    if not rospy.has_param(key):
      rospy.logerr('\"%s\" node doesn\'t have \"%s\" parameter!',
          _NODE_NAME, key)
      raw_input('------press any key to exit------')
      sys.exit()
    else:
      rospy.logdebug('Has param: %s!', key)

    try:
      value = rospy.get_param(key)
    except KeyError:
      rospy.logerr('Couldn\'t get \"%s\" parameter value!', key)
      raw_input('------press any key to exit------')
      sys.exit()
    rospy.logdebug('Successfully get param: %s, value: %s', key, str(value));
    return value

  def update(self, t_offset):
    t = super(SinMotion, self).getRunTime(t_offset)
    # offset sinusoid to start from lowest value
    phase_offset = -(math.pi / 2.0)
    x = self.a_ * math.sin(self.omega_ * t + phase_offset)
    v = self.a_ * self.omega_ * math.cos(self.omega_ * t + phase_offset) * \
          self._SCALE_FACTOR

    # scaling factor for position and velocity to obtain desirable 
    # values magnitude (position: ~0-800, velocity: ~0-250)
    k = 10000
    x = (x + self.pos_offset_) * k
    v = math.fabs(v) * k + self.speed_offset_
    return x, v, t 
    
class ConstMotion(Motion):
  def __init__(self, speed, time_interval):
    super(ConstMotion, self).__init__()
    self.s_   = speed
    self.ti_  = time_interval

  def update(self, t_offset):
    t = super(ConstMotion, self).getRunTime(t_offset)
    n_seq = int(t) / self.ti_
    v = self.s_
    if not n_seq & 1:
      x = _PLATFORM_MAX_X
    else:
      x = 0
    return x, v, t

class JerkyMotion(Motion):
  def __init__(self, speed, step, t_delta):
    super(JerkyMotion, self).__init__()
    self.s_   = speed
    self.xd_  = step
    self.td_  = t_delta
    self.prev_t  = rospy.Time()
    self.x_      = 0
    self.start_  = True
    self.moving_ = True

    if self.xd_ > _PLATFORM_MAX_X:
      rospy.logerr('Too large motion step value!')

  def update(self, t_offset):
    if self.start_:
      self.prev_t = t_offset
      self.x_ = self.xd_
      self.start_ = False

    td  = rospy.get_rostime() - self.prev_t
    t   = float(td.secs * 10**9 + td.nsecs) / float(10**9)
    v = self.s_
    if t >= self.td_:
      self.prev_t = rospy.get_rostime()
      nx = self.x_ + self.xd_
      if self.x_ == _PLATFORM_MAX_X or self.x_ == 0:
        self.xd_ *= -1
        self.x_ += self.xd_
      elif nx < 0:
        self.x_ = 0
      elif nx > _PLATFORM_MAX_X:
        self.x_ = _PLATFORM_MAX_X
      else:
        self.x_ += self.xd_

    x = self.x_
    return x, v, t

class NoMotion(Motion):
  def __init__(self):
    super(NoMotion, self).__init__()
    
  def update(self, t_offset):
    t = super(NoMotion, self).getRunTime(t_offset)
    return 0.0, 0.0, t


class LinearDriveControl(object):
  """docstring for LinearDriveControl"""
  def __init__(self, motion_impl):
    self.angle_ = self.getNodeParam("~angle")
    
    self.position_pub_  = rospy.Publisher("/linearDrive_positionSP", Float32, 
        queue_size=10)
    self.speed_pub_     = rospy.Publisher("/linearDrive_speedSP", Float32, 
        queue_size=10)
    rospy.Subscriber("/linearDrive_positionPV", Float32, self.positionCallback)
    
    self.motion_impl_ = motion_impl

  def _publishPosVel(self, pos, vel, t):
    position, speed = Float32(), Float32()
    position.data = pos
    speed.data    = vel
    self.position_pub_.publish(position)
    self.speed_pub_.publish(speed)
    rospy.loginfo('[%f]: %f, %f', t, position.data, speed.data)

  def run(self):
    rate      = rospy.Rate(30) # ~33hz
    t_offset  = rospy.get_rostime()

    while not rospy.is_shutdown():
      x, v, t = self.motion_impl_.update(t_offset)
      self._publishPosVel(x, v, t)
      rate.sleep()

  def positionCallback(self, pos):
    br = tf2_ros.TransformBroadcaster()
    t = geometry_msgs.msg.TransformStamped()

    t.header.stamp = rospy.get_rostime()
    t.header.frame_id = "world"
    t.child_frame_id = "kinect"
    # pos.data is in [mm] so convert it to standard ROS lenght unit - meters
    t.transform.translation.x = -(pos.data / 1000.0) * 
                                  math.cos(math.radians(self.angle_)) # forward
    t.transform.translation.y = -(pos.data / 1000.0) * 
                                  math.sin(math.radians(self.angle_)) # left
    t.transform.translation.z = 0.0                 # up
    q = tf.transformations.quaternion_from_euler(float(0), float(0), float(0))
    t.transform.rotation.x = q[0]
    t.transform.rotation.y = q[1]
    t.transform.rotation.z = q[2]
    t.transform.rotation.w = q[3]

    br.sendTransform(t)

if __name__ == '__main__':
  rospy.init_node(_NODE_NAME, anonymous=True)
  # fast
  # motion = LinearDriveControl(ConstMotion(220, 6))
  # med
  # motion = LinearDriveControl(ConstMotion(150, 8))
  # slow
  # motion = LinearDriveControl(ConstMotion(50, 16))
  motion = LinearDriveControl(SinMotion())
  # motion = LinearDriveControl(JerkyMotion(200, 150, 1.4))
  # motion = LinearDriveControl(NoMotion())
  try:
    motion.run()
    # may be thrown by rospy.Rate.sleep() methods when Ctrl-C 
    # is pressed or your Node is otherwise shutdown
  except rospy.ROSInterruptException:
    pass
