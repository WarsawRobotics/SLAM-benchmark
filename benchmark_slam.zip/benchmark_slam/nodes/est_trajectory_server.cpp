//=============================================================================
// Copyright (c) 2011, Stefan Kohlbrecher, TU Darmstadt
// All rights reserved.

// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the Simulation, Systems Optimization and Robotics
//       group, TU Darmstadt nor the names of its contributors may be used to
//       endorse or promote products derived from this software without
//       specific prior written permission.

// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
// DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
// THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//=============================================================================
// 
// Modified for internal use.
// Adam Rogowiec Invenco. Sp. z o.o. 2017
// 
//=============================================================================


#include <cstdio>
#include <cmath>
#include <signal.h>
#include <functional>
#include <sstream>
#include <fstream>

#include "ros/console.h"
#include "ros/ros.h"

#include "nav_msgs/Path.h"
#include "std_msgs/String.h"

#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Quaternion.h>

#include <nav_msgs/Odometry.h>

#include <tf2_ros/buffer.h>
#include <tf2_ros/transform_listener.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>

std::function<void()> g_shutdown_handler_fun;

void shutdownHandler(int signal)
{
  g_shutdown_handler_fun();
}

class PathContainer
{
 public:
  PathContainer() :
    tf_listener_(tf_buffer_)
  {
    ros::NodeHandle private_nh("~");

    bool track_tf;
    std::string odom_topic;

    track_tf = private_nh.param("target_frame_name", p_target_frame_name_,
                                 std::string());
    track_tf = track_tf & private_nh.param("source_frame_name", 
                                            p_source_frame_name_,
                                            std::string(""));
    private_nh.param("trajectory_update_rate", p_trajectory_update_rate_, 4.0);
    private_nh.param("trajectory_publish_rate", p_trajectory_publish_rate_,
                     0.25);

    private_nh.param("odom_topic", odom_topic, std::string());
    private_nh.param("trajectory_filepath", p_trajectory_filepath_, 
                      std::string());
    private_nh.param("start_end_log_filepath", p_start_end_log_filepath_,
                      std::string());

    if (ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME, 
                                       ros::console::levels::Info))
    {
        ros::console::notifyLoggerLevelsChanged();
    }

    ros::NodeHandle nh;
    
    if (track_tf)
    {
      waitForTf();
      sys_cmd_sub_    = nh.subscribe("syscommand", 1, 
                              &PathContainer::sysCmdCallback, this);
      trajectory_pub_ = nh.advertise<nav_msgs::Path>("trajectory", 1, true);

      last_reset_time_ = ros::Time::now();
      update_trajectory_timer_ = private_nh.createTimer(
          ros::Duration(1.0 / p_trajectory_update_rate_),
          &PathContainer::trajectoryUpdateTimerCallback, this, false);
      publish_trajectory_timer_ = private_nh.createTimer(
          ros::Duration(1.0 / p_trajectory_publish_rate_),
          &PathContainer::publishTrajectoryTimerCallback, this, false);

      pose_source_.pose.orientation.w = 1.0;
      pose_source_.header.frame_id    = p_source_frame_name_;
      tf_trajectory_.header.frame_id     = p_target_frame_name_;
    }

    if (!odom_topic.empty())
    {
      odom_sub_ = nh.subscribe(odom_topic, 1, 
                               &PathContainer::odomCallback, this);
    }
  }

  void waitForTf()
  {
    ros::Time start = ros::Time::now();
    ROS_INFO(
        "Waiting for tf transform data between frames %s and %s to become "
        "available",
        p_target_frame_name_.c_str(), p_source_frame_name_.c_str());

    bool transform_successful = false;

    while (!transform_successful)
    {
      transform_successful = tf_buffer_.canTransform(p_target_frame_name_,
                                  p_source_frame_name_, ros::Time(),
                                  ros::Duration(0.0));
      if (transform_successful)
        break;

      ros::Time now = ros::Time::now();
      if ((now - start).toSec() > 20.0)
      {
        ROS_WARN_ONCE(
            "No transform between frames %s and %s available after %f seconds "
            "of waiting. This warning only prints once.",
            p_target_frame_name_.c_str(), p_source_frame_name_.c_str(),
            (now - start).toSec());
      }

      if (!ros::ok())
        return;
      ros::WallDuration(1.0).sleep();
    }

    ros::Time end = ros::Time::now();
    ROS_INFO("Finished waiting for tf, waited %f seconds",
             (end - start).toSec());
  }

  void sysCmdCallback(const std_msgs::String& sys_cmd)
  {
    if (sys_cmd.data == "reset")
    {
      last_reset_time_ = ros::Time::now();
      tf_trajectory_.poses.clear();
      tf_trajectory_.header.stamp = ros::Time::now();
    }
  }

  void addCurrentTfPoseToTrajectory()
  {
    pose_source_.header.stamp = ros::Time(0);

    geometry_msgs::PoseStamped pose_out;

    tf_buffer_.transform(pose_source_, pose_out, p_target_frame_name_);

    if (tf_trajectory_.poses.size() != 0)
    {
      // Only add pose to trajectory if it's not already stored
      if (pose_out.header.stamp !=
          tf_trajectory_.poses.back().header.stamp)
      {
        tf_trajectory_.poses.push_back(pose_out);
      }
    }
    else
    {
      tf_trajectory_.poses.push_back(pose_out);
    }

    tf_trajectory_.header.stamp = pose_out.header.stamp;
  }

  void trajectoryUpdateTimerCallback(const ros::TimerEvent& event)
  {
    try
    {
      addCurrentTfPoseToTrajectory();
    }
    catch (tf2::TransformException &e)
    {
      ROS_WARN("Trajectory Server: Transform from %s to %s failed: %s \n",
               p_target_frame_name_.c_str(),
               pose_source_.header.frame_id.c_str(), e.what());
    }
  }

  void publishTrajectoryTimerCallback(const ros::TimerEvent& event)
  {
    trajectory_pub_.publish(tf_trajectory_);
  }

  void odomCallback(nav_msgs::Odometry const &msg)
  {
    std::ostringstream ss;
    // serialize message
    ss.precision(6);
    ss << std::fixed << msg.header.stamp.toSec() << " "
       << msg.pose.pose.position.x << " "
       << msg.pose.pose.position.y << " "
       << msg.pose.pose.position.z << " "
       << msg.pose.pose.orientation.x << " "
       << msg.pose.pose.orientation.y << " "
       << msg.pose.pose.orientation.z << " "
       << msg.pose.pose.orientation.w;
    odom_trajectory_.push_back(ss.str());
  }

  void onShutDown()
  {
    geometry_msgs::PoseStamped start = *tf_trajectory_.poses.begin();
    geometry_msgs::PoseStamped end   = *(--tf_trajectory_.poses.end());

    geometry_msgs::Point start_p = start.pose.position;    
    geometry_msgs::Point end_p   = end.pose.position;    

    double dist = std::sqrt((start_p.x-end_p.x)*(start_p.x-end_p.x) + 
                            (start_p.y-end_p.y)*(start_p.y-end_p.y) +
                            (start_p.z-end_p.z)*(start_p.z-end_p.z));

    ROS_INFO_STREAM("Start point: (" << start_p.x << ", " << start_p.y << ", "
                    << start_p.z << ")");
    ROS_INFO_STREAM("End point: (" << end_p.x << ", " << end_p.y << ", "
                    << end_p.z << ")");
    ROS_INFO_STREAM("Start-End error: " << dist);

    if (!p_start_end_log_filepath_.empty())
    {
      std::ofstream dst_file(p_start_end_log_filepath_,
                             std::ios::out | std::ios::app);
      if (dst_file.fail())
      {
        throw std::logic_error("Couldn't open file: " + 
                                p_start_end_log_filepath_);
      }

      dst_file.precision(6);
      dst_file << dist << "\n";
      dst_file.flush();
      dst_file.close();
    }

    if (!p_trajectory_filepath_.empty())
    {
      std::string prefix = p_trajectory_filepath_.substr(0,
                              p_trajectory_filepath_.rfind("."));
      std::string fext = p_trajectory_filepath_.substr(
                            p_trajectory_filepath_.rfind("."));

      if (!tf_trajectory_.poses.empty())
      {
          std::string filepath = prefix + "_tf" + fext;
          std::vector<std::string> data;
          serializeTfTrajectory(data);
          storeTrajectory(filepath, data);
      }

      if (!odom_trajectory_.empty())
      {
          std::string filepath = prefix + "_odom" + fext;
          storeTrajectory(filepath, odom_trajectory_);
      }
    }
    ros::shutdown();
  }

 private:

  void serializeTfTrajectory(std::vector<std::string> &out)
  {
    for (auto p : tf_trajectory_.poses)
    {
      std::ostringstream ss;
      // serialize message
      ss.precision(6);
      ss << std::fixed << p.header.stamp.toSec() << " "
         << p.pose.position.x << " "
         << p.pose.position.y << " "
         << p.pose.position.z << " "
         << p.pose.orientation.x << " "
         << p.pose.orientation.y << " "
         << p.pose.orientation.z << " "
         << p.pose.orientation.w;
      out.push_back(ss.str());
    }
  }

  void storeTrajectory(
    std::string const &filepath,
    std::vector<std::string> const &data)
  {
    std::ofstream dst_file(filepath, std::ios::out | std::ios::app);
    if (dst_file.fail())
    {
      throw std::logic_error("Couldn't open file: " + filepath);
    }

    dst_file.precision(6);
    for (auto p : data)
    {
      dst_file << p << "\n";
    }
    dst_file.flush();
    dst_file.close();
  }

  // parameters
  std::string p_target_frame_name_;
  std::string p_source_frame_name_;
  std::string p_trajectory_filepath_;
  std::string p_start_end_log_filepath_;

  double p_trajectory_update_rate_;
  double p_trajectory_publish_rate_;

  // Zero pose used for transformation to target_frame.
  geometry_msgs::PoseStamped pose_source_;

  ros::Timer update_trajectory_timer_;
  ros::Timer publish_trajectory_timer_;

  ros::Subscriber odom_sub_;
  ros::Subscriber sys_cmd_sub_;
  ros::Publisher trajectory_pub_;

  std::vector<std::string> odom_trajectory_;
  nav_msgs::Path tf_trajectory_;

  tf2_ros::Buffer            tf_buffer_;
  tf2_ros::TransformListener tf_listener_;

  ros::Time last_reset_time_;
  ros::Time last_pose_save_time_;
};

int main(int argc, char** argv)
{
  ros::init(argc, argv, "trajectory_server",
            ros::init_options::NoSigintHandler);

  PathContainer pc;

  g_shutdown_handler_fun = [&pc]() {
    pc.onShutDown();
  };

  // signal handling
  signal(SIGINT, shutdownHandler);

  ros::spin();
  return 0;
}
