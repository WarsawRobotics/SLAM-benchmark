#!/usr/bin/env python
# vim:fileencoding=utf-8
import sys
import rospy
import tf2_ros

from geometry_msgs.msg import TransformStamped


if __name__ == '__main__':

  rospy.init_node('world_transform_listener')
  tf_buffer    = tf2_ros.Buffer()
  tf_listener  = tf2_ros.TransformListener(tf_buffer)

  rate = rospy.Rate(20)
  while not rospy.is_shutdown():
    try:
      ts = tf_buffer.lookup_transform('kinect', 'world', rospy.Time())
    except (tf2_ros.LookupException, tf2_ros.ConnectivityException, 
            tf2_ros.ExtrapolationException):
      rospy.logerr('Error while looking up for /world -> /kinect transform!')
      rate.sleep()
      continue

    gt_sec  = ts.header.stamp.secs
    gt_nsec = ts.header.stamp.nsecs
    gt_tx   = ts.transform.translation.x
    gt_ty   = ts.transform.translation.y
    gt_tz   = ts.transform.translation.z
    gt_qx   = ts.transform.rotation.x
    gt_qy   = ts.transform.rotation.y
    gt_qz   = ts.transform.rotation.z
    gt_qw   = ts.transform.rotation.w

    rospy.loginfo('[gndt]\t %i.%i %.4f %.4f %.4f %.4f %.4f %.4f %.4f',
      gt_sec, gt_nsec, gt_tx, gt_ty, gt_tz, gt_qx, gt_qy, gt_qz, gt_qw)
    rate.sleep()

