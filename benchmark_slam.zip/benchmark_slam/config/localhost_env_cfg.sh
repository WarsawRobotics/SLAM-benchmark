#!/usr/bin/env sh
export ROS_MASTER_URI=http://localhost:11311

. /opt/ros/kinetic/setup.sh
# . ${HOME}/playground/kinect/devel/setup.sh
. ${HOME}/playground/zed_ws/devel/setup.sh
exec "$@"
