#!/usr/bin/env python
# vim:fileencoding=utf-8

import plotting
import numpy as np
import os


x = np.linspace(-np.pi, np.pi, 201)
step = 10*np.pi/180.
y = list()
for i in range(5):
    y.append(list(np.sin(x - i * step)))

plot1 = plotting.StandardPlot()
plot1.filename = 'multiple_sin_plots'
plot1.x_axis_label = 'Angle [rad]'
plot1.y_axis_label = 'sin(x)'
plot1.out_path = os.path.dirname(os.path.abspath(__file__))

layers = list()
layers.append(plotting.StandardLayer(list(x), y[0], '0deg', 
                            plotting.getLightColour('blue'),
                            line_style=plotting.getStyle2('solid')))
layers.append(plotting.StandardLayer(list(x), y[1], '10deg', 
                            plotting.getLightColour('orange'),
                            line_style=plotting.getStyle2('solid')))
layers.append(plotting.StandardLayer(list(x), y[2], '20deg', 
                            plotting.getLightColour('green'),
                            line_style=plotting.getStyle2('solid')))
layers.append(plotting.StandardLayer(list(x), y[3], '30deg', 
                            plotting.getLightColour('red'),
                            line_style=plotting.getStyle2('solid')))
layers.append(plotting.StandardLayer(list(x), y[4], '40deg', 
                            plotting.getLightColour('purple'),
                            line_style=plotting.getStyle2('solid')))

for l in layers:
    plot1.addLayer(l)

plot1.plot()
plot1.savePlot()
plot1.clearPlot()

# ----------------------------------------------------------------------
# 
# ----------------------------------------------------------------------

x = np.linspace(0, np.pi*0.5, 10)
y = list()
for i in range(5):
    y.append([list(np.sin(x) - np.sin(x)*0.1*(i+1)),
              list(np.sin(x) + np.sin(x)*0.1*(i+1)),
              list(np.sin(x) * (1. + 0.05 * i))])

plot2 = plotting.GroupedPlot()
plot2.filename = 'grouped_sin_bar_plots'
plot2.x_axis_label = 'Angle [rad]'
plot2.y_axis_label = 'sin(x)'
plot2.out_path = os.path.dirname(os.path.abspath(__file__))

layers = list()
layers.append(plotting.ErrorBarStatLayer(list(x), y[0], 'x1.0', 
        [plotting.getLightColour('blue'), plotting.getLightColour('grey')] ))
layers.append(plotting.ErrorBarStatLayer(list(x), y[1], 'x1.1', 
        [plotting.getLightColour('orange'), plotting.getLightColour('grey')] ))
layers.append(plotting.ErrorBarStatLayer(list(x), y[2], 'x1.2', 
        [plotting.getLightColour('green'), plotting.getLightColour('grey')] ))
layers.append(plotting.ErrorBarStatLayer(list(x), y[3], 'x1.3', 
        [plotting.getLightColour('red'), plotting.getLightColour('grey')] ))
layers.append(plotting.ErrorBarStatLayer(list(x), y[4], 'x1.4', 
        [plotting.getLightColour('purple'), plotting.getLightColour('grey')] ))

for l in layers:
    plot2.addLayer(l)

plot2.plot()
plot2.savePlot()
plot2.clearPlot()

# ----------------------------------------------------------------------
# 
# ----------------------------------------------------------------------

x_data = np.arange(0.2, 1, 0.2)
base_y = np.array([0.1, 0.2, 0.22, 0.24, 0.245, 0.249, 0.25, 0.251,
                   0.255, 0.26, 0.266, 0.3, 0.5, 0.7, 1.3])

bag1 = list()
bag2 = list()
y_data_samples1 = list()
y_data_samples2 = list()

for i in range(0, len(x_data)):
    noise1 = np.sin(0.2*i)
    noise2 = np.sin(-0.2*i)
    y1 = list(base_y + noise1)
    y2 = list(base_y + noise2)
    bag1.append(y1)
    bag2.append(y2)


mm1 = list([list(np.min(bag1,1)),list(np.max(bag1,1))])
m1 = np.mean(bag1,1)
mean1 = list(m1)
std1 = np.std(bag1,1)
std1_range = list([list(m1-std1),list(m1+std1-(m1-std1))])

mm2 = list([list(np.min(bag2,1)),list(np.max(bag2,1))])
m2 = np.mean(bag2,1)
mean2 = list(m2)
std2 = np.std(bag2,1)
std2_range = list([list(m2-std2),list(m2+std2-(m2-std2))])

plot3 = plotting.GroupedPlot()
plot3.filename = 'grouped_compound_layers'
plot3.x_axis_label = 'Param value'
plot3.y_axis_label = 'err'
plot3.out_path = os.path.dirname(os.path.abspath(__file__))


width = 0.6*plot3.bw
layers = list()
bag1_layer = plotting.CompoundLayer()
bag1_layer.addSubLayer(plotting.VLinesLayer(list(x_data), mm1, 'bag1', 
                        plotting.getLightColour('orange')))
bag1_layer.addSubLayer(plotting.BarLayer(list(x_data), width, std1_range, '', 
                        plotting.getLightColour('blue')))
bag1_layer.addSubLayer(plotting.ScatterLayer(list(x_data), mean1, '', 
                        plotting.getLightColour('red'),
                        plotting.getStyle2('diamond')))
bag1_layer.addSubLayer(plotting.VerticalScatterLayer(list(x_data),
                       bag1, '', plotting.getLightColour('green'),
                       plotting.getStyle2('x')))

bag2_layer = plotting.CompoundLayer()
bag2_layer.addSubLayer(plotting.VLinesLayer(list(x_data), mm2, 'bag2', 
                        plotting.getLightColour('purple')))
bag2_layer.addSubLayer(plotting.BarLayer(list(x_data), width, std2_range, '', 
                        plotting.getLightColour('blue')))
bag2_layer.addSubLayer(plotting.ScatterLayer(list(x_data), mean2, '', 
                        plotting.getLightColour('red'),
                        plotting.getStyle2('diamond')))
bag2_layer.addSubLayer(plotting.VerticalScatterLayer(list(x_data),
                       bag2, '', plotting.getLightColour('green'),
                       plotting.getStyle2('x')))

layers.append(bag1_layer)
layers.append(bag2_layer)

for l in layers:
    plot3.addLayer(l)

plot3.plot()
plot3.savePlot()
plot3.clearPlot()
