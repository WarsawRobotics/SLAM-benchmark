# vim:fileencoding=utf-8

import os
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import math
import numpy as np
import collections
import sys

from tests.util.colored_str import *

"""
    '-'     solid line style
    '--'    dashed line style
    '-.'    dash-dot line style
    ':'     dotted line style
    '.'     point marker
    ','     pixel marker
    'o'     circle marker
    'v'     triangle_down marker
    '^'     triangle_up marker
    '<'     triangle_left marker
    '>'     triangle_right marker
    '1'     tri_down marker
    '2'     tri_up marker
    '3'     tri_left marker
    '4'     tri_right marker
    's'     square marker
    'p'     pentagon marker
    '*'     star marker
    'h'     hexagon1 marker
    'H'     hexagon2 marker
    '+'     plus marker
    'x'     x marker
    'D'     diamond marker
    'd'     thin_diamond marker
    '|'     vline marker
    '_'     hline marker                
"""
_STYLE_DICT = {
    'solid': '-',
    'dashed': '--',
    'dash-dot': '-.',
    'dotted': ':',
    'point': '.',
    'pixel': ',',
    'circle': 'o',
    'triangle_down': 'v',
    'triangle_up': '^',
    'triangle_left': '<',
    'triangle_right': '>',
    'tri_down': '1',
    'tri_up': '2',
    'tri_left': '3',
    'tri_right': '4',
    'square': 's',
    'pentagon': 'p',
    'star': '*',
    'hexagon1': 'h',
    'hexagon2': 'H',
    'plus': '+',
    'x': 'x',
    'diamond': 'D',
    'thin_diamond': 'd',
    'vline': '|',
    'hline': '_',
}

_STD_COLOUR_DICT = {
    'red': 'r',
    'green': 'g',
    'blue': 'b',
    'yellow': 'y',
    'cyan': 'c',
    'magenta': 'm',
    'black': 'k',
}

# -------- nice colours --------
_LIGHT_COLOUR_DICT = {
    'blue'   : '#1f77b4',
    'orange' : '#ff7f0e',
    'green'  : '#2ca02c',
    'red'    : '#d62728',
    'purple' : '#9467bd',
    'brown'  : '#8c564b',
    'pink'   : '#e377c2',
    'grey'   : '#7f7f7f',
    'yelGr'  : '#bcbd22',    
    'turq'   : '#17becf',   #turquoise
}

def getStdColor(c):
    return _STD_COLOUR_DICT.values()[c % len(_STD_COLOUR_DICT.values())]

def getStyle(s):
    return _STYLE_DICT.values()[s % len(_STYLE_DICT.values())]

def getLightColour(key):
    return _LIGHT_COLOUR_DICT[key]

def getLightColour2(c):
    return _LIGHT_COLOUR_DICT.values()[c % len(_LIGHT_COLOUR_DICT.values())]

def getLightColours(n):
    nc = len(_LIGHT_COLOUR_DICT)
    v =_LIGHT_COLOUR_DICT.values()
    return [v[i%nc] for i in range(n)]

def getStyle2(key):
    return _STYLE_DICT[key]

def prePlotConfig():
    # set font with polish characters
    mpl.rc('font', family='Arial')
    fig = plt.figure()
    # fig.set_figwidth(20)
    fig.set_tight_layout(True)
    plt.grid(axis='y', linestyle='--', alpha=0.6)
    plt.grid(axis='x', linestyle='--', alpha=0.6)
    return fig

def postPlotConfig(axis_label, path, filename):
    plt.xlabel(axis_label[0])
    plt.ylabel(axis_label[1])
    print(infoStr('Saving file: ' + path + '/' + filename + '.svg'))
    plt.savefig(path + '/' + filename + '.svg', dpi=100)

def drawStdPlot(x_data, y_data, plot_label, line_style, marker_style,
                plot_colour, axis_label, path, filename):
    """Draw and save standard matplotlib plots.
    
    Arguments:
        x_data {list[list[number]]} -- A list of list of values for 
                                       x-position's.
        y_data {list[list[number]]} -- A list of list of values for 
                                       y-position's (data values).
        plot_label {list[str]} -- List of labels for each plot.
        line_style {list[str]} -- List of line styles for each plot.
        marker_style {list[str]} -- List of marker styles for each plot.
        plot_colour {list[str]} -- List of colours for each plot.
        axis_label {list[str]} -- List of axis labels [x,y].
        path {str} -- Path to folder where to save plot.
        filename {str} -- Plot filename.
    """
    fig = prePlotConfig()

    min_x_val = min(min(x_data))
    max_x_val = max(max(x_data))
    dt_x_val = max_x_val - min_x_val

    min_y_val = min(min(y_data))
    max_y_val = max(max(y_data))
    dt_y_val = max_y_val - min_y_val

    # set X,Y axis range respectively
    plt.axis([min_x_val-dt_x_val*0.1, max_x_val+dt_x_val*0.1,
              min_y_val-dt_y_val*0.1, max_y_val+dt_y_val*0.1])

    # draw plots
    for x, y, s, m, c, l in zip(x_data, y_data, line_style, marker_style,
                               plot_colour, plot_label):
        plt.plot(x, y, linestyle=s, marker=m, color=c, label=l)

    plt.legend()
    postPlotConfig(axis_label, path, filename)
    plt.close(fig)


def drawScatterPlot(x_data, y_data, marker, colour, axis_label, path, 
                    filename):
    """Draw and save matplotlib.pyplot.scatter plot
    
    Arguments:
        x_data {list[number]} -- A list of markers' x positions
        y_data {list[number]} -- A list of markers' y positions
        marker {str} -- String defining marker style.
        colour {str} -- String defining markers' colour.
        axis_label {list[str]} -- List of axis labels [x,y].
        path {str} -- Path to folder where to save plot.
        filename {str} -- Plot filename.
    """
    fig = prePlotConfig()

    plt.scatter(x_data, y_data, alpha=0.85, edgecolors='face', 
                marker=marker, color=colour)
    postPlotConfig(axis_label, path, filename)
    plt.close(fig)

def drawHist2DPlot(x_data, y_data, x_bins, y_bins, axis_label, path, filename):
    """Draw and save matplotlib.pyplot.hist2d plot
    
    Arguments:
        x_data {list[number]} -- A list of x-axis values
        y_data {list[number]} -- A list of y-axis values
        axis_label {list[str]} -- List of axis labels [x,y].
        path {str} -- Path to folder where to save plot.
        filename {str} -- Plot filename.
    """
    fig = prePlotConfig()

    plt.hist2d(x_data, y_data, [x_bins, y_bins], cmap=cm.viridis)
    plt.colorbar()
    postPlotConfig(axis_label, path, filename)
    plt.close(fig)

def drawErrorBarStatPlot(x_data, y_data, plot_colours, plot_label, axis_label,
                         path, filename):
    """Draw a vertical error bars with mean and median markers.
    
    Arguments:
        x_data {list[number]} -- List of x (key) values around which we plot
                                 errorbars.
        y_data {numpy.ndarray} -- 3D matrix of data to plot. 
                                  Z corresponds to separate plots, 
                                  Y is [min, max, mean]
                                  X corresponds to consequtive x_data values,
        plot_colours {list[str]} -- List of colours for respective plots.
        plot_label {list[str]} -- List of labels for respective plots.
        axis_label {list[str]} -- List of axis labels [x,y].
        path {str} -- Path to folder where to save plot.
        filename {str} -- Plot filename.
    """
    fig = prePlotConfig()
    plt.grid(axis='x', b=False)

    if (y_data.shape[0] != len(plot_colours) or
        y_data.shape[0] != len(plot_label)):
        raise ValueError('Incorrect data! x_data, plot_colours and ' +
            'plot_label should have same dimension as y_data.shape[0] ' +
            '(Y-dimension)')

    n_plots = y_data.shape[0]
    n_groups = y_data.shape[2]
    if n_groups != len(x_data):
        raise ValueError('Incorrect data! x_data should have same dimension' +
                ' as y_data.shape[2]')
    bar_width = 0.4
    step = n_plots * 2 + 1
    offset = 0.5
    first_tick = offset + int(n_plots) / 2 * bar_width
    if n_plots & 1:
        first_tick += bar_width * 0.5

    # positions where to place x_data values
    x_ticks = np.arange(first_tick, n_groups*step + first_tick, step)
    plt.xticks(x_ticks, x_data)

    x_pos = np.empty((n_plots, n_groups))

    for n in range(n_plots):
        for g in range(n_groups):
            x_pos[n,g] = offset + n * bar_width + bar_width * 0.5 + g * step

    for n in range(n_plots):
        plt.vlines(x_pos[n,:], y_data[n,0,:], y_data[n,1,:], 
                   colors=plot_colours[n], label=plot_label[n], zorder=1)

    for n in range(n_plots):
        plt.scatter(x_pos[n,:], y_data[n,2,:], alpha=0.95, edgecolors='face',
                 marker='s', color=_LIGHT_COLOUR_DICT['red'], zorder=2)
        plt.scatter(x_pos[n,:], y_data[n,0,:], alpha=0.95, edgecolors='face',
                 marker='_', color=plot_colours[n], zorder=2)
        plt.scatter(x_pos[n,:], y_data[n,1,:], alpha=0.95, edgecolors='face',
                 marker='_', color=plot_colours[n], zorder=2)

    plt.legend()
    postPlotConfig(axis_label, path, filename)
    plt.close(fig)


# ----------------------------------------------------------------------------
# 
#   NEW PLOTTING INTERFACE
# 
# ----------------------------------------------------------------------------

class Plot(object):
    """Base class for plotting data"""
    def __init__(self):
        super(Plot, self).__init__()
        self.filename = str()
        """File name we use to save a plot"""
        self.x_axis_label = str()
        """Plot x-axis label"""
        self.y_axis_label = str()
        """Plot y-axis label"""
        self.out_path = str()
        """Absolute path to directory where to save plot file"""
        self._figure = None
        """This figure hook"""
        self._layers = list()
        """List of layers containing data to plot"""

    def plot(self):
        """Plots all layers data and save a file."""
        self._figure = self._prePlotConfig()
        for layer in self._layers:
            layer.plot()

        self._postPlotConfig()

    def savePlot(self):
        """Store plot to specifed filename inside given out_path directory."""
        print(infoStr('Saving file: ' + self.out_path + '/' + self.filename + 
                      '.png'))
        # bbox_inches='tight' enables the legend to be visible, this times
        # it is taken into consideration when calculating figure size
        plt.savefig(self.out_path + '/' + self.filename + '.png', dpi=100,
                    bbox_inches='tight')

    def _prePlotConfig(self):
        """Set some nicely looking plot configuration.

        Returns
            fig [plt.Figure] -- Figure hook.
        """
        # set font with polish characters
        mpl.rc('font', family='Arial')
        fig = plt.figure()
        fig.clf()
        print(infoStr('Created figure with id: ' + str(fig.number)))
        # fig.set_figwidth(20)
        fig.set_tight_layout(True)
        plt.grid(axis='y', linestyle='--', alpha=0.6)
        plt.grid(axis='x', linestyle='--', alpha=0.6)
        return fig

    def _postPlotConfig(self):
        """Set axis labels and turn on legend."""
        plt.xlabel(self.x_axis_label)
        plt.ylabel(self.y_axis_label)
        plt.legend(loc='lower center', bbox_to_anchor=(0., 0.98, 1.0, 1.0),
                   bbox_transform=self._figure.transFigure, borderpad=0.1,  
                   mode='expand', borderaxespad=0., ncol=3, fancybox=True,
                   handletextpad=-0.5)
        # plt.legend()

    def _setAxisRanges(self, min_x_val, max_x_val, min_y_val, max_y_val):
        """Sets custom axis value ranges.
        
        Add for each axis a 10% of its value range offsets - it looks better.
        
        Arguments:
            min_x_val {number} -- Minimum x axis value.
            max_x_val {number} -- Maximum x axis value.
            min_y_val {number} -- Minimum y axis value.
            max_y_val {number} -- Maximum y axis value.
        """
        # set X,Y axis range respectively
        offset = 0.1
        dt_x_val = max_x_val - min_x_val
        dt_y_val = max_y_val - min_y_val
        plt.axis([min_x_val-dt_x_val*offset, max_x_val+dt_x_val*offset,
                  min_y_val-dt_y_val*offset, max_y_val+dt_y_val*offset])

    def addLayer(self, layer):
        self._layers.append(layer)
     
    def clearLayers(self):
        self._layers = list()

    def clearPlot(self):
        self.filename = str()
        self.x_axis_label = str()
        self.y_axis_label = str()
        self.out_path = str()
        plt.close(self._figure)
        self._figure = None
        self.clearLayers()

# -----------------------------------------------------------------------------

class StandardPlot(Plot):
    """Class for drawing standard plots using pyplt.plot() function.

    Data are plotted as is, there is no preformatting of data layout. The user
    is reponsible for passing correct data. Esspecially this means, if there
    are two layers with identical x-axis and y-axis data, then one layer will 
    hide second.
    """
    def __init__(self):
        super(StandardPlot, self).__init__()
       
    def _getAxisRanges(self):
        l_min_x = [l.getMinXVal() for l in self._layers]
        l_min_y = [l.getMinYVal() for l in self._layers]
        l_max_x = [l.getMaxXVal() for l in self._layers]
        l_max_y = [l.getMaxYVal() for l in self._layers]

        min_x = min(l_min_x)
        min_y = min(l_min_y)
        max_x = max(l_max_x)
        max_y = max(l_max_y)

        return min_x, max_x, min_y, max_y

    def plot(self):
        min_x, max_x, min_y, max_y = self._getAxisRanges()
        self._setAxisRanges(min_x, max_x, min_y, max_y)
        super(StandardPlot, self).plot()

# -----------------------------------------------------------------------------

class GroupedPlot(Plot):
    """Class enabling easier plotting of groups of data with common style.

    There are avaiable two grouping styles:
        uniform -- This means that all layers have same x-axis values, thus we
                   plot as many 'groups' as there are x-axis values and each 
                   group will have as many points/bars/etc as there are layers.
        non-uniform -- Each layer may have different x-axis values. In 
                       consequence there will be as many groups as there are 
                       layers and each group will have as many points/bars/etc.
                       as respective layer x-axis values.
    """
    def __init__(self, offset = 0.5, uniform = True, bar_width = 0.4,
                 group_step = 1, x_ticks_labels=list(),
                 x_ticks_rot='horizontal'):
        super(GroupedPlot, self).__init__()
        self.uniform = uniform
        self.offset = offset
        self.step = 0.0
        self.gs = group_step
        self.bw = bar_width
        self._x_ticks = list()
        self._x_ticks_labels = x_ticks_labels
        self._x_ticks_rotation = x_ticks_rot

    def plot(self):
        has_data = (self._distributeDataUniform() if self.uniform 
                            else self._distributeDataMixed())
        if has_data:
            super(GroupedPlot, self).plot()
            if self.uniform:
                self._updateXTicks(self._x_ticks, self._x_ticks_labels,
                        rotation=self._x_ticks_rotation)
            # make space for rotated x_ticks
            if isinstance(self._x_ticks_rotation, int):
                plt.subplots_adjust(bottom=0.15)
        else:
            print(infoStr('There is no data to plot!'))

    def _distributeDataUniform(self):
        n_plots = len(self._layers)
        if n_plots == 0:
            return False

        self.step = n_plots * self.bw + self.gs
        # assume all layers has same length x_data
        n_groups = self._layers[0].XDataSize()
        first_tick = self.offset + n_plots * 0.5 * self.bw
        x_ticks = np.arange(first_tick, n_groups * self.step + first_tick,
                             self.step)
        if len(x_ticks) != n_groups:
            print(errorStr('x_ticks length must be equal to n_groups! ' +
                            str(len(x_ticks)) + ' != ' + str(n_groups)))
            print x_ticks
            return False

        self._x_ticks = x_ticks
        if len(self._x_ticks_labels) == 0:
            self._x_ticks_labels = self._layers[0].getXData()
        
        for i,layer in enumerate(self._layers):
            first = self.offset + i * self.bw + self.bw * 0.5
            last = first + layer.XDataSize() * self.step
            x_pos, step = np.linspace(first, last, num=n_groups,
                endpoint=False, retstep=True)
            if not np.isclose([step],[self.step])[0]:
                print(errorStr('Error in interpolating new x_data values! ' +
                       'step:' + str(step) + '!= self.step:' + str(self.step)))
            layer.updateXData(x_pos)
        return True

    def _distributeDataMixed(self):
        x_ticks = list()
        n_groups = len(self._layers)
        cur_start = self.offset + 0.5 * self.bw

        for i,layer in enumerate(self._layers):
            start = cur_start
            n_points = layer.XDataSize()
            end = start + n_points * self.bw
            x_pos = np.arange(start + 0.5 * self.bw, end + self.bw, self.bw)
            layer.updateXData(x_pos)
            x_ticks.append((start+end) * 0.5)
            cur_start = end + self.step
        return True

    def _updateXTicks(self, x_ticks, x_data, rotation):
        print(infoStr('Updating x_ticks. x_ticks: '))
        print x_ticks
        print(infoStr('ticks labels: '))
        print x_data
        plt.xticks(x_ticks, x_data, rotation=rotation)

# -----------------------------------------------------------------------------

class LayerInterface(object):
    """Class defining Layer interface"""
    def __init__(self):
        pass       

    def plot(self):
        raise NotImplementedError()

    def XDataSize(self):
        raise NotImplementedError()

    def getXData(self):
        raise NotImplementedError()

    def getYData(self):
        raise NotImplementedError()

    def getMinXVal(self):
        raise NotImplementedError()

    def getMaxXVal(self):
        raise NotImplementedError()

    def getMinYVal(self):
        raise NotImplementedError()

    def getMaxYVal(self):
        raise NotImplementedError()

    def updateXData(self, x_pos):
        raise NotImplementedError()


# -----------------------------------------------------------------------------


class SimpleLayer(LayerInterface):
    """Describes set of data, plotted with one command"""
    def __init__(self, x_data, y_data, label, colour, marker_style=str(),
                 line_style=str()):
        super(SimpleLayer, self).__init__()
        self.x_data = x_data
        self.y_data = y_data
        self.label = label
        self.colour = colour
        self.marker_style = marker_style
        self.line_style = line_style
        self.x_ticks = list()

    def updateXData(self, x_pos):
        if len(self.x_data) != len(x_pos):
            print(errorStr('ERROR! Length of x_pos and x_data must be equal!' +
                    'len(x_data): ' + str(len(self.x_data)) + 
                    ' != len(x_pos): ' + str(len(x_pos))))
            raise ValueError()
        self.x_data = list(x_pos)

    def XDataSize(self):
        return len(self.x_data)

    def getXData(self):
        return self.x_data

    def getYData(self):
        return self.y_data

    def getMinXVal(self):
        return min(self.x_data)        

    def getMaxXVal(self):
        return max(self.x_data)

    def getMinYVal(self):
        return min(self.y_data)        

    def getMaxYVal(self):
        return max(self.y_data)


# -----------------------------------------------------------------------------

class StandardLayer(SimpleLayer):
    """Class representing layer plotted with standard pyplot.plot() command."""
    def __init__(self, x_data, y_data, label, colour, marker_style=str(),
                 line_style = str()):
        super(StandardLayer, self).__init__(x_data, y_data, label, colour,
                                                marker_style, line_style)
   
    def plot(self, zorder=2):
        plt.plot(self.x_data, self.y_data, linestyle=self.line_style,
                 marker=self.marker_style, color=self.colour, label=self.label,
                 zorder=zorder)

# -----------------------------------------------------------------------------

class VLinesLayer(SimpleLayer):
    """Class representing layer plotted with pyplot.vlines() function"""
    def __init__(self, x_data, y_data, label, colour, line_style='solid',
                 linewidths=2):
        super(VLinesLayer, self).__init__(x_data, y_data, label, colour,
                                              line_style=line_style)
        self.linewidth = linewidths

    def plot(self, zorder=2):
        plt.vlines(self.x_data, self.y_data[0], self.y_data[1], 
                   colors=self.colour, label=self.label, 
                   linestyles=self.line_style, linewidths=self.linewidth,
                   zorder=zorder)

# -----------------------------------------------------------------------------

class HLinesLayer(SimpleLayer):
    """Class representing layer plotted with pyplot.hlines() function"""
    def __init__(self, x_data, y_data, label, colour, line_style='solid',
                 linewidths=2):
        super(HLinesLayer, self).__init__(x_data, y_data, label, colour,
                                              line_style=line_style)
        self.linewidth = linewidths

    def plot(self, zorder=2):
        plt.vlines(self.x_data[0], self.x_data[1], self.y_data, 
                   colors=self.colour, label=self.label,
                   linestyles=self.line_style, linewidths=self.linewidth,
                   zorder=zorder)

# -----------------------------------------------------------------------------

class ScatterLayer(SimpleLayer):
    """Class representing a layer plotted with pyplot.scatter() function"""
    def __init__(self, x_data, y_data, label, colour, marker_style=str(),
                 line_style = str()):
        super(ScatterLayer, self).__init__(x_data, y_data, label, colour,
                                                marker_style, line_style)

    def plot(self, zorder=2):
        plt.scatter(self.x_data, self.y_data, alpha=0.95, edgecolors='face',
                    label=self.label, marker=self.marker_style, 
                    color=self.colour)

# -----------------------------------------------------------------------------

class VerticalScatterLayer(SimpleLayer):
    """Class representing a layer plotted with pyplot.scatter() function"""
    def __init__(self, x_data, y_data, label, colour, marker_style=str(),
                 line_style = str()):
        """ Constructor
            Arguments:

            x_data {list}       -- X-axis data positions, without repetition.
            y_data {list{list}} -- Y-axis data. One list for each corresponding
                                   (in order) value of x_data.
        """
        super(VerticalScatterLayer, self).__init__(x_data, y_data, label,
                                                   colour,marker_style,
                                                   line_style)

    def getYData(self):
        return self._getFlatYData()

    def getMinYVal(self):
        return min(self._getFlatYData())

    def getMaxYVal(self):
        return max(self._getFlatYData())

    def plot(self, zorder=2):
        nx = self.XDataSize()
        flat_x_data = list()
        for i in range(nx):
            flat_x_data.extend(
                        [self.x_data[i] for j in range(len(self.y_data[i]))])

        plt.scatter(flat_x_data, self._getFlatYData(), alpha=0.95,
                    edgecolors='face', marker=self.marker_style,
                    label=self.label, color=self.colour, zorder=zorder)

    def _getFlatYData(self):
        return reduce(lambda x,y:x+y, [v for v in self.y_data], list())


# -----------------------------------------------------------------------------

class BarLayer(SimpleLayer):
    """Class representing a layer plotted with pyplot.scatter() function"""
    def __init__(self, x_data, width, y_data, label, colour):
        super(BarLayer, self).__init__(x_data, y_data, label, colour)

        self.width = width

    def plot(self, zorder=2):
        plt.bar(self.x_data, self.y_data[1], self.width, self.y_data[0],
                edgecolor=self.colour, facecolor='none', color=None,
                linestyle='solid', zorder=zorder, label=self.label)

# -----------------------------------------------------------------------------

class ErrorBarStatLayer(SimpleLayer):
    """Class representing layer with error bars for statistical data.

    Each bar is represented by three values: (min_y, max_y, mean_y)
    """
    def __init__(self,  x_data, y_data, label, colour, marker_style=str(),
                 line_style=str()):
        """Constructor
        
        Arguments:
            x_data {list} -- x values.
            y_data {list[list]} -- y_data[0] - list of min y values,
                                   y_data[1] - list of max y values,
                                   y_data[2] - list of mean y values,

            label {str} -- [description]
            colour {list} -- colour[0] a string representation for bar colour,
                             colour[1] a string representation for mean value 
                             marker colour,
        
        Keyword Arguments:
            marker_style {str} -- Marker string representation for mean values
                                  (default: {str()})
            line_style {str} --  (default: {str()})
        """
        marker_style = ['s','_']
        super(ErrorBarStatLayer, self).__init__(x_data, y_data, label,
                                             colour, marker_style, line_style)

    def plot(self):
        plt.vlines(self.x_data, self.y_data[0], self.y_data[1], 
                   colors=self.colour[0], label=self.label, zorder=1)
        plt.scatter(self.x_data, self.y_data[2], alpha=0.95, edgecolors='face',
                    marker=self.marker_style[0], color=self.colour[1],
                    zorder=2)
        plt.scatter(self.x_data, self.y_data[0], alpha=0.95, edgecolors='face',
                    marker=self.marker_style[1], color=self.colour[0], 
                    zorder=2)
        plt.scatter(self.x_data, self.y_data[1], alpha=0.95, edgecolors='face',
                    marker=self.marker_style[1], color=self.colour[0], 
                    zorder=2)

# -----------------------------------------------------------------------------

class CompoundLayer(LayerInterface):
    """Class representing layer consisting of multiple sublayers
    
    This class aggregates many single layers (assume that single layer 
    represents plot with one type of function). 
    """
    def __init__(self):
        super(CompoundLayer, self).__init__()
        self._sub_layers = list()

    def addSubLayer(self, layer):
        self._sub_layers.append(layer);

    # -------- LayerInterface -------------
    def plot(self):
        for i, layer in enumerate(self._sub_layers):
            layer.plot(i+1)

    def XDataSize(self):
        return len(self.getXData())

    def getXData(self):
        all_x_data = list(collections.OrderedDict.fromkeys(reduce(
                        lambda x,y: x + y, 
                        [s.getXData() for s in self._sub_layers], list())))
        all_x_data.sort()
        return all_x_data

    def getYData(self):
        all_y_data = list(collections.OrderedDict.fromkeys(reduce(
                        lambda x,y: x + y, 
                        [s.getYData() for s in self._sub_layers], list())))
        all_y_data.sort()
        return all_y_data

    def getMinXVal(self):
        return reduce(lambda x,y: min(x,y), 
                      [s.getMinXVal() for s in self._sub_layers],
                       sys.float_info.max)

    def getMaxXVal(self):
        return reduce(lambda x,y: max(x,y), 
                      [s.getMaxXVal() for s in self._sub_layers],
                       sys.float_info.min)

    def getMinYVal(self):
        return reduce(lambda x,y: min(x,y), 
                      [s.getMinYVal() for s in self._sub_layers],
                       sys.float_info.max)

    def getMaxYVal(self):
        return reduce(lambda x,y: max(x,y), 
                      [s.getMaxYVal() for s in self._sub_layers],
                       sys.float_info.min)

    def updateXData(self, x_pos):
        for s in self._sub_layers:
            s.updateXData(x_pos)