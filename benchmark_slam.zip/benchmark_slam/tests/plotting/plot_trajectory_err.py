#!/usr/bin/env python
# vim:fileencoding=utf-8

import plotting
import os

y = [
    0.336012,
    0.237176,
    0.271909,
    0.246511,
    0.289662,
    0.270873,
    0.270855,
    0.21809,
    0.211556,
    0.218069,
    0.270261,
]
x = range(len(y))

plot1 = plotting.StandardPlot()
plot1.filename = 'realsense_sdk_slam_start_end_err'
plot1.x_axis_label = u'Nr próby'
plot1.y_axis_label = u'Błąd [m]'
plot1.out_path = os.path.dirname(os.path.abspath(__file__))

layers = list()
layers.append(plotting.StandardPlotLayer(list(x), y, '', 
                        plotting.getLightColour('blue'),
                        line_style=plotting.getStyle2('solid')))

for l in layers:
    plot1.addLayer(l)

plot1.plot()