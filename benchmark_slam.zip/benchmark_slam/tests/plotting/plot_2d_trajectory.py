#!/usr/bin/env python
# vim:fileencoding=utf-8

import plotting
import os
import argparse
import re

from tests.util.colored_str import *

def plot2D(data, dir, filename):
    p = plotting.StandardPlot()
    p.filename = filename
    p.x_axis_label = u'Współrzędna X'
    p.y_axis_label = u'Współrzędna Y'
    p.out_path = dir

    time = [float(v[0]) for v in data]
    x_data = [float(v[1]) for v in data]
    y_data = [float(v[2]) for v in data]
    z_data = [float(v[3]) for v in data]

    p.addLayer(plotting.StandardLayer(x_data, y_data, 'Pozycja kamery 2D',
                            plotting.getLightColour('blue'),
                            line_style=plotting.getStyle2('solid')))
    p.plot()
    p.savePlot()
    p.clearPlot()

    # p.filename = filename + '_x'
    # p.x_axis_label = u'Czas [s]'
    # p.y_axis_label = u'Współrzędna X'
    # p.out_path = dir

    # p.addLayer(plotting.StandardLayer(time, x_data, u'Współrzędna x kamery 2D',
    #                         plotting.getLightColour('blue'),
    #                         line_style=plotting.getStyle2('solid')))
    # p.plot()
    # p.savePlot()
    # p.clearPlot()

    # p.filename = filename + '_y'
    # p.x_axis_label = u'Czas [s]'
    # p.y_axis_label = u'Współrzędna Y'
    # p.out_path = dir

    # p.addLayer(plotting.StandardLayer(time, y_data, u'Współrzędna y kamery 2D',
    #                         plotting.getLightColour('blue'),
    #                         line_style=plotting.getStyle2('solid')))
    # p.plot()
    # p.savePlot()
    # p.clearPlot()

    import matplotlib
    import matplotlib.pyplot as plt

    matplotlib.rc('font', family='Arial')
    plt.close('all')
    f, (ax1, ax2, ax3) = plt.subplots(3, sharex=True, figsize=(6,6))
    f.set_tight_layout(True)

    ax1.plot(time, x_data, linestyle=plotting.getStyle2('solid'),
                 color=plotting.getLightColour('blue'), 
                 label=u'Współrzędna x kamery 2D')
    ax1.set_ylabel(u'Pozycja X [m]')
    ax1.legend()
    ax1.grid(axis='y', linestyle='--', alpha=0.6)
    ax1.grid(axis='x', linestyle='--', alpha=0.6)
    ax2.plot(time, y_data, linestyle=plotting.getStyle2('solid'),
                 color=plotting.getLightColour('blue'), 
                 label=u'Współrzędna y kamery 2D')
    ax2.legend()
    ax2.grid(axis='y', linestyle='--', alpha=0.6)
    ax2.grid(axis='x', linestyle='--', alpha=0.6)
    ax2.set_ylabel(u'Pozycja Y [m]')
    ax3.plot(time, z_data, linestyle=plotting.getStyle2('solid'),
                 color=plotting.getLightColour('blue'), 
                 label=u'Współrzędna z kamery 2D')
    ax3.legend()
    ax3.grid(axis='y', linestyle='--', alpha=0.6)
    ax3.grid(axis='x', linestyle='--', alpha=0.6)
    ax3.set_ylabel(u'Pozycja Z [m]')
    ax3.set_xlabel(u'Czas [s]')
    print(infoStr('Saving file: ' + dir + '/' + filename + '_xyz' + '.png'))
    plt.savefig(dir + '/' + filename + '_xyz' + '.png', dpi=100,
                    bbox_inches='tight')



if __name__ == '__main__':
    # parse command line
    parser = argparse.ArgumentParser(description=''''Plot 2d trajectory 
      X-Y.''')
    parser.add_argument('--t', help='Path to trajectory file.')
    parser.add_argument('--n', help='Outupt filename.')
    parser.add_argument('--o', help='Path to output folder.')
    args = parser.parse_args()

    odom_rexp = re.compile('^\d+\.\d+\s+(\-?\d+\.\d+\s+){7}$')

    xy_traj = list()
    has_start = False
    start = 0.0

    with open(args.t, 'r') as f:
        for line in f:
            lval = line.split()
            if not has_start:
                start = float(lval[0])
                has_start = True

            if odom_rexp.match(line) is not None:
                xy_traj.append((float(lval[0])-start, float(lval[1]), 
                                float(lval[2]), float(lval[3])))
            else:
                print warningStr('ERROR: Invalid trajectory file entry!')
                print warningStr('line: ' + line)
                continue

    plot2D(xy_traj, args.o, args.n)
