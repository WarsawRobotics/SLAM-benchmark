# vim:fileencoding=utf-8


class Pose(object):
    """3D (6-DOF) pose in specified time point

    Represents 3D position (x,y,z), and 3D rotation as a quaternion 
    (qx,qy,qz,qw) in specified time point (as floating point seconds).
    """

    def __init__(self, x, y, z, qx, qy, qz, qw, time):
        super(Pose, self).__init__()
        self.x = x
        self.y = y
        self.z = z
        self.qx = qx
        self.qy = qy
        self.qz = qz
        self.qw = qw
        self.time = time

    @classmethod
    def fromList(cls, pose_list):
        """Creates Pose object form list of values
        
        Arguments:
            pose_list {list} -- List containing (x,y,z,qx,qy,qz,qw,time)
        
        Returns:
            [Pose] -- Pose object
        """
        if len(pose_list) != 8:
            raise ValueError('ERROR: Input list have inccorect number ' + 
                             'of values!')
        return cls(*pose_list)

    @classmethod
    def fromPoseTime(cls, pose_list, time):
        """Creates Pose objcet from pose list and time point.
        
        Arguments:
            pose_list {list} -- List containing (x,y,z,qx,qy,qz,qw)
            time {float} -- Time point as seconds.
        """
        if len(pose_list) != 7:
            raise ValueError('ERROR: Input list have inccorect number ' + 
                             'of values!')
        return cls(*(pose_list + [time]))

    def toList(self):
        return [self.x, self.y, self.z, self.qx, self.qy, self.qz, self.qw,
                self.time]

    def position(self):
        """Return 3D point position
        
        Returns:
            [list] -- List of x,y,z point coordinates.
        """
        return [self.x, self.y, self.z]

    def orientation(self):
        """Returns 3D point orientation as a quaternion.
        
        Returns:
            [list] -- List of quaternion values.
        """
        return (self.qx, self.qy, self.qz, self.qw)
    
    # -----------------------------------------------------------------
    #       COMPARISON FUNCTIONS
    # -----------------------------------------------------------------

    def cmpTimestamps(self, rhs):
        if self.time == rhs.time:
            return 0
        elif self.time > rhs.time:
            return 1
        else:
            return -1
