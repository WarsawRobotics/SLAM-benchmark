# vim:fileencoding=utf-8

import os
import re
import numpy

import tests.util.utilities as utils

from tests.util.colored_str import *
from tests.test_results.pose import Pose


#--------------------------------------------------------------------------
#         SINGLE TEST RESULTS
#--------------------------------------------------------------------------

class TestResult(object):
    """A class representing single test configuration & results"""

    def __init__(self, test_id, trajectory_file_path, cfg_stat,
                 time_offset=0.0, time_window=0.35):
        """Constructor

        Arguments:
            test_id {str}              -- 'timestamp_pid[_pid]'
            trajectory_file_path {str} -- Absolute path to trajectory file
            cfg_stat {tuple}           -- A tuple consisting of (config=dict, 
                                          stat=dict)

        Keyword Arguments:
            time_offset {number} -- Time offset for estimated pose trajectory
                                    (default: {0.0})
            time_window {number} -- Time window used to search for
                                    corresponding ground truth and estimeted
                                    poses (default: {0.35})
        """

        super(TestResult, self).__init__()
        self._test_id = test_id
        """Test identificator in format: timestamp_pid[_pid]"""
        self._time_offset = time_offset
        """Optional time offset for matching gndt and est trajectory entries.
        """
        self._time_window = time_window
        """Time interval used to search for relevant trajectory entries."""
        self._config = cfg_stat[0]
        """This dictionary may be empty if derived class doesn't supply any 
        specific configurations."""
        self._stat = cfg_stat[1]
        """Dictionary containing calculated error statistic metrics.
        Structure: keyword: statistic metric (eg. 'max' etc.), value: {list}
        """
        gt, et, gt_full, et_full = self._getTrajectories(trajectory_file_path)
        self._gndt_trajectory = gt
        """Dictionary containing recorded ground truth trajectory.
        Entries are matched with data inside _est_trajectory by keywords.
        Structure: keyword: 'timestamp' (ROS standard: seconds from UNIX
        epoch),
        value: {list} -- x,y,z,qx,qw,qz,qw -- 3D translation and orientation.
        """
        self._est_trajectory = et
        """Dictionary containing recorded estimated trajectory.
        Entries are matched with data inside _gndt_trajectory by keywords.
        Structure: keyword: 'timestamp' (ROS standard: seconds from UNIX 
        epoch),
        value: {list} -- x,y,z,qx,qw,qz,qw -- 3D translation and orientation.
        """
        self._gndt_full_trajectory = gt_full
        """Dictionary containing raw recorded ground truth trajectory.
        Structure: keyword: 'timestamp' (ROS standard: seconds from UNIX
        epoch),
        value: {list} -- x,y,z,qx,qw,qz,qw -- 3D translation and orientation.
        """
        self._est_full_trajectory = et_full
        """Dictionary containing raw recorded estimated trajectory.
        Structure: keyword: 'timestamp' (ROS standard: seconds from UNIX
        epoch),
        value: {list} -- x,y,z,qx,qw,qz,qw -- 3D translation and orientation.
        """
        r, t, te = self._align()
        self._rot = r
        """Rotation matrix from est trajectory to gndt"""
        self._trans = t
        """Translational vector from est trajectory to gndt"""
        self._trans_error = te
        """Translational error per point."""

    #--------------------------------------------------------------------------
    #         PRIVATE METHODS
    #--------------------------------------------------------------------------
 
    def _getTrajectories(self, filepath):
        gndt, est = self._loadTrajectories(filepath)

        gndt_full = [Pose.fromPoseTime(v[0:7],k) for k,v in gndt.items()]
        est_full = [Pose.fromPoseTime(v,k) for k,v in est.items()]
        gndt_full.sort(cmp=lambda u,v: u.cmpTimestamps(v))
        est_full.sort(cmp=lambda u,v: u.cmpTimestamps(v))

        start = gndt_full[0].time
        if est_full[0].time < start:
            start = est_full[0].time

        for g in gndt_full:
            g.time -= start

        for e in est_full:
            e.time -= start

        matches = utils.associate(gndt, est, self._time_offset,
                                  self._time_window)

        gndt_start = matches[0][0]
        est_start = matches[0][1]
        # XXX 2017-08-21 AR: Ignore last gndt element (velocity)
        gndt = [Pose.fromPoseTime(gndt[a][0:7], a - gndt_start)
                for a, b in matches]
        est = [Pose.fromPoseTime(est[b][0:7], b - est_start)
               for a, b in matches]

        return gndt, est, gndt_full, est_full

    def _loadTrajectories(self, filepath):
        if not os.path.exists(filepath):
            print(errorStr('ERROR: wrong trajectory file path! ' + filepath))
            raise ValueError('ERROR: wrong trajectory file path! ' + filepath)

        gndt = dict()
        est = dict()

        # [gndt] seconds_from_epoch x y z qx qy qz qw v
        # [odom] seconds_from_epoch x y z qx qy qz qw
        # where {x, y, z, qx, qy, qz, qw, v}  are floating point values
        gndt_rexp = re.compile('^\[gndt\]\s+\d+\.\d+\s+(\-?\d+\.\d+\s+){7}' +
                               '(\-?\d+\.\d+){1}$')
        odom_rexp = re.compile('^\[odom\]\s+\d+\.\d+\s+(\-?\d+\.\d+\s+){7}$')

        f = open(filepath, 'r')
        for line in f:
            lval = line.split()
            if gndt_rexp.match(line) is not None:
                gndt[float(lval[1])] = [float(x) for x in lval[2:]]
            elif odom_rexp.match(line) is not None:
                est[float(lval[1])] = [float(x) for x in lval[2:]]
            else:
                print warningStr('ERROR: Invalid trajectory file entry!')
                print warningStr('line: ' + line)
                continue
        f.close()
        return gndt, est

    def _align(self):
        """Computes rotation and translation to align est to gndt trajectory.
        
        Returns:
            rot -- rotation matrix (3x3)
            trans -- translation vector (3x1)
            trans_error -- translational error per point (1xn)
        """
        estt_xyz = numpy.matrix([p.position()
                                for p in self._est_trajectory]).transpose()
        gntt_xyz = numpy.matrix([p.position()
                                for p in self._gndt_trajectory]).transpose()
        rot, trans, trans_error = utils.align(estt_xyz, gntt_xyz)
        return rot, trans, trans_error

    #--------------------------------------------------------------------------
    #         PUBLIC INTERFACE
    #--------------------------------------------------------------------------

    def getMin(self):
        """Return minimum values across collected features from test.

        Returns:
            [list] -- List of minimum values each for collected feature.
        """
        return self._stat['min']

    def getMax(self):
        """Return maximum values across collected features from test.

        Returns:
            [list] -- List of maximum values each for collected feature.
        """
        return self._stat['max']

    def getMean(self):
        """Return mean values across collected features from test.

        Returns:
            [list] -- List of mean values each for collected feature.
        """
        return self._stat['mean']

    def getMedian(self):
        """Return median values across collected features from test.

        Returns:
            [list] -- List of median values each for collected feature.
        """
        return self._stat['median']

    def getStddev(self):
        """Return standard deviation values across collected features from test.

        Returns:
            [list] -- List of standard deviation values each for collected 
                      feature.
        """
        return self._stat['stddev']

    def getConfig(self):
        """Return tested configuration of key, values.

        Returns:
            [dict] -- Dictionary of changed parameters. [string] = [number|str]
        """
        return self._config

    def getEstimatedTrajectory(self):
        """Return estimated trajectory matched with ground truth 
           (within specified window time).
        
        Returns:
            [list[Pose]] -- List of 3D pose with timepoints
        """
        return self._est_trajectory

    def getGndTruthTrajectory(self):
        """Return ground truth trajectory mathced with estimated (within
           specified window time).
        
        Returns:
            [list[Pose]] -- List of 3D pose with timepoints
        """
        return self._gndt_trajectory

    def getFullEstimatedTrajectory(self):
        """Return full (unmatched) estimated trajectory.
        
        Returns:
            [list[Pose]] -- List of 3D pose with timepoints
        """
        return self._est_full_trajectory

    def getFullGndTruthTrajectory(self):
        """Return full (unmatched) ground truth trajectory.
        
        Returns:
            [list[Pose]] -- List of 3D pose with timepoints
        """
        return self._gndt_full_trajectory

    def getRotation(self):
        """Returns rotation matrix transforming est trajectory to gndt coordinates.
        
        Returns:
            [numpy.matrix] -- Rotation matrix 3x3
        """
        return self._rot

    def getTranslation(self):
        """Returns translational vector transforming est trajectory to gndt coordinates.
        
        Returns:
            [numpy.matrix] -- Translational vector.
        """
        return self._trans

    def getATEMetrics(self):
        """Calculates ATE (absolute translational error) metrics.
        
        Calculates rmse, mean, median, standard deviation, min, max metrics.
        
        Returns:
            [number] -- Calculated metrics
        """
        ate_rmse = numpy.sqrt(numpy.dot(trans_error,trans_error) / 
                              len(trans_error))
        ate_mean = numpy.mean(trans_error)
        ate_median = numpy.median(trans_error)
        ate_std = numpy.std(trans_error)
        ate_min = numpy.min(trans_error)
        ate_max = numpy.max(trans_error)
        return ate_rmse, ate_mean, ate_median, ate_std, ate_min, ate_max

class RtabmapTestResult(TestResult):
    """Class holding RtabMap test results.
    
    Extends:
        TestResult
    """

    def __init__(self, test_id, trajectory_file_path, cfg_stat,
                 config_file_path, time_offset=0.0, time_window=0.35):
        """Constructor

        Arguments:
            test_id {str}              -- 'timestamp_pid[_pid]'
            trajectory_file_path {str} -- Absolute path to trajectory file
            cfg_stat {tuple}           -- A tuple consisting of (config=dict, 
                                          stat=dict)
            config_file_path {str}     -- Absolute path to full config file 
                                          (*.ini)

        Keyword Arguments:
            time_offset {number} -- Time offset for estimated pose trajectory
                                    (default: {0.0})
            time_window {number} -- Time window used to search for corresponding
                                    ground truth and estimeted poses (default: 
                                    {0.35})
        """
        super(RtabmapTestResult, self).__init__(test_id, trajectory_file_path, 
                    cfg_stat, time_offset=0.0, time_window=0.35)
        self._full_config_path = config_file_path
        

