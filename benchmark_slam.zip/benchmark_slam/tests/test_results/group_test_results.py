# vim:fileencoding=utf-8

import sys
import os
import re

import tests.util.utilities as utils
import tests.test_results.single_test_results as st_res

from tests.util.json_stat_parser import JSONStatParser
from tests.util.colored_str import *

#--------------------------------------------------------------------------
#         GROUP OF TEST RESULTS
#--------------------------------------------------------------------------

class TestResultsGroup(object):
    """Class representing a group of test results having sth in common.
    
    Results are stored in it's own, unique directory.
    """

    def __init__(self, group_key):
        super(TestResultsGroup, self).__init__()
        self.key = group_key
        self.test_count = 0
        """Number of stored test results."""
        self.results = list()
        # self._subgroups = list()
        
    #--------------------------------------------------------------------------
    #         PUBLIC INTERFACE
    #--------------------------------------------------------------------------

    # def hasSubGroups(self):
    #     return len(self._subgroups) > 0

    # def subgroups(self):
    #     return iter(self._subgroups)

    # def addSubGroup(self, group):
    #     self._subgroups.append(group)
        
    def append(self, result):
        self.results.append(result)
        self.test_count += 1

    #--------------------------------
    #         STATISTICS
    #--------------------------------

    def getBest(self, cmp_fun, n_best):
        self.results.sort(cmp=cmp_fun)
        return self.results[0:n_best]

    def getMinDistribution(self):
        return [t.getMin() for t in self.results]

    def getMaxDistribution(self):
        return [t.getMax() for t in self.results]

    def getMeanDistribution(self):
        return [t.getMean() for t in self.results]

    def getMedianDistribution(self):
        return [t.getMedian() for t in self.results]

    def getStddevDistribution(self):
        return [t.getStddev() for t in self.results]

    #--------------------------------
    #         MISCELLANEOUS
    #--------------------------------

    def getTestedConfigs(self):
        return [t.getConfig() for t in self.results]

    def getUniqueConfigKeys(self):
        configs = self.getTestedConfigs()
        return utils.uniqueKeys(configs)


#--------------------------------------------------------------------------
#         BAG TEST RESULTS
#--------------------------------------------------------------------------

class BagTestResult(object):
    """A class representing results form all test run with given bagfile"""

    def __init__(self, bag_filename):
        """Constuctor. Initialize class instance variables.
        
        Arguments:
            bag_filename {str} -- Name of the file providing test data.
        """
        super(BagTestResult, self).__init__()
        self.bag_filename = bag_filename
        """Name of the file providing test data. It's a ROS bag file."""
        self._re_timestamp = ('\d{4}((0[1-9])|(1[0-2]))((0[1-9])|([1,2]\d)|' +
                             '(3[0,1]))(([0,1]\d)|(2[0-3]))([0-5]\d){2}')
        """Regular expression used to extract timestamp information.
        Matches correct data in format: YYYYMMDDHHMMSS"""
        self._re_pid_pid = '_\d+(_\d+)?'
        """Regular expression used to extract PID infromation.
        Matches information in format _PID[_PID], where second PID is 
        optional. PID may consist of multiple digits."""
        self.test_count = 0
        """Number of stored test results."""
        self.groups = dict()

        print(infoStr('----------------------------------------'))
        print(infoStr('Creating BagTestResult:'))
        print(infoStr('bag_filename: ' + self.bag_filename))

    def _hasSubGroups(self, dir):
        """Check whether dir has subgroups inside.
        
        All elements inside dir have to be a directory if there is a subgroup.
        
        Arguments:
            dir {str} -- Absolute path to directory to check.
        
        Returns:
            bool -- True if there are subgroups else False.
        """
        for f in os.listdir(dir):
            if not os.path.isdir(os.path.join(dir, f)):
                return False
        return True

    def _getTrajectoryFilePaths(self, trajectory_files_dir):
        # Must match format 'timestamp_pid[_pid]_trajectory.txt'
        paths = [os.path.join(trajectory_files_dir, f)
                 for f in os.listdir(trajectory_files_dir) if
                 os.path.isfile(os.path.join(trajectory_files_dir, f)) and
                 re.match(self._re_timestamp + self._re_pid_pid + 
                          '_trajectory.txt', f)
                 is not None]

        print(infoStr('trajectory_files_dir: ' + trajectory_files_dir))
        print(infoStr('n traj. paths: ' + str(len(paths))))
        return paths

    def _getConfigStatsData(self, stat_files_dir):
        stat_data = JSONStatParser.parseBagData(stat_files_dir, 
                                                self.bag_filename)

        print(infoStr('stat_files_dir: ' + stat_files_dir))
        print(infoStr('n stat_entries: ' + str(len(stat_data))))

        return stat_data

    def _matches(self, trajectory_files, cfg_stats):
        """Finds and collects matches for entries across given files.
        
        Arguments:
            trajectory_files {list[str]} -- List with paths of trajectory 
                                            files.
            cfg_stats {list[tuple]} -- List of config-stats tuples.
        """
        trajectories = list(trajectory_files)
        for c, s, tid in cfg_stats:
            tp = str()
            for t in trajectories:
                if re.search(tid, t) is not None:
                    tp = t
                    trajectories.remove(t)
                    break
            if len(tp) == 0:
                print(infoStr('No matches found for tid: ' + tid))
                continue
            else:
                yield (tp, (c, s), tid)

    #--------------------------------------------------------------------------
    #         PUBLIC INTERFACE
    #--------------------------------------------------------------------------

    def getBest(self, cmp_fun, n_best):
        all_results = list()
        for g in self.groups:
            all_results.extend(g.getBest(cmp_fun, n_best))
        all_results.sort(cmp=cmp_fun)
        return all_results[0:n_best]

    def getMinDistribution(self):
        return reduce(lambda x, y: x + y, 
                            self.getGroupMinDistribution().values(), list())

    def getMaxDistribution(self):
        return reduce(lambda x, y: x + y, 
                            self.getGroupMaxDistribution().values(), list())

    def getMeanDistribution(self):
        return reduce(lambda x, y: x + y, 
                            self.getGroupMeanDistribution().values(), list())

    def getMedianDistribution(self):
        return reduce(lambda x, y: x + y, 
                            self.getGroupMedianDistribution().values(), list())

    def getStddevDistribution(self):
        return reduce(lambda x, y: x + y, 
                            self.getGroupStddevDistribution().values(), list())

    def getTestedConfigs(self):
        return reduce(lambda x, y: x + y, 
                            self.getGroupTestedConfigs().values(), list())

    def getUniqueConfigKeys(self):
        configs = self.getTestedConfigs()
        return utils.uniqueKeys(configs)

    def getGroupBest(self, cmp_fun, n_best):
        return dict([(k, g.getBest()) for (k,g) in self.groups.iteritems()])

    def getGroupMinDistribution(self):
        return dict([(k, g.getMinDistribution()) for (k,g) in 
                                                    self.groups.iteritems()])

    def getGroupMaxDistribution(self):
        return dict([(k, g.getMaxDistribution()) for (k,g) in 
                                                    self.groups.iteritems()])

    def getGroupMeanDistribution(self):
        return dict([(k, g.getMeanDistribution()) for (k,g) in 
                                                    self.groups.iteritems()])

    def getGroupMedianDistribution(self):
        return dict([(k, g.getMedianDistribution()) for (k,g) in 
                                                    self.groups.iteritems()])

    def getGroupStddevDistribution(self):
        return dict([(k, g.getStddevDistribution()) for (k,g) in 
                                                    self.groups.iteritems()])

    def getGroupTestedConfigs(self):
        return dict([(k, g.getTestedConfigs()) for (k,g) in 
                                                    self.groups.iteritems()])


class RtabmapBagTestResult(BagTestResult):
    """Aggregates results from all tests run on single bag file with RtabMap.
    
    Extends:
        BagTestResult
    """
    def __init__(self, bag_filename, trajectory_files_dir, config_files_dir,
                 stat_files_dir, old_data_format=False):
        """Constructor.
        
        Scans for trajectory, config-stat and configuration files, then tries 
        to match entries and build test results objects.
                
        Arguments:
            bag_filename {str} -- Tested bag file name.
            trajectory_files_dir {str} -- Directory with trajectory files.
            config_files_dir {str} -- Directory with configuration files.
            stat_files_dir {str} -- Directory with config-stat files.

        Keyword Arguments:
            old_data_format {bool} -- Flag indicating wheter or not to use
                                    old data format, when there was no PID 
                                    in file identificators. (default: {False})
        """
        super(RtabmapBagTestResult, self).__init__(bag_filename)
                                            
        # In old data format we didn't use PID postfixes, so clear this part
        # of regular expression used to filter files.
        self._old_data_format = old_data_format
        if self._old_data_format:
            self._re_pid_pid = ''

        self._collectData(config_files_dir, trajectory_files_dir, 
                          stat_files_dir, str(), bag_filename)
        print(infoStr('matched test_count: ' + str(self.test_count)))

    def _collectData(self, c_dir, t_dir, s_dir, prev_node, curr_leaf):
        """Recursively collect data and pack into TestResultGroup objects.
        
        NOTE: Support only one level of group nesting.
        
        Arguments:
            c_dir {str} -- Path to configuration files directory.
            t_dir {str} -- Path to trajectory files directory.
            s_dir {str} -- Path to stats files directory.
            prev_node {str} -- Name of previously processed directory.
            curr_leaf {str} -- Name of currently processed directory.
        """
        if (self._hasSubGroups(c_dir) and
            self._hasSubGroups(t_dir) and
            self._hasSubGroups(s_dir)):

            if (prev_node is self.bag_filename and
                curr_leaf is not self.bag_filename):
                print(errorStr('[ERROR] Nested TestResultsGroup at level 2' +
                               ' detected! Nested subgroups are not' +
                               ' supported yet!'))
                sys.exit()

            c_sub_dirs = [f for f in os.listdir(c_dir)]
            t_sub_dirs = [f for f in os.listdir(t_dir)]
            s_sub_dirs = [f for f in os.listdir(s_dir)]

            for c in c_sub_dirs:
                if c in t_sub_dirs and c in s_sub_dirs:
                    self._collectData(os.path.join(c_dir, c),
                                      os.path.join(t_dir, c),
                                      os.path.join(s_dir, c), curr_leaf, c)
        else:
            if curr_leaf is not self.bag_filename:
                g = TestResultsGroup(curr_leaf)
            else:
                g = TestResultsGroup('default')

            print(infoStr('Creating TestResultsGroup with key: ' + g.key))

            config_file_paths = self._getConfigFilePaths(c_dir)
            trajectory_file_paths = self._getTrajectoryFilePaths(t_dir)
            stat_data = self._getConfigStatsData(s_dir)

            for r in self._matches(trajectory_file_paths, stat_data,
                                   config_file_paths):
                t_path = r[0]
                c_path = r[1]
                cfg_stat = r[2]
                test_id = r[3]
                g.append(st_res.RtabmapTestResult(test_id, t_path, cfg_stat,
                                                 c_path))
            self.groups[g.key] = g
            self.test_count += g.test_count

    def _getConfigFilePaths(self, c_dir):
        c_paths = [os.path.join(c_dir, f) for f in os.listdir(c_dir)
                   if os.path.isfile(os.path.join(c_dir, f)) and
                      re.match('_?' + self.bag_filename + '_' +
                      self._re_timestamp + self._re_pid_pid +
                      '_rtab_config.ini', f)
                   is not None]
        print(infoStr('config_files_dir: ' + c_dir))
        print(infoStr('n config_files_paths: ' + str(len(c_paths))))
        return c_paths

    def _matches(self, trajectory_files, cfg_stats, config_files):
        """Finds and collects matches for entries across given files.
        
        Arguments:
            trajectory_files {list[str]} -- List with paths of trajectory 
                                            files.
            cfg_stats {list[tuple]} -- List of config-stats tuples.
            config_files {list[str]} -- List of paths of configuration files.
        
        Raises:
            ValueError -- If an identificator within cfg_stats file is invalid.
        """
        trajectories = list(trajectory_files)
        configs = list(config_files)
        for c, s, tid in cfg_stats:
            if self._old_data_format:
                rexptm = re.search(self._re_timestamp, tid)
                if rexptm is not None:
                    tid = rexptm.group()
                else:
                    from inspect import currentframe, getframeinfo
                    frameinfo = getframeinfo(currentframe())
                    raise ValueError('Invalid stat id format! file: ' +
                                     frameinfo.filename + ', line: ' +
                                     str(frameinfo.lineno))
            tp = str()
            cp = str()
            for t in trajectories:
                if re.search(tid, t) is not None:
                    tp = t
                    trajectories.remove(t)
                    break
            for k in configs:
                if re.search(tid, k) is not None:
                    cp = k
                    configs.remove(k)
                    break
            if len(tp) == 0 or len(cp) == 0:
                continue
            else:
                yield (tp, cp, (c, s), tid)


class ClosedLibBagTestResult(BagTestResult):
    """Aggregates results form all tests run on single bag file.
    
    Description:
        Should be used with closed source libraries which doesn't provide 
        configuration parameters for their SLAM solutions. Or in case we don't
        need to change any of available parameters.

    Extends:
        BagTestResult
    """

    def __init__(self, bag_filename, trajectory_files_dir, stat_files_dir):
        """Constructor
        
        Scans for trajectory and config-stat files, then tries to match entries
        and build test results objects.
        
        Arguments:
            bag_filename {str} -- Tested bag file name.
            trajectory_files_dir {str} -- Directory with trajectory files.
            stat_files_dir {str} -- Directory with config-stat files.
        """
        super(ClosedLibBagTestResult, self).__init__(bag_filename)

        trajectory_file_paths = self._getTrajectoryFilePaths(
                                            trajectory_files_dir)
        stat_data = self._getConfigStatsData(stat_files_dir)

        g = TestResultsGroup('default')

        for r in self._matches(trajectory_file_paths, stat_data):
            t_path = r[0]
            cfg_stat = r[1]
            test_id = r[2]
            g.append(st_res.TestResult(r[2], r[0], r[1]))

        self.groups[g.key] = g
        self.test_count += g.test_count
        print(infoStr('matched test_count: ' + str(self.test_count)))

