# vim:fileencoding=utf-8

import os
import errno
import numpy as np
import functools

import tests.test_results.group_test_results as gt_results
import tests.plotting.plotting as plotting
import tests.util.utilities as utils

from tests.util.colored_str import *

class TestResultsAnalysis(object):
    """TestResultsAnalysis class defines interfase for test results analysis"""

    def __init__(self, t_dir, s_dir, o_dir):
        """Constructor
        
        Initializes necessary members and search for bagfiles.
        
        Arguments:
            t_dir {str} -- Absolute path to trajectory files directory.
            s_dir {str} -- Absolute path to statistics files directory.
            o_dir {str} -- Absolute path to output files directory.
        """
        self._output_base_dir = o_dir
        self._bag_results = list()
        self._findBagfiles(t_dir, s_dir)

    # --------------------------------------------------------
    #   PUBLIC INTERFACE
    # --------------------------------------------------------

    def drawGeneralStat(self):
        for br in self._bag_results:
            self._doDrawGeneralStat(br)

    def drawTrajectories(self, tr_group, bag_filename):
        for tr in tr_group.results:
            self._doDrawTrajectory(tr, bag_filename, tr_group.key)

    def drawAlignedTrajectories(self, tr_group, bag_filename):
        for tr in tr_group.results:
            self._doDrawAlignedTrajectory(tr, bag_filename, tr_group.key)


    # --------------------------------------------------------
    #   PRIVATE METHODS
    # --------------------------------------------------------

    def _findBagfiles(self, t_dir, s_dir):
        # acquire bag filenames 
        self._bagnames = [d for d in os.listdir(t_dir) 
                          if os.path.isdir(os.path.join(t_dir, d))]
        # check consistency across directories
        for b in [d for d in os.listdir(s_dir) if os.path.isdir(
                  os.path.join(s_dir, d))]:
            if b not in self._bagnames:
                print(warningStr('Bag file names inconsistency! Bag: <' +
                     b + '> is missing from directory: ' + trajectory_dir))

        for b in self._bagnames:
            print(infoStr('Found bag: ' + b))

    def _drawSingleMMMErrPlot(self, max_dist, min_dist, mean_dist, path):
        mmm_plot = plotting.StandardPlot()
        filenames = ['est_err_mmm_along_x_axis',
                     'est_err_mmm_along_y_axis',
                     'est_err_mmm_along_z_axis']
        mmm_plot.x_axis_label = 'Nr testu'
        mmm_plot.y_axis_label = u'Wartość błędu estymacji [m]'
        mmm_plot.out_path = path

        # plot for x,y,z axis respectively
        for i, filename in enumerate(filenames):
            mmm_plot.clearLayers()
            mmm_plot.filename = filename
            x_data = range(len(max_dist))
            y_data = [[t[i] for t in min_dist]]
            y_data.append([t[i] for t in max_dist])
            y_data.append([t[i] for t in mean_dist])

            mmm_plot.addLayer(plotting.StandardLayer(x_data, y_data[0],
                            'min', '#d62728', marker_style='.'))
            mmm_plot.addLayer(plotting.StandardLayer(x_data, y_data[0],
                            'max', '#d62728', marker_style='.'))
            mmm_plot.addLayer(plotting.StandardLayer(x_data, y_data[0],
                            'mean', '#1f77b4', marker_style='x'))
            mmm_plot.plot()
            mmm_plot.savePlot()

    def _drawSingleMedianErrPlot(self, median_dist, path):
        m_plot = plotting.StandardPlot()
        filenames = ['est_err_median_along_x_axis',
                     'est_err_median_along_y_axis',
                     'est_err_median_along_z_axis']
        m_plot.x_axis_label = 'Nr testu'
        m_plot.y_axis_label = u'Wartość błędu estymacji [m]'
        m_plot.out_path = path

        # plot for x,y,z axis respectively
        for i, filename in enumerate(filenames):
            m_plot.clearLayers()
            m_plot.filename = filename
            x_data = range(len(median_dist))
            y_data = [t[i] for t in median_dist]

            m_plot.addLayer(plotting.StandardLayer(x_data, y_data,
                            'mediana', '#1f77b4', marker_style='x'))
            m_plot.plot()
            m_plot.savePlot()

    def _drawSingleStddevErrPlot(self, stddev_dist, path):
        std_plot = plotting.StandardPlot()
        filenames = ['est_err_stddev_along_x_axis',
                     'est_err_stddev_along_y_axis',
                     'est_err_stddev_along_z_axis']
        std_plot.x_axis_label = 'Nr testu'
        std_plot.y_axis_label = u'Wartość błędu estymacji [m]'
        std_plot.out_path = path

        # plot for x,y,z axis respectively
        for i, filename in enumerate(filenames):
            std_plot.clearLayers()
            std_plot.filename = filename
            x_data = range(len(stddev_dist))
            y_data = [t[i] for t in stddev_dist]

            std_plot.addLayer(plotting.StandardLayer(x_data, y_data,
                            'stddev', '#1f77b4', marker_style='x'))
            std_plot.plot()
            std_plot.savePlot()

    def _doDrawGeneralStat(self, bag_results):
        subdir = bag_results.bag_filename + '/general_stat'
        path = self._output_base_dir + '/' + subdir
        try:
            os.makedirs(path)
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise
        
        if len(bag_results.groups) == 0:
            print(warningStr('Bag "' + bag_result.bag_filename + '" have no' +
                             ' data to plot!'))
            return
        elif len(bag_results.groups) == 1:
            # draw 'flat' plots, since there is only single group
            max_dist = bag_results.getMaxDistribution()
            min_dist = bag_results.getMinDistribution()
            mean_dist = bag_results.getMeanDistribution()
            median_dist = bag_results.getMedianDistribution()
            stddev_dist = bag_results.getStddevDistribution()

            # -----------------------------------------------------------------
            #           MIN, MEAN, MAX PLOT
            # -----------------------------------------------------------------
            self._drawSingleMMMErrPlot(max_dist, min_dist, mean_dist, path)
            # -----------------------------------------------------------------
            #           MEDIAN PLOT
            # -----------------------------------------------------------------
            self._drawSingleMedianErrPlot(median_dist, path)
            # -----------------------------------------------------------------
            #           STANDARD DEVIATION PLOT
            # -----------------------------------------------------------------
            self._drawSingleStddevErrPlot(stddev_dist, path)
        else:
            # draw single error bar for each group
            # TODO
            pass


    def _doDrawTrajectory(self, test_result, bag_filename, group_key):
        subdir = bag_filename + '/trajectories/' + group_key
        path = self._output_base_dir + '/' + subdir
        try:
            os.makedirs(path)
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise

        estt = test_result.getEstimatedTrajectory()
        gntt = test_result.getGndTruthTrajectory()

        x_data = list()
        y_data = list()

        x_data.append([p.time for p in gntt])
        x_data.append([p.time for p in estt])

        y_data.append([p.y for p in gntt])
        y_data.append([p.y for p in estt])

        plot_label = ['ground_truth', 'estimated']
        plot_colour = ['#1f77b4', '#2ca02c']
        marker_style = ['', '']
        line_style = ['-', '--']
        axis_label = ['Czas[s]', u'Pozycja wzdłuż osi y[m]']

        plotting.drawStdPlot(x_data, y_data, plot_label, line_style, 
                             marker_style, plot_colour, axis_label, path,
                             test_result._test_id + '_trajectory_y_axis')

    def _doDrawAlignedTrajectory(self, test_result, bag_filename, group_key):
        subdir = bag_filename + '/trajectories/' + group_key
        path = self._output_base_dir + '/' + subdir
        try:
            os.makedirs(path)
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise

        estt = test_result.getEstimatedTrajectory()
        gntt = test_result.getGndTruthTrajectory()
        estt_full = test_result.getFullEstimatedTrajectory()
        gntt_full = test_result.getFullGndTruthTrajectory()

        estt_xyz = np.matrix([p.position() for p in estt]).transpose()
        gntt_xyz = np.matrix([p.position() for p in gntt]).transpose()

        estt_full_xyz = np.matrix(
                            [p.position() for p in estt_full]).transpose()
        gntt_full_xyz = np.matrix(
                            [p.position() for p in gntt_full]).transpose()

        rot = test_result.getRotation()
        trans = test_result.getTranslation()
        estt_aligned = rot * estt_xyz + trans
        estt_full_aligned = rot * estt_full_xyz + trans
        
        # ----- y axis ----- 
        x_data = list()
        y_data = list()

        x_data.append([p.time for p in gntt])
        x_data.append([p.time for p in estt])

        y_data.append(list(gntt_xyz.A[1,:]))
        y_data.append(list(estt_aligned.A[1,:]))

        plot_label = ['ground_truth', 'estimated']
        plot_colour = ['#1f77b4', '#2ca02c']
        marker_style = ['', '']
        line_style = ['-', '--']
        axis_label = ['Czas[s]', u'Pozycja wzdłuż osi y[m]']

        plotting.drawStdPlot(x_data, y_data, plot_label, line_style, 
                             marker_style, plot_colour, axis_label, path,
                             test_result._test_id + 
                             '_aligned_trajectory_y_axis')
        
        x_data = list()
        y_data = list()

        x_data.append([p.time for p in gntt_full])
        x_data.append([p.time for p in estt_full])

        y_data.append(list(gntt_full_xyz.A[1,:]))
        y_data.append(list(estt_full_aligned.A[1,:]))

        plotting.drawStdPlot(x_data, y_data, plot_label, line_style, 
                             marker_style, plot_colour, axis_label, path,
                             test_result._test_id + 
                             '_full_aligned_trajectory_y_axis')


class RtabmapAnalysis(TestResultsAnalysis):
    """Class providing tools to analyse Rtabmap test results."""

    def __init__(self, trajectory_dir, config_dir, stat_dir, output_dir,
                 old_data_format=False):
        super(RtabmapAnalysis, self).__init__(trajectory_dir, stat_dir,
                                              output_dir)

        for b in [d for d in os.listdir(config_dir) if os.path.isdir(
                    os.path.join(config_dir, d))]:
            if b not in self._bagnames:
                print(warningStr('Bag file names inconsistency! Bag: <' +
                     b + '> is missing from directory: ' + trajectory_dir))

        self._bag_results = [gt_results.RtabmapBagTestResult(b,
                                trajectory_dir + '/' + b, config_dir + 
                                '/' + b, stat_dir + '/' + b, old_data_format)
                             for b in self._bagnames]

        """A list of blacklisted parameters for drawing plots
        
        We don't draw plots for these parameters, as they're fixed at single 
        value at the moment.
        """
        self._PARAM_BLACKLIST = [
            'DbSqlite3\InMemory',
            'BRIEF\Bytes',
            'Grid\DepthMax',
            'Grid\DepthMin',
            'Grid\NoiseFilteringMinNeighbors',
            'Grid\NoiseFilteringRadius',
            'Kp\MaxFeatures',
            'Kp\MaxDepth',
            'Kp\MinDepth',
            'Kp\NNStrategy',
            'Mem\BadSignaturesIgnored',
            'Mem\ImageKept',
            'Mem\STMSize',
            'Mem\NotLinkedNodesKept',
            'Odom\ImageBufferSize',
            'Odom\ResetCountdown',
            'OdomF2M\BundleAdjustment',
            'Optimizer\Robust',
            'Optimizer\Strategy',
            'RGBD\OptimizeMaxError',
            'RGBD\OptimizeFromGraphEnd',
            'Rtabmap\TimeThr',
            'Rtabmap\PublishLastSignature',
            'Rtabmap\PublishLikelihood',
            'Rtabmap\PublishPdf',
            'Rtabmap\PublishStats',
            'Rtabmap\ImageBufferSize',
            'Rtabmap\DetectionRate',
            'Reg\Strategy',
            'Vis\BundleAdjustment',
            'Vis\CorNNType',
            'Vis\EstimationType',
            'Vis\MaxDepth',
            'Vis\MinDepth',
        ]

    # --------------------------------------------------------
    #   PUBLIC INTERFACE
    # --------------------------------------------------------

    def drawStatPerKey(self):
        for br in self._bag_results:
            self._doDrawStatPerKey(br)

    def drawStatPerKeyGroup(self):
        for br in self._bag_results:
            for g in br.groups.values():
                self._doDrawStatPerKeyGroup(g, br.bag_filename)

    def drawStatPerKeyBags(self):
        self._doDrawStatPerKeyBags()

    def drawStatPerKeyGroupInterBags(self):
        self._drawStatPerKeyGroupInterBags()

    # --------------------------------------------------------
    #   PRIVATE METHODS
    # --------------------------------------------------------

    def _doDrawStatPerKey(self, bag_results):
        """Draw statistics plots per key values.
        
        Arguments:
            bag_results {RtabmapBagTestResult} -- Object with data 
                            corresponding to bag test resutls.
        
        Keyword Arguments:
            draw_hist {bool} -- Whether or not to draw histograms 
                                (default: {False})
        """
        subdir = bag_results.bag_filename + '/stat_per_key'
        path = self._output_base_dir + '/' + subdir
        try:
            os.makedirs(path)
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise
        
        unique_config_keys = bag_results.getUniqueConfigKeys()
        configs = bag_results.getTestedConfigs()
        max_dist = bag_results.getMaxDistribution()
        mean_dist = bag_results.getMeanDistribution()
        median_dist = bag_results.getMedianDistribution()
        stddev_dist = bag_results.getStddevDistribution()
        
        prefix = 'key_'

        for key in unique_config_keys:
            if key in self._PARAM_BLACKLIST:
                continue
            param_name = ''.join(key.split('\\'))
            filename = prefix + param_name
            self._drawErrInParamValue(param_name, key, filename, path, configs,
                                      max_dist, mean_dist, stddev_dist)

            # ------------ HISTOGRAMS -------------
            # if draw_hist:
            #     # max along y-axis
            #     max_val = max(y_data[3])
            #     min_val = min(y_data[3])
            #     dt_val = max_val - min_val
            #     step = dt_val / 10.0;
            #     y_bins = np.arange(min_val-0.5*step, max_val+step, step)
                
            #     unique_key_val = utils.uniqueValues(key_values)
            #     nx_bins = len(unique_key_val)
            #     min_kv = min(unique_key_val)
            #     max_kv = max(unique_key_val)
            #     if nx_bins == 1:
            #         if max_kv is not 0:
            #             x_bins = [max_kv*0.5, max_kv*1.5]
            #         else:
            #             x_bins = [-0.5, 0.5]
            #     else:
            #         step_kv = abs(unique_key_val[1]-unique_key_val[0])
            #         dt_kv = max_kv - min_kv + step_kv
            #         x_bins = np.arange(min_kv-step_kv*0.5, max_kv+step_kv, step_kv)
                
            #     axis_label = [u'Wartość parametru ' + param_name,
            #                   u'Błąd wzdłuż osi y[m]']

            #     plotting.drawHist2DPlot(key_values, y_max, x_bins, y_bins, 
            #                     axis_label, path, filename + 
            #                     '_est_max_err_y-axis-hist2d')

    def _doDrawStatPerKeyGroup(self, group, bag_filename):
        subdir = bag_filename + '/stat_per_key/' + group.key
        path = self._output_base_dir + '/' + subdir
        try:
            os.makedirs(path)
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise
        
        configs = group.getTestedConfigs()
        max_dist = group.getMaxDistribution()
        mean_dist = group.getMeanDistribution()
        median_dist = group.getMedianDistribution()
        stddev_dist = group.getStddevDistribution()
        
        prefix = 'key_'
        param_name = ''.join(group.key.split('\\'))
        filename = prefix + param_name

        self._drawErrInParamValue(param_name, group.key.replace('_','\\'),
                                  filename, path, configs, max_dist, mean_dist,
                                  stddev_dist)

    def _drawErrInParamValue(self, param_name, key, filename, path, configs,
                            max_dist, mean_dist, stddev_dist):
        key_values = list()
        y_data = dict()
        y_data['x_max'] = list()
        y_data['x_mean'] = list()
        y_data['x_std'] = list()
        y_data['y_max'] = list()
        y_data['y_mean'] = list()
        y_data['y_std'] = list()
        y_data['z_max'] = list()
        y_data['z_mean'] = list()
        y_data['z_std'] = list()

        for c, maxx, mean, stddev, in zip(configs, max_dist, mean_dist,
                                          stddev_dist):
            if c.has_key(key):
                key_values.append(utils.val2numeric(c[key]))
                # x-axis
                y_data['x_max'].append(maxx[0])
                y_data['x_mean'].append(mean[0])
                y_data['x_std'].append(stddev[0])
                # y-axis
                y_data['y_max'].append(maxx[1])
                y_data['y_mean'].append(mean[1])
                y_data['y_std'].append(stddev[1])
                # z-axis
                y_data['z_max'].append(maxx[2])
                y_data['z_mean'].append(mean[2])
                y_data['z_std'].append(stddev[2])

        # along x-axis
        marker = 'x'
        colour = '#1f77b4'
        axis_label = [u'Wartość parametru ' + param_name,
                      u'Maks błąd estym. wzdłuż osi x[m]']

        plotting.drawScatterPlot(key_values, y_data['x_max'], marker, colour,
            axis_label, path, filename + '_est_max_err_x-axis')

        axis_label[1] = u'Średni błąd estym. wzdłuż osi x[m]'
        plotting.drawScatterPlot(key_values, y_data['x_mean'], marker, colour,
            axis_label, path, filename + '_est_mean_err_x-axis')

        axis_label[1] = u'Std. odch. błędu estymacji wzdłuż osi x[m]'
        plotting.drawScatterPlot(key_values, y_data['x_std'], marker, colour,
            axis_label, path, filename + '_est_stddev_err_x-axis')

        # along y-axis
        marker = 'x'
        colour = '#1f77b4'
        axis_label = [u'Wartość parametru ' + param_name,
                      u'Maks błąd estym. wzdłuż osi y[m]']

        plotting.drawScatterPlot(key_values, y_data['y_max'], marker, colour,
            axis_label, path, filename + '_est_max_err_y-axis')

        axis_label[1] = u'Średni błąd estym. wzdłuż osi y[m]'
        plotting.drawScatterPlot(key_values, y_data['y_mean'], marker, colour,
            axis_label, path, filename + '_est_mean_err_y-axis')

        axis_label[1] = u'Std. odch. błędu estymacji wzdłuż osi y[m]'
        plotting.drawScatterPlot(key_values, y_data['y_std'], marker, colour,
            axis_label, path, filename + '_est_stddev_err_y-axis')

        # along z-axis
        marker = 'x'
        colour = '#1f77b4'
        axis_label = [u'Wartość parametru ' + param_name,
                      u'Maks błąd estym. wzdłuż osi z[m]']

        plotting.drawScatterPlot(key_values, y_data['z_max'], marker, colour,
            axis_label, path, filename + '_est_max_err_z-axis')

        axis_label[1] = u'Średni błąd estym. wzdłuż osi z[m]'
        plotting.drawScatterPlot(key_values, y_data['z_mean'], marker, colour,
            axis_label, path, filename + '_est_mean_err_z-axis')

        axis_label[1] = u'Std. odch. błędu estymacji wzdłuż osi z[m]'
        plotting.drawScatterPlot(key_values, y_data['z_std'], marker, colour,
            axis_label, path, filename + '_est_stddev_err_z-axis')

    def _doDrawStatPerKeyBags(self):
        subdir = '/inter_bag_stat'
        path = self._output_base_dir + '/' + subdir
        try:
            os.makedirs(path)
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise
        
        # some magic: flattening multiple lists and removing duplicate keys.
        unique_config_keys = list(functools.reduce(np.intersect1d, 
                                            tuple([br.getUniqueConfigKeys() 
                                                for br in self._bag_results])))
        prefix = 'key_'

        for key in unique_config_keys:
            if key in self._PARAM_BLACKLIST:
                continue
            param_name = ''.join(key.split('\\'))
            filename = prefix + param_name


            #------------------------------------------------------------------
            #  Estimation errorbars in function of parameter value across bags
            #------------------------------------------------------------------
            # key values across bags should be the same
            key_values = [utils.val2numeric(c[key])
                            for c in self._bag_results[0].getTestedConfigs()
                            if c.has_key(key)]
            unique_values = utils.uniqueValues(key_values)
            # sort to preserve same order of parameter values
            unique_values.sort()

            data = list()
            # collect data for respective bags, parameter-value pairs, and 
            # respective statistic metrics
            for br in self._bag_results:
                kv_maps = [dict() for i in range(9)]
                configs = br.getTestedConfigs()
                max_dist = br.getMaxDistribution()
                mean_dist = br.getMeanDistribution()
                stddev_dist = br.getStddevDistribution()

                for c, maxx, mean, stddev in zip(configs, max_dist, mean_dist,
                                                  stddev_dist):
                    if c.has_key(key):
                        # XXX: 2017-08-24 We ignore rotations at the moment!
                        # To add them, one should extend data matrix along 
                        # y dimension, and fill it with appropriate data below.
                        # x-axis
                        self._addKVMapValue(kv_maps[0], c[key], maxx[0])
                        self._addKVMapValue(kv_maps[1], c[key], mean[0])
                        self._addKVMapValue(kv_maps[2], c[key], stddev[0])
                        # y-axis
                        self._addKVMapValue(kv_maps[3], c[key], maxx[1])
                        self._addKVMapValue(kv_maps[4], c[key], mean[1])
                        self._addKVMapValue(kv_maps[5], c[key], stddev[1])
                        # z-axis
                        self._addKVMapValue(kv_maps[6], c[key], maxx[2])
                        self._addKVMapValue(kv_maps[7], c[key], mean[2])
                        self._addKVMapValue(kv_maps[8], c[key], stddev[2])
                data.append(kv_maps)

            # compute (min, max, mean) for each parameter-value list of data.
            plot_data = np.zeros([len(self._bag_results), 9, 3, 
                                  len(unique_values)])

            for b,kv_maps in enumerate(data):
                for m in range(9):
                    kvs = kv_maps[m].items()
                    # sort to preserve same order of parameter values
                    kvs.sort()
                    for i,(k,v) in enumerate(kvs):
                        plot_data[b,m,0,i] = np.min(v)
                        plot_data[b,m,1,i] = np.max(v)
                        plot_data[b,m,2,i] = np.mean(v)

            #------------------------------------------------------------------
            #  MAX DISTRIBUTION ERROR
            #------------------------------------------------------------------
            # along x-axis
            x_data = unique_values
            y_data = plot_data[:,0,:,:]
            plot_colours = plotting.getLightColours(y_data.shape[0])
            plot_label = [br.bag_filename for br in self._bag_results]
            axis_label = [u'Wartość parametru ' + param_name,
                          u'Maks błąd estym. wzdłuż osi x[m]']

            plotting.drawErrorBarStatPlot(x_data, y_data, plot_colours, 
                        plot_label, axis_label, path, 
                        filename + '_max_est_err_x-axis')

            # along y-axis
            y_data = plot_data[:,3,:,:]
            plot_colours = plotting.getLightColours(y_data.shape[0])
            plot_label = [br.bag_filename for br in self._bag_results]
            axis_label = [u'Wartość parametru ' + param_name,
                          u'Maks błąd estym. wzdłuż osi y[m]']

            plotting.drawErrorBarStatPlot(x_data, y_data, plot_colours, 
                        plot_label, axis_label, path, 
                        filename + '_max_est_err_y-axis')

            #------------------------------------------------------------------
            #  STANDARD DEVIATION DISTRIBUTION ERROR
            #------------------------------------------------------------------
            # along x-axis
            y_data = plot_data[:,2,:,:]
            plot_colours = plotting.getLightColours(y_data.shape[0])
            plot_label = [br.bag_filename for br in self._bag_results]
            axis_label = [u'Wartość parametru ' + param_name,
                          u'Std. odch. błędu estym. wzdłuż osi x[m]']

            plotting.drawErrorBarStatPlot(x_data, y_data, plot_colours, 
                        plot_label, axis_label, path, 
                        filename + '_stddev_est_err_x-axis')

            # along y-axis
            y_data = plot_data[:,5,:,:]
            plot_colours = plotting.getLightColours(y_data.shape[0])
            plot_label = [br.bag_filename for br in self._bag_results]
            axis_label = [u'Wartość parametru ' + param_name,
                          u'Std. odch. błędu estym. wzdłuż osi y[m]']

            plotting.drawErrorBarStatPlot(x_data, y_data, plot_colours, 
                        plot_label, axis_label, path, 
                        filename + '_stddev_est_err_y-axis')

    def _addKVMapValue(self, kv_map, key, val):
        # print(debugStr('Adding [' + str(key) + ']:' + str(val)))
        if key in kv_map:
            kv_map[key].append(val)
        else:
            kv_map[key] = list([val])

    def _drawStatPerKeyGroupInterBags(self):
        subdir = '/inter_bag_stat'
        path = self._output_base_dir + '/' + subdir
        try:
            os.makedirs(path)
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise
        
        prefix = 'key_'
        plot_dict = dict()

        for b_idx, b in enumerate(self._bag_results):
            layers_dict = dict()
            print(infoStr('---- processing bag: ' + b.bag_filename))

            # through each group
            for k,group in b.groups.iteritems():
                key = group.key.replace('_','\\')
                if key in self._PARAM_BLACKLIST:
                    continue
                print(infoStr('---- processing group: ' + key))

                bw = 0.4
                x_ticks_labels = list()
                x_ticks_rotation = 'horizontal'
                if (key == 'Kp\DetectorStrategy' or
                    key == 'Vis\FeatureType'):
                    bw = 0.6
                    x_ticks_labels = ['ORB', 'FAST/FREAK', 'FAST/BRIEF',
                        'GFTT/FREAK', 'GFTT/BRIEF', 'BRISK', 'GFTT/ORB',
                        'FREAK']
                    x_ticks_rotation = 30
                elif key == 'Vis\CorType':
                    bw = 0.2
                    x_ticks_labels = ['Features Matching', 'Optical Flow']
                elif key == 'Odom\Strategy':
                    bw = 0.2
                    x_ticks_labels = ['Frame-to-Map', 'Frame-to-Frame']
                elif (key == 'Vis\MinInliers' or
                      key == 'Vis\CorGuessWinSize' or
                      key == 'Vis\CorNNDR' or 
                      key == 'Vis\InlierDistance'):
                    bw = 0.8

                param_name = ''.join(key.split('\\'))
                filename = prefix + param_name

                if not plot_dict.has_key(param_name+'_max'):
                    # create new plots
                    print(warningStr('Creating new plots!'))
                    p_max = plotting.GroupedPlot(bar_width=bw,
                                        x_ticks_rot=x_ticks_rotation,
                                        x_ticks_labels=x_ticks_labels)
                    p_max.filename = filename + '_est_max_err_y-axis'
                    p_max.out_path = path
                    p_max.x_axis_label = (u'Wartość parametru: "' +
                                          param_name + '"')
                    p_max.y_axis_label = u'Maks. błąd estymacji pozycji [m]'
                    plot_dict[param_name+'_max'] = p_max

                    p_mean = plotting.GroupedPlot(bar_width=bw,
                                        x_ticks_rot=x_ticks_rotation,
                                        x_ticks_labels=x_ticks_labels)
                    p_mean.filename = filename + '_est_mean_err_y-axis'
                    p_mean.out_path = path
                    p_mean.x_axis_label = (u'Wartość parametru: "' +
                                          param_name + '"')
                    p_mean.y_axis_label = u'Średni błąd estymacji pozycji [m]'
                    plot_dict[param_name+'_mean'] = p_mean

                    p_std = plotting.GroupedPlot(bar_width=bw, 
                                        x_ticks_rot=x_ticks_rotation,
                                        x_ticks_labels=x_ticks_labels)
                    p_std.filename = filename + '_est_stddev_err_y-axis'
                    p_std.out_path = path
                    p_std.x_axis_label = (u'Wartość parametru: "' +
                                          param_name + '"')
                    p_std.y_axis_label = (u'Odchylenie standardowe błędu ' + 
                                         'estymacji pozycji [m]')
                    plot_dict[param_name+'_std'] = p_std


                l_max = plotting.VerticalScatterLayer(list(), list(), 
                                    b.bag_filename, 
                                    plotting.getLightColour2(b_idx),
                                    plotting.getStyle2('x'))
                l_mean = plotting.VerticalScatterLayer(list(), list(), 
                                    b.bag_filename, 
                                    plotting.getLightColour2(b_idx),
                                    plotting.getStyle2('x'))
                l_std = plotting.VerticalScatterLayer(list(), list(), 
                                    b.bag_filename, 
                                    plotting.getLightColour2(b_idx),
                                    plotting.getStyle2('x'))
                    
                
                configs = group.getTestedConfigs()
                key_values = [utils.val2numeric(c[key])
                                for c in configs if c.has_key(key)]
                unique_values = utils.uniqueValues(key_values)
                # print(infoStr('key_values:'))
                # print key_values
                print(infoStr('unique_values:'))
                print unique_values
                # sort to preserve same order of parameter values
                unique_values.sort()
   
                l_max.x_data = unique_values
                l_mean.x_data = unique_values
                l_std.x_data = unique_values

                # Aggregate data such that each err value is registered to 
                # corresponding test's key_value
                max_y_data = dict()
                mean_y_data = dict()
                std_y_data = dict()

                for v in unique_values:
                    max_y_data[v] = list()
                    mean_y_data[v] = list()
                    std_y_data[v] = list()

                for t in group.results:
                    key_val = t.getConfig()[key]
                    if key_val not in max_y_data:
                        print(errorStr('key_val: ' + str(key_val) + 
                            ' not present in unique_values!!'))
                    # collect errors only in y-axis
                    max_y_data[key_val].append(t.getMax()[1])
                    mean_y_data[key_val].append(t.getMean()[1])
                    std_y_data[key_val].append(t.getStddev()[1])

                for v in unique_values:
                    print(infoStr('value: ' + str(v) + ', len(y_data): ' +
                                  str(len(max_y_data[v]))))
                    l_max.y_data.append(max_y_data[v])
                    l_mean.y_data.append(mean_y_data[v])
                    l_std.y_data.append(std_y_data[v])

                print(infoStr('Adding layer ' + l_max.label + 
                      ' to ' + param_name + '_max, ' + 'layers count: ' + 
                       str(len(plot_dict[param_name+'_max']._layers))))
                plot_dict[param_name+'_max'].addLayer(l_max)
                plot_dict[param_name+'_mean'].addLayer(l_mean)
                plot_dict[param_name+'_std'].addLayer(l_std)

        for p in plot_dict.values():
            p.plot()
            p.savePlot()
            p.clearPlot()

class ClosedLibAnalysis(TestResultsAnalysis):
    """Tools for closed source SLAM library test results analysis.
    
    Extends:
        TestResultsAnalysis
    """
    def __init__(self, trajectory_dir, stat_dir, output_dir):
        super(ClosedLibAnalysis, self).__init__(trajectory_dir, stat_dir,
                                            output_dir)

        self._bag_results = [gt_results.ClosedLibBagTestResult(
                                    b, trajectory_dir + '/' + b, 
                                    stat_dir + '/' + b)
                             for b in self._bagnames]
    # --------------------------------------------------------
    #   PUBLIC INTERFACE
    # --------------------------------------------------------
