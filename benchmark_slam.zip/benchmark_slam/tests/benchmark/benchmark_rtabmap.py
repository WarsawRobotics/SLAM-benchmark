#!/usr/bin/env python
# vim:fileencoding=utf-8

import sys
import multiprocessing as mp
import threading as thr
import subprocess

import tests.util.rtabmap_param_configurator as rpc
from benchmark import RtabBenchmark
import tests.util.colored_str as str_util

#-------------------------------------------------------------------------
#  GLOBAL VARIABLES & CONSTANTS
#-------------------------------------------------------------------------

MULTICORE = False

#-------------------------------------------------------------------------
#  HELPER METHODS
#-------------------------------------------------------------------------

def getDefaultCameraTestSetup():
    return RtabBenchmark('test_rtabmap_kinect.launch', 'base_config.ini')

def getDefaultBagTestSetup():
    bag_filename = 'kinect_v2_const_motion_fast_v2'
    rtab_cfg_filename = 'base_config.ini'
    launch_filename = 'test_rtabmap_bag.launch'
    run_rviz = False
    play_rate = 1
    play_bag = True
    ns = str(mp.current_process().pid)
    return RtabBenchmark(launch_filename, rtab_cfg_filename, bag_filename, 
                         play_bag, play_rate, run_rviz, ns)

#-------------------------------------------------------------------------
#  TESTS
#-------------------------------------------------------------------------

def testParams(parent_pid, bag_filename, launch_filename, rtab_cfg_filename,
               params, cfg_rlock):
    """Tests given parameters sets
    
    Arguments:
        parent_pid {int} -- [description]
        bag_filename {str} -- [description]
        launch_filename {str} -- [description]
        rtab_cfg_filename {str} -- [description]
        params {list} -- List of prameters sets to test.
    """
    cur_pid = mp.current_process().pid
    ns = str()
    if parent_pid != 0:
        ns += str(parent_pid) + '_'
    ns += str(cur_pid)
    t = RtabBenchmark(launch_filename, rtab_cfg_filename, bag_filename,
                      True, wrapper_ns=ns, cfg_rlock=cfg_rlock)
    for p in params:
        t.runTest(p)

def testParamsRanges(parent_pid, bag_filename, launch_filename, 
                     rtab_cfg_filename, params, base_set, cfg_rlock):
    """Tests given parameters value ranges,
    
    Arguments:
        parent_pid {int} -- [description]
        bag_filename {str} -- [description]
        launch_filename {str} -- [description]
        rtab_cfg_filename {str} -- [description]
        params {dict} -- Dict of prameters value ranges to test.
    """
    repeat_cnt = 10
    cur_pid = mp.current_process().pid
    ns = str()
    if parent_pid != 0:
        ns += str(parent_pid) + '_'
    ns += str(cur_pid)
    for k,v in params.iteritems():
        local_dir = k.replace('\\', '_')
        t = RtabBenchmark(launch_filename, rtab_cfg_filename, local_dir, 
                          bag_filename, True, wrapper_ns=ns, 
                          cfg_rlock=cfg_rlock)
        t.runTestParamRange(base_set, {k:v}, repeat_cnt)


def testBagMultProc(bags, launch_filename, rtab_cfg_filename, test_sets,
            nsubproc, cfg_rlock):
    pid = mp.current_process().pid
    for bag_filename in bags:
        print(str_util.infoStr('---------- test bag: ' + bag_filename))
        ns = str(pid)
        t = RtabBenchmark(launch_filename, rtab_cfg_filename, bag_filename, 
                          True, wrapper_ns=ns, cfg_rlock=cfg_rlock)
        # run default rtabmap configuration setup
        t.runTest({})

        subproc = list()
        chunksize = (len(test_sets) + nsubproc-1) / nsubproc
        for i in range(nsubproc):
            begin = i*chunksize
            end = (i+1)*chunksize
            if begin > len(test_sets):
                break
            if end > len(test_sets):
                end = len(test_sets)
            params = test_sets[begin:end]        
            args = (pid, bag_filename, launch_filename, rtab_cfg_filename, 
                    params, cfg_rlock)
            p = mp.Process(target=testParams, args=args)
            # daemonic processess cannot have child processess!
            p.daemon = False
            p.start()
            subproc.append(p)

        for s in subproc:
            s.join()


def testBagFilesMultProc(nproc, nsubproc):
    print(str_util.infoStr('-------- testBagFilesMultProc -----------'))

    rtab_cfg_filename = 'base_config.ini'
    launch_filename = 'test_rtabmap_bag.launch'
    bag_file_list = [
        'kinect_v2_const_motion_fast_v2',
        'kinect_v2_const_motion_med_v2',
        'kinect_v2_const_motion_slow_v2',
        'kinect_v2_jerky_motion_v2',
        'kinect_v2_sin_motion_v2',
    ]
    
    # generate set of all parameters configuration sets we want to test
    base_set = rpc.getParamSet(rpc.Kinect2CameraParams())
    param_range_val_set = rpc.getParamRangeSet()
    param_set_builder = rpc.ParamSetBuilder(base_set)
    param_set_builder.generate(param_range_val_set)
    test_sets = param_set_builder.getParamSets()

    shared_manager = mp.Manager()
    cfg_rlock = shared_manager.RLock()

    subproc = list()
    chunksize = (len(bag_file_list) + nproc-1) / nproc

    for i in range(nproc):
        begin = i*chunksize
        end = (i+1)*chunksize
        if begin > len(bag_file_list):
            break
        if end > len(bag_file_list):
            end = len(bag_file_list)
        bags = bag_file_list[begin:end]    
        args = (bags, launch_filename, rtab_cfg_filename, test_sets, nsubproc,
                cfg_rlock)
        p = mp.Process(target=testBagMultProc, args=args)
        # daemonic processess cannot have child processess!
        p.daemon = False
        subproc.append(p)

    for s in subproc:
        s.start()
    for s in subproc:
        s.join()


def testBagFiles():
    print(str_util.infoStr('-------- testBagFiles -----------'))

    rtab_cfg_filename = 'base_config.ini'
    launch_filename = 'test_rtabmap_bag.launch'
    bag_file_list = [
        'kinect_v2_const_motion_fast_v2',
        'kinect_v2_const_motion_med_v2',
        'kinect_v2_const_motion_slow_v2',
        'kinect_v2_jerky_motion_v2',
        'kinect_v2_sin_motion_v2',
    ]
    
    # generate set of all parameters configuration sets we want to test
    base_set = rpc.getParamSet(rpc.Kinect2CameraParams())
    param_range_val_set = rpc.getParamRangeSet()
    param_set_builder = rpc.ParamSetBuilder(base_set)
    param_set_builder.generate(param_range_val_set)
    test_sets = param_set_builder.getParamSets()

    for b in bag_file_list:
        print(str_util.infoStr('---------- test bag: ' + b))
        testParams(0, b, launch_filename, rtab_cfg_filename, test_sets, 
                    thr.RLock())

def testBagFilesV2():
    print(str_util.infoStr('-------- testBagFilesV2 -----------'))

    rtab_cfg_filename = 'base_config.ini'
    launch_filename = 'test_rtabmap_bag.launch'
    bag_file_list = [
        'kinect_v2_const_motion_fast_v2',
        'kinect_v2_const_motion_med_v2',
        'kinect_v2_const_motion_slow_v2',
        'kinect_v2_jerky_motion_v2',
        'kinect_v2_sin_motion_v2',
    ]
    
    # generate set of all parameters configuration sets we want to test
    base_set = rpc.getParamSet(rpc.Kinect2CameraParams())
    param_range_val_set = rpc.getParamRangeSet()

    for b in bag_file_list:
        print(str_util.infoStr('---------- test bag: ' + b))
        testParamsRanges(0, b, launch_filename, rtab_cfg_filename,
                         param_range_val_set, base_set, thr.RLock())


def testBasic():
    print(str_util.infoStr('-------- testBasic -----------'))
    t = getDefaultBagTestSetup()
    base_set = rpc.getParamSet()
    t.runTest(base_set)


def startRoscore(args):
    end_event = args
    cmd = 'roscore'
    print(str_util.infoStr('--------- starting roscore ----------'))
    roscore = subprocess.Popen(cmd)
    end_event.wait()
    print(str_util.infoStr('--------- stopping roscore ----------'))
    roscore.terminate()


#-------------------------------------------------------------------------
#  MAIN
#-------------------------------------------------------------------------

if __name__ == '__main__':
    if MULTICORE:
        bag_process_count = 1
        bag_subprocess_count = 4
        
        if len(sys.argv) >= 2:
            bag_process_count = int(sys.argv[1])
        if len(sys.argv) >= 3:
            bag_subprocess_count = int(sys.argv[2])

        end_event = thr.Event()
        roscore_thr = thr.Thread(target=startRoscore, args=(end_event,))
        roscore_thr.start()
        # make sure roscore started properly
        time.sleep(4)

        testBagFilesMultProc(bag_process_count, bag_subprocess_count)
        # testBasic()

        # notify roscore thread to stop
        end_event.set()
    else:
        testBagFilesV2()
        # testBasic()