#!/usr/bin/env python
# vim:fileencoding=utf-8

import sys
import multiprocessing as mp
import threading as thr
import subprocess
import time

from benchmark import ZEDfuBenchmark
import tests.util.colored_str as str_util


#-------------------------------------------------------------------------
#  GLOBAL CONSTANTS & VARIABLES
#-------------------------------------------------------------------------

ZEDFU_LAUNCHFILE = 'test_zedfu.launch'
USE_WRAPPER_NS = False

#-------------------------------------------------------------------------
#  TESTS
#-------------------------------------------------------------------------

def testOldBagFiles(repeat_cnt):
    print(str_util.infoStr('-------- testOldBagFiles -----------'))

    cur_pid = mp.current_process().pid
    launch_filename = ZEDFU_LAUNCHFILE
    bag_file_list = [
        'zed_sin_motion_v2',
        'zed_const_motion_fast_v2',
        'zed_const_motion_med_v2',
        'zed_const_motion_slow_v2',
        'zed_jerky_motion_v2',
    ]

    ns = str()
    if USE_WRAPPER_NS:
        ns = str(cur_pid)

    for b in bag_file_list:
        print(str_util.infoStr('---------- test bag: ' + b))
        t = ZEDfuBenchmark(launch_filename, b, True, wrapper_ns=ns)
        for i in range(repeat_cnt):
            t.runTest({'zed_odometry':True})

def testBasic():
    print(str_util.infoStr('-------- testBasic -----------'))
    cur_pid = mp.current_process().pid
    bag_filename = 'zed_sin_motion_v2'
    launch_filename = ZEDFU_LAUNCHFILE
    play_rate = 1
    play_bag = True

    ns = str()
    if USE_WRAPPER_NS:
        ns = str(cur_pid)

    t = ZEDfuBenchmark(launch_filename, bag_filename, play_bag, play_rate, 
                        wrapper_ns=ns)
    t.runTest({'zed_odometry':True})

def startRoscore(args):
    end_event = args
    cmd = 'roscore'
    print(str_util.infoStr('--------- starting roscore ----------'))
    roscore = subprocess.Popen(cmd)
    end_event.wait()
    print(str_util.infoStr('--------- stopping roscore ----------'))
    roscore.terminate()

#-------------------------------------------------------------------------
#  MAIN
#-------------------------------------------------------------------------

if __name__ == '__main__':
    repeat_count = 10
    if len(sys.argv) == 2:
        repeat_count = int(sys.argv[1])

    USE_WRAPPER_NS = True

    end_event = thr.Event()
    roscore_thr = thr.Thread(target=startRoscore, args=(end_event,))
    roscore_thr.start()
    # make sure roscore started properly
    time.sleep(4)
    # testBasic()
    testOldBagFiles(repeat_count)
    # notify roscore thread to stop
    end_event.set()
