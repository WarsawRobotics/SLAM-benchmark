#!/usr/bin/env python
# vim:fileencoding=utf-8

import argparse

import tests.test_results.analysis as analysis


if __name__ == '__main__':
    # parse command line
    parser = argparse.ArgumentParser(description='''This script loads test 
    results from different bag files (each in separate directory named of bag 
    file name), then computes some (hopefully) usefull statistics and draws 
    respective plots to visualize them.''')
    parser.add_argument('--t', help='Path to folder with trajectory files.')
    parser.add_argument('--s', help='Path to folder with statistics files.')
    parser.add_argument('--o', help='Path to folder where to save plots.')
    args = parser.parse_args()

    ra = analysis.ClosedLibAnalysis(args.t, args.s, args.o)
    ra.drawGeneralStat()

    # print trajectories
    for b in ra._bag_results:
        for g in b.groups.values():
            ra.drawTrajectories(g, b.bag_filename)
            ra.drawAlignedTrajectories(g, b.bag_filename)
