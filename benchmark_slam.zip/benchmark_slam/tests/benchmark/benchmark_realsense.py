#!/usr/bin/env python
# vim:fileencoding=utf-8

import sys
import multiprocessing as mp

from benchmark import RealSenseBenchmark
import tests.util.colored_str as str_util


#-------------------------------------------------------------------------
#  GLOBAL CONSTANTS & VARIABLES
#-------------------------------------------------------------------------

REALSENSE_LAUNCHFILE = 'test_librealsense_slam.launch'

#-------------------------------------------------------------------------
#  TESTS
#-------------------------------------------------------------------------

def testBagFiles(repeat_cnt, launch_filename, bag_file_list, params=dict()):
    print(str_util.infoStr('-------- testBagFiles -----------'))

    cur_pid = mp.current_process().pid
    ns = str(cur_pid)

    for b in bag_file_list:
        print(str_util.infoStr('---------- test bag: ' + b))
        t = RealSenseBenchmark(launch_filename, b, True, wrapper_ns=ns)
        for i in range(repeat_cnt):
            t.runTest(params)

def testBasic():
    print(str_util.infoStr('-------- testBasic -----------'))
    cur_pid = mp.current_process().pid
    bag_filename = 'rs_sdk_slam_cmd6_static_start'
    launch_filename = REALSENSE_LAUNCHFILE
    play_rate = 1
    play_bag = True
    ns = str(cur_pid)

    t = RealSenseBenchmark(launch_filename, bag_filename, play_bag, play_rate, 
                           wrapper_ns=ns)
    t.runTest()



#-------------------------------------------------------------------------
#  MAIN
#-------------------------------------------------------------------------

if __name__ == '__main__':
    repeat_count = 10
    if len(sys.argv) == 2:
        repeat_count = int(sys.argv[1])

    # launch_filename = REALSENSE_LAUNCHFILE
    launch_filename = 'octomap_realsense.launch'
    bag_file_list = [
        # 'rs_sdk_slam_cmd6_static_start',
        # 'rs_sdk_slam_cmd6_dynamic_start',
        # 'rs_sdk_slam_cmd2_static_start',
        # 'rs_sdk_slam_cmd3_static_start',
        # 'rs_sdk_slam_cmd7_static_start',
        # 'rs_sdk_slam_cmd7_dynamic_start',
        'rs_sdk_slam_room',
    ]

    params = {'trajectory_tracker':'true'}

    # testBasic()
    testBagFiles(repeat_count, launch_filename, bag_file_list, params)
    