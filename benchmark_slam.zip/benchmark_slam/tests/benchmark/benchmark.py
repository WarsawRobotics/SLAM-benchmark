# vim:fileencoding=utf-8

import os
import sys
import errno
import subprocess
import copy
import numpy as np

from datetime import datetime
from ConfigParser import SafeConfigParser, ParsingError
import threading as thr

from tests.util.json_logger import JsonLogger
import tests.util.colored_str as str_util

#-------------------------------------------------------------------------
#      'Benchmark' CLASS
#-------------------------------------------------------------------------
class Benchmark(object):
    """Base class for SLAM benchmarking classess.
    
    A class providing common functionality and interface for benchmarking 
    SLAM algorithms.
    
    """

    def __init__(self, launch_filename, bag_filename=str(),
                 play_bag=False, play_rate=1, wrapper_ns=str()):
        """Initialize and configure Benchmark class.
        
        Creates necessary directories, file paths and files.
        
        Arguments:
            launch_filename {str} -- ROS launch file, which runs all necessary
                                     nodes.

        Keyword Arguments:
            bag_filename {str} -- Name of file providing testing data. 
                                  (default: {str()})
            play_bag {bool}    -- Flag deciding of whether or not to play a bag 
                                  file, or to run a live test. 
                                  (default: {False})
            play_rate {number} -- Bag file play rate. 1 - original play rate. 
                                  (default: {1})
            wrapper_ns {str}   -- Optional wrapper namespace for nodes started 
                                  by used launch file. It is useful only for 
                                  concurrent processing of multiple benchmarks. 
                                  (default: {str()})
        """
        self.launch_filename_ = launch_filename
        self.bag_filename_ = bag_filename
        self.play_rate_ = play_rate
        self.play_bag_ = play_bag
        self.wrapper_ns_ = wrapper_ns

        # paths relative to tests/ dir
        self._STAT_DIR = '/../data/stats'
        self._TRAJ_DIR = '/../data/trajectories'
        self._setLogFilePath()
        self._createLogDirectories()
        
    #-------------------------------------------------------------------------
    #      'PRIVATE' METHODS
    #-------------------------------------------------------------------------
    def _setLogFilePath(self):
        print(str_util.infoStr('Benchmark._setLogFilePath'))
        self._cfg_stat_log_filename = (self.bag_filename_ + '_' +
                                       self.wrapper_ns_ + '_cfg_stat.log')
        self._cfg_stat_log_file_path = (self._getTestsDirPath() + 
                                        self._STAT_DIR + '/' +
                                        self.bag_filename_ + '/' + 
                                        self._cfg_stat_log_filename)

    def _createLogDirectories(self):
        try:
            os.makedirs(os.path.dirname(self._cfg_stat_log_file_path))
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise

        if not os.path.exists(self._cfg_stat_log_file_path):
            with open(self._cfg_stat_log_file_path, 'a+') as f:
                f.write('{}')

    def _getCommand(self, fsuffix):
        # cmd = ('/usr/bin/xterm -e roslaunch benchmark_slam ' + 
        cmd = ('roslaunch benchmark_slam ' + 
                self.launch_filename_ +  ' play_bag:=' +
               str(self.play_bag_) + ' bag_filename:=' + self.bag_filename_ +
               ' play_rate:=' + str(self.play_rate_) +
               ' filename_suffix:=' + fsuffix + ' wrapper_ns:=' + 
               self.wrapper_ns_ + ' cfg_stat_log_filename:=' + 
               self._cfg_stat_log_filename)
        return cmd

    def _getTimestamp(self):
        now = datetime.now()
        timestamp = '{0:d}{1:02d}{2:02d}{3:02d}{4:02d}{5:02d}'.format(
            now.year, now.month, now.day, now.hour, now.minute, now.second)
        return timestamp

    def _getTestsDirPath(self):
        # At the moment we're under tests/benchmark/ directory, so we must
        # go up one dir
        path = os.path.dirname(os.path.abspath(__file__)) + '/..'
        return path

    def _createCfgStatLogEntry(self, key, cfg, stat):
        """Creates an entry inside stat dictionary with key and (cfg, stat)
        
        Create an antry inside results dictionary log file. We have to 
        beforehand create such an entry, in order to enable ros nodes to fill 
        it with results data. Data are in JSON format. 
        
        Arguments:
            key {str} -- Entry identificator: timestamp.
            cfg {dict} -- Test configuration. Place for additional parameters.
            stat {dict} -- Estimation error statistics in form of dictionary. 
                            Keys are metrics (min, max etc.) and objects, are 
                            list of values.
        """
        with JsonLogger(self._cfg_stat_log_file_path) as slogfile:
            slogfile.addTestEntry(key, cfg, stat)


    #-------------------------------------------------------------------------
    #      'PUBLIC' METHODS
    #-------------------------------------------------------------------------
    def runTest(self, cmd):
        """
          Run single test
        """
        try:
            subprocess.check_call(cmd.split())
        except subprocess.CalledProcessError as e:
            print(str_util.criticalStr('Command "' + ' '.join(e.cmd) + 
                  '" failed with returned ' + 'code: ' + str(e.returncode) + 
                  '. Exiting!'))
            return

#-------------------------------------------------------------------------
#      'RtabBenchmark' CLASS
#-------------------------------------------------------------------------

class RtabBenchmark(Benchmark):
    """
      RtabBenchmark is a class providing tools for benchmarking RtabMap
      application SLAM accuracy, with respect to its parameter configuration.
    """

    def __init__(self, launch_filename, cfg_filename, local_dir=str(),
                 bag_filename=str(), play_bag=False, play_rate=1, 
                 run_rviz=False, wrapper_ns=str(), cfg_rlock=thr.RLock()):
        """Constructor

        Arguments:
            launch_filename {str} -- ROS launch file, which runs all necessary
                                     nodes.
            cfg_filename {[type]} -- Name of file containing base parameters 
                                     configuration.
        
        Keyword Arguments:
            local_dir {str}    -- Name of subdirectory for storing results
                                  (default: {str()})
            bag_filename {str} -- Name of file providing testing data. 
                                  (default: {str()})
            play_bag {bool}    -- Flag deciding of whether or not to play a 
                                  bag file, or to run a live test. 
                                  (default: {False})
            play_rate {number} -- Bag file play rate. 1 - original play rate. 
                                  (default: {1})
            run_rviz {bool}    -- Wheter or not to launch a rviz instance.
                                  (default: {False})
            wrapper_ns {str}   -- Optional wrapper namespace for nodes started 
                                  by used launch file. It is useful only for 
                                  concurrent processing of multiple 
                                  benchmarks. (default: {str()})
            cfg_rlock {threading.RLock} -- Lock synchronizing access to 
                                           configuration  & stat file. Usefull 
                                           only with concurrent processing of 
                                           multiple benchmarks. 
                                           (default: {thr.RLock()})
        """
        self._LOCAL_DIR = local_dir
        self.RTAB_CORE_SECTION_ = 'Core'
        self._CONF_DIR = 'config/rtab_param'
        
        super(RtabBenchmark, self).__init__(
                launch_filename, bag_filename, play_bag, play_rate, wrapper_ns)
        self.rviz_ = run_rviz
        self._cfg_rlock = cfg_rlock
        self._base_cfg_filename = cfg_filename
        self._loadConfigFile(self._base_cfg_filename)

    #-------------------------------------------------------------------------
    #      'PRIVATE' METHODS
    #-------------------------------------------------------------------------

    def _loadConfigFile(self, cfg_filename):
        config_file_path = self._getConfigFilePath(cfg_filename)
        if os.path.exists(config_file_path):
            self.config_ = SafeConfigParser()
            # Change default function, which converts all input parameters to
            # lowercase letters, into simply `str`, to become case sensitive, 
            # because RtabMap parameters are case sensitive!
            self.config_.optionxform = str
            self._cfg_rlock.acquire()
            with open(config_file_path, 'r') as f:
                self.config_.readfp(f, cfg_filename)
            self._cfg_rlock.release()
        else:
            raise ValueError('Couldn\'t find configuration file!' + 
                  config_file_path + ' Exiting!')

    def _setLogFilePath(self):
        self._cfg_stat_log_filename = (self.bag_filename_ + '_' +
                                       self.wrapper_ns_ + '_cfg_stat.log')
        # add local directory
        self._cfg_stat_log_file_path = (self._getTestsDirPath() + 
                                        self._STAT_DIR + '/' +
                                        self.bag_filename_ + '/' + 
                                        self._LOCAL_DIR + '/' +
                                        self._cfg_stat_log_filename)


    def _getConfigFilePath(self, cfg_filename):
        path = self._getTestsDirPath()
        # We assume we are under tests/ directory and config files, are under
        # config/ directory, so we need to move back one time and step into
        # config/
        path += '/../config/' + cfg_filename
        return path

    def _getCommand(self, fsuffix, cfg_filename):
        # cmd = ('roslaunch benchmark_slam ' + 
        cmd = super(RtabBenchmark, self)._getCommand(fsuffix)
        cmd += (' run_rviz:=' + str(self.rviz_) + 
                ' rtab_cfg_filename:=' + cfg_filename + 
                ' rtab_cfg_dir:=' + self._CONF_DIR + '/' + self.bag_filename_ +
                '/' + self._LOCAL_DIR +
                ' local_dir:=' + self._LOCAL_DIR)
        return cmd

    def _storeConfiguration(self, filename):
        path = self._getTestsDirPath()
        path += ('/../' + self._CONF_DIR + '/' + self.bag_filename_ + '/' + 
                self._LOCAL_DIR + '/')
        # We assume we are under tests/ directory and config files, are under
        # config/ directory, so we need to move back one time and step into
        # config/
        try:
            os.makedirs(path)
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise
        path += filename
        with open(path, 'w') as f:
            self.config_.write(f)

    #-------------------------------------------------------------------------
    #      'PUBLIC' METHODS
    #-------------------------------------------------------------------------

    def setKeyValue(self, key, val):
        if self.config_.has_option(self.RTAB_CORE_SECTION_, key):
            self.config_.set(self.RTAB_CORE_SECTION_, key, str(val))
        else:
            raise ValueError('Couldn\'t find "' + key + '" key in config ' +
                  'file under "' + self.RTAB_CORE_SECTION_ + '" section!')

    def runTest(self, params, repeat_cnt=1):
        """
          Run single test for currently stored configuration
        """
        # reload default parameters
        try:
            self._loadConfigFile(self._base_cfg_filename)
        except ParsingError as e:
            print(str_util.errorStr(str(e.args[0])))
            return
        except ValueError as e:
            print(str(e.args[0]))
            return

        try:
            for k, v in params.iteritems():
                self.setKeyValue(k, v)
        except ValueError as e:
            print(str_util.warningStr(str(e.args[0])))
            return
            
        for i in range(repeat_cnt):
            fsuffix = self._getTimestamp()
            config_filename = str()

            if self.play_bag_:
                config_filename += self.bag_filename_ + '_'
            config_filename += fsuffix + '_' + self.wrapper_ns_ + '_rtab_config.ini'

            self._createCfgStatLogEntry(fsuffix, params, {})
            self._storeConfiguration(config_filename)

            cmd = self._getCommand(fsuffix, config_filename)
            super(RtabBenchmark, self).runTest(cmd)

    def runTestParamRange(self, base_param_set, key_values, repeat_cnt=1):
        """
          Run multiple tests. Firstly basic configuration as in base_param_set 
          is setup. Then the test is run for each entry in key_values 
          dictonary, where key is a parameter to test, and value is a tuple 
          (min, max, step) where min is inclusive and max is exclusive.
        """
        for key, (minv, maxv, step) in key_values.iteritems():
            print '------ test param key: %s' % key
            for v in np.arange(minv, maxv, step):
                ps = copy.deepcopy(base_param_set)
                ps[key] = v
                # print '------ test value: ' + str(v)
                self.runTest(ps, repeat_cnt)

#-------------------------------------------------------------------------
#      'ZEDfuBenchmark' CLASS
#-------------------------------------------------------------------------

class ZEDfuBenchmark(Benchmark):
    """Class supervising benchmarking of ZEDfu algorithm"""

    def __init__(self, launch_filename, bag_filename=str(), play_bag=False, 
                 play_rate=1, wrapper_ns=str()):
        super(ZEDfuBenchmark, self).__init__(launch_filename, bag_filename, 
                                            play_bag, play_rate, wrapper_ns)

    def runTest(self, params):
        """
          Run single test for currently stored configuration
        """
        fsuffix = self._getTimestamp()
        self._createCfgStatLogEntry(fsuffix, params, dict())
        super(ZEDfuBenchmark, self).runTest(self._getCommand(fsuffix, params))

    def _getCommand(self, fsuffix, params):
        cmd = super(ZEDfuBenchmark, self)._getCommand(fsuffix)
        cmd += (' save_trajectory:=true' +
                ' run_rtabmap:=' + str(not params['zed_odometry']) +
                ' use_zed_odometry:=' + str(params['zed_odometry']))
        return cmd
 

#-------------------------------------------------------------------------
#      'KinfuBenchmark' CLASS
#-------------------------------------------------------------------------

class KinfuBenchmark(Benchmark):
    """Class supervising benchmarking of Kinfu algorithm"""

    def __init__(self, launch_filename, bag_filename=str(), play_bag=False, 
                 play_rate=1, wrapper_ns=str()):
        super(KinfuBenchmark, self).__init__(launch_filename, bag_filename, 
                                            play_bag, play_rate, wrapper_ns)

    def runTest(self, params=dict()):
        """
          Run single test for currently stored configuration
        """
        fsuffix = self._getTimestamp()
        self._createCfgStatLogEntry(fsuffix, params, dict())
        super(KinfuBenchmark, self).runTest(self._getCommand(fsuffix, params))

    def _getCommand(self, fsuffix, params):
        cmd = super(KinfuBenchmark, self)._getCommand(fsuffix)
        cmd += (' save_trajectory:=true')
        for k,v in params.iteritems():
            cmd += ' ' + str(k) + ':=' + str(v)
        return cmd

#-------------------------------------------------------------------------
#      'RealSenseBenchmark' CLASS
#-------------------------------------------------------------------------

class RealSenseBenchmark(Benchmark):
    def __init__(self, launch_filename, bag_filename=str(), play_bag=False, 
                 play_rate=1, wrapper_ns=str()):
        super(RealSenseBenchmark, self).__init__(launch_filename, bag_filename,
                                                 play_bag, play_rate,
                                                 wrapper_ns)

    def runTest(self, params=dict()):
        """
          Run single test for currently stored configuration
        """
        fsuffix = self._getTimestamp()
        self._createCfgStatLogEntry(fsuffix, params, dict())
        super(RealSenseBenchmark, self).runTest(self._getCommand(fsuffix,
                                                params))

    def _getCommand(self, fsuffix, params):
        cmd = super(RealSenseBenchmark, self)._getCommand(fsuffix)
        cmd += (' save_trajectory:=true')
        for k,v in params.iteritems():
            cmd += ' ' + str(k) + ':=' + str(v)
        return cmd