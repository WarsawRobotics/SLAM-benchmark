#!/usr/bin/env python
# vim:fileencoding=utf-8

import unittest
import tests.util.rtabmap_param_configurator as rpc

#-------------------------------------------------------------------------
#  TESTS
#-------------------------------------------------------------------------

class TestParamSetBuilder(unittest.TestCase):
    """docstring for TestParamSetBuilder"""

    def setUp(self):
        base_param_set = {
            'aaa':1,
            'bbb':2,
            'ccc':3,
            'ddd':4,
            'eee':5,
        }
        self._psb = rpc.ParamSetBuilder(base_param_set)

    def testRangeSet1(self):
        param_range_set = {
            'a2':(0,4,1),
            'b2':(0.1,0.5,0.1),
        }
        self._psb.generate(param_range_set)
        ps = self._psb.getParamSets()
        
        self.assertEqual(len(ps), 1281)

    def testEmptyRangeVal(self):
        param_range_set = dict()
        self._psb.generate(param_range_set)
        ps = self._psb.getParamSets()
        
        self.assertEqual(len(ps), 161)

    def testDuplicates(self):
        param_range_set = {
            'a2':(0,4,1),
            'b2':(0.1,0.5,0.1),
        }
        self._psb.generate(param_range_set)
        ps = self._psb.getParamSets()

        for s in ps:
            self.assertEqual(ps.count(s), 1)

    def testHugeSet(self):
        param_range_set = rpc.getParamRangeSet()
        self._psb.generate(param_range_set)
        ps = self._psb.getParamSets()
        for s in ps:
            self.assertEqual(ps.count(s), 1)        

#-------------------------------------------------------------------------
#  MAIN
#-------------------------------------------------------------------------

if __name__ == '__main__':
    unittest.main()