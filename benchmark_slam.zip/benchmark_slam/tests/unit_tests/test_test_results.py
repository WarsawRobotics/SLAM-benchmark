#!/usr/bin/env python
# vim:fileencoding=utf-8

import os
import unittest
import random
import time
import math
import numpy as np
import json
import re

from datetime import datetime

import tests.test_results.results as tresults
from tests.util.json_stat_parser import JSONStatParser
from tests.test_results.pose import Pose

#-------------------------------------------------------------------------
#  TESTS
#-------------------------------------------------------------------------


class TestTestResult(unittest.TestCase):


    def setUp(self):
        self.test_id = '20170811173241_2435_10522'
        self.time_offset = 0.0
        self.time_window = 0.45
        cur_dir = os.path.dirname(os.path.abspath(__file__))
        self.trajectory_file_path = cur_dir + 'ut_trajectory_file.txt'
        self.trajectory_samples_count = 100
        self.trajectory_file = self._genTrajectoryFile(
                                                self.trajectory_file_path,
                                                0.1, self.time_window * 0.7,
                                                self.trajectory_samples_count)
        self.trajectory_file.close()
        config = {
            "Group1\\Param1": 0.0,
            "Group1\\Param2": -0.1,
            "Group2\\Param1": "false",
            "Group2\\Param2": "true",
            "Group3\\Param1": 2,
        }
        stat = {
            "min":    [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, ],
            "max":    [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, ],
            "mean":   [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, ],
            "median": [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, ],
            "stddev": [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, ],
        }
        self.cfg_stat = (config, stat)
        self.config_file_path = cur_dir + 'ut_full_cfg.ini'

    def _genTrajectoryFile(self, filepath, pos_sigma, t_sigma, n_entries):
        # import tf
        f = open(filepath, 'w')

        gndt_time_start = time.time()

        gndt_preffix = '[gndt]'
        odom_preffix = '[odom]'
        phase_offset = -(math.pi / 2.0)
        a = 0.04
        omega = 0.55
        y_offset = 0.04
        v_offset = 0.0

        for k in range(1, n_entries+1):
            gndt_t = gndt_time_start + k * self.time_window * 3.0
            t = gndt_t - gndt_time_start
            y = a * math.sin(omega * t + phase_offset)
            v = a * omega * math.cos(omega * t + phase_offset) * 1.1
            k = 10000
            y = (y + y_offset) * k
            v = math.fabs(v) * k + v_offset
            # timestamp x y z qx qy qz qw velocity
            x, z = 0.0, 0.0
            qx, qy, qz, = 0.0, 0.0, 0.0
            qw = 1.0
            gndt_line = ('{0: .4f} {1: .4f} {2: .4f} {3: .4f} {4: .4f}'
                         ' {5: .4f} {6: .4f} {7: .4f} {8: .4f}').format(
                        gndt_t, x, y, z, qx, qy, qz, qw, v)
            f.write(gndt_preffix + '\t' + gndt_line + '\n')
            odom_t = gndt_t + random.uniform(0, t_sigma)
            # add some noise to odom position
            mu = 0.0
            x += random.gauss(mu, pos_sigma)
            y += random.gauss(mu, pos_sigma)
            z += random.gauss(mu, pos_sigma)
            # ax, ay, az = (random.gauss(mu, pos_sigma) for k in range(3))
            # q = tf.transformations.quaternion_from_euler(float(ax),
            #                             float(ay), float(az))
            # qx = q[0]
            # qy = q[1]
            # qz = q[2]
            # qw = q[3]
            odom_line = ('{0: .4f} {1: .4f} {2: .4f} {3: .4f} {4: .4f}'
                         ' {5: .4f} {6: .4f} {7: .4f}').format(
                         odom_t, x, y, z, qx, qy, qz, qw)
            f.write(odom_preffix + '\t' + odom_line + '\n')

        return f

    def tearDown(self):
        os.remove(self.trajectory_file_path)

    def testCorrectData(self):
        rm_tr = tresults.RtabmapTestResult(self.test_id,
                                 self.trajectory_file_path, self.cfg_stat, 
                                 self.config_file_path,
                                 time_offset=self.time_offset,
                                 time_window=self.time_window)

        zf_tr = tresults.ZEDfuTestResult(self.test_id,
                                 self.trajectory_file_path, self.cfg_stat, 
                                 time_offset=self.time_offset,
                                 time_window=self.time_window)

        # RtabMap
        self.assertEqual(len(rm_tr._gndt_trajectory),
                         self.trajectory_samples_count)
        self.assertEqual(len(rm_tr._est_trajectory),
                         self.trajectory_samples_count)
        for gp, ep in zip(rm_tr._gndt_trajectory, rm_tr._est_trajectory):
            self.assertLessEqual(abs(gp.time - ep.time), self.time_window)

        # ZEDfu
        self.assertEqual(len(zf_tr._gndt_trajectory),
                         self.trajectory_samples_count)
        self.assertEqual(len(zf_tr._est_trajectory),
                         self.trajectory_samples_count)
        for gp, ep in zip(zf_tr._gndt_trajectory, zf_tr._est_trajectory):
            self.assertLessEqual(abs(gp.time - ep.time), self.time_window)

    def testNoisyData(self):
        self.trajectory_file = self._genTrajectoryFile(
            self.trajectory_file_path,
            0.1, self.time_window * 1.5,
            self.trajectory_samples_count)
        self.trajectory_file.close()

        rm_tr = tresults.RtabmapTestResult(self.test_id,
                                 self.trajectory_file_path, self.cfg_stat, 
                                 self.config_file_path,
                                 time_offset=self.time_offset,
                                 time_window=self.time_window)

        zf_tr = tresults.ZEDfuTestResult(self.test_id,
                                 self.trajectory_file_path, self.cfg_stat, 
                                 time_offset=self.time_offset,
                                 time_window=self.time_window)

        # RtabMap
        self.assertLess(len(rm_tr._gndt_trajectory),
                        self.trajectory_samples_count)
        self.assertLess(len(rm_tr._est_trajectory),
                        self.trajectory_samples_count)
        for gp, ep in zip(rm_tr._gndt_trajectory, rm_tr._est_trajectory):
            self.assertLessEqual(abs(gp.time - ep.time), self.time_window)

        # ZEDfu
        self.assertLess(len(zf_tr._gndt_trajectory),
                        self.trajectory_samples_count)
        self.assertLess(len(zf_tr._est_trajectory),
                        self.trajectory_samples_count)
        for gp, ep in zip(zf_tr._gndt_trajectory, zf_tr._est_trajectory):
            self.assertLessEqual(abs(gp.time - ep.time), self.time_window)

    def testCorruptedData(self):
        self.trajectory_file = self._genTrajectoryFile(
            self.trajectory_file_path,
            0.1, self.time_window * 0.7,
            self.trajectory_samples_count)
        self.trajectory_file.close()
        with open(self.trajectory_file_path, 'r+') as f:
            lines = f.readlines()

            lines[10] = ('[gndt] ' + str(time.time()) + '\n')
            lines[11] = ('[gndt] ' + str(time.time()) +
                         ' 1.1 2.2 3.3 4.4 5.5 6.6 7.7' + '\n')
            lines[12] = ('[gndt] ' + str(time.time()) +
                         ' 1.1 2.2 3.3 4.4 5.5 6.6 7.7 8.8 9.9' + '\n')
            lines[13] = (' gndt  ' + str(time.time()) +
                         ' 1.1 2.2 3.3 4.4 5.5 6.6 7.7 8.8' + '\n')
            lines[14] = ('[gn    ' + str(time.time()) +
                         ' 1.1 2.2 3.3 4.4 5.5 6.6 7.7 8.8' + '\n')
            lines[15] = (' aaaa  ' + str(time.time()) +
                         ' 1.1 2.2 3.3 4.4 5.5 6.6 7.7 8.8' + '\n')
            lines[16] = (str(time.time()) +
                         ' 1.1 2.2 3.3 4.4 5.5 6.6 7.7 8.8' + '\n')
            lines[17] = ('[odom] ' + str(time.time()) + '\n')
            lines[18] = ('[odom] ' + str(time.time()) +
                         ' 1.1 2.2 3.3 4.4 5. 6. 7.7' + '\n')
            lines[19] = ('[odom] ' + str(time.time()) +
                         ' 1.1 2.2 3.3 4.4 5.5 6.6 7.7 8.8 9.9' + '\n')
            lines[20] = ('[od    ' + str(time.time()) +
                         ' 1.1 2.2 3.3 4.4 5.5 6.6 7.7' + '\n')
            lines[21] = (' odom  ' + str(time.time()) +
                         ' 1.1 2.2 3.3 4.4 5.5 6.6 7.7' + '\n')
            lines[22] = (' aaaa  ' + str(time.time()) +
                         ' 1.1 2.2 3.3 4.4 5.5 6.6 7.7' + '\n')
            lines[23] = (str(time.time()) +
                         ' 1.1 2.2 3.3 4.4 5.5 6.6 7.7' + '\n')

            f.seek(0)
            f.truncate()
            for k in lines:
                f.write(k)
            f.flush()

        rm_tr = tresults.RtabmapTestResult(self.test_id,
                                 self.trajectory_file_path, self.cfg_stat, 
                                 self.config_file_path,
                                 time_offset=self.time_offset,
                                 time_window=self.time_window)

        zf_tr = tresults.ZEDfuTestResult(self.test_id,
                                 self.trajectory_file_path, self.cfg_stat, 
                                 time_offset=self.time_offset,
                                 time_window=self.time_window)

        # RtabMap
        self.assertEqual(len(rm_tr._gndt_trajectory),
                         self.trajectory_samples_count - 14/2)
        self.assertEqual(len(rm_tr._est_trajectory),
                         self.trajectory_samples_count - 14/2)
        for gp, ep in zip(rm_tr._gndt_trajectory, rm_tr._est_trajectory):
            self.assertLessEqual(abs(gp.time - ep.time), self.time_window)

        # ZEDfu
        self.assertEqual(len(zf_tr._gndt_trajectory),
                         self.trajectory_samples_count - 14/2)
        self.assertEqual(len(zf_tr._est_trajectory),
                         self.trajectory_samples_count - 14/2)
        for gp, ep in zip(zf_tr._gndt_trajectory, zf_tr._est_trajectory):
            self.assertLessEqual(abs(gp.time - ep.time), self.time_window)


class TestBagTestResult(unittest.TestCase):

    def setUp(self):
        self.bag_filename = 'dummy_bag'
        self.trajectory_files_dir = 'ut_dummy_dir/trajectories'
        self.config_files_dir = 'ut_dummy_dir/config'
        self.stat_files_dir = 'ut_dummy_dir/stat'

        self.re_timestamp = ('\d{4}((0[1-9])|(1[0-2]))((0[1-9])|([1,2]\d)|' +
                             '(3[0,1]))(([0,1]\d)|(2[0-3]))([0-5]\d){2}')

        self.re_pid_pid = '_\d+(_\d+)?'

        os.makedirs(self.trajectory_files_dir)
        os.makedirs(self.config_files_dir)
        os.makedirs(self.stat_files_dir)

        self.entries_count = 30
        tnow = datetime.now()
        timestamps = [('{0:04d}{1:02d}{2:02d}{3:02d}{4:02d}{5:02d}').format(
            tnow.year, tnow.month, tnow.day,
            tnow.hour, k, tnow.second)
            for k in range(self.entries_count)]
        pids = ['1234', '1234_56789', '1234_9876', '1234_12331']

        stat_file_suffix = 'cfg_stat.log'
        trajectory_file_suffix = 'trajectory.txt'
        config_file_suffix = 'rtab_config.ini'

        self.trajectory_file_paths = self._genTrajectoryFiles(timestamps, pids,
                                                      trajectory_file_suffix)
        self.config_file_paths = self._genConfigFiles(timestamps, pids,
                                                      config_file_suffix)
        self.stat_file_paths = self._genStatFiles(timestamps, pids,
                                                  stat_file_suffix)

    def _genTrajectoryFiles(self, timestamps, pids, file_suffix):
        """Generate a list of trajectory file paths, as well as creates those 
        files.

        File name syntax:
        $timestamp_$pids_$file_suffix,
        where:
            timestamp -- YYYYMMDDHHMMSS
            pids -- pid[_pid], where pid is a 4-5 digit number
            file_suffix -- 'trajectory.txt'

        Arguments:
            timestamps {list} -- List containing timestamps for respective 
                                 entries.
            pids {list} -- List of pid identificators. Determines number of 
                           subprocessess.
            file_suffix {str} -- Each file name suffix (with file extension).
        """
        file_paths = list()
        for i, t in enumerate(timestamps):
            idx = i % len(pids)
            path = (self.trajectory_files_dir + '/' + t + '_' + pids[idx] +
                    '_' + file_suffix)
            f = open(path, 'w')
            self._genTrajectoryFileContent(f)
            f.close()
            file_paths.append(path)
        return file_paths

    def _genTrajectoryFileContent(self, file, n_entries=100):
        # import tf
        import time
        import math

        time_window = 0.45
        pos_sigma = 0.1
        t_sigma = time_window * 0.7
        gndt_time_start = time.time()

        gndt_preffix = '[gndt]'
        odom_preffix = '[odom]'
        phase_offset = -(math.pi / 2.0)
        a = 0.04
        omega = 0.55
        y_offset = 0.04
        v_offset = 0.0

        for k in range(1, n_entries+1):
            gndt_t = gndt_time_start + k * time_window * 3.0
            t = gndt_t - gndt_time_start
            y = a * math.sin(omega * t + phase_offset)
            v = a * omega * math.cos(omega * t + phase_offset) * 1.1
            k = 10000
            y = (y + y_offset) * k
            v = math.fabs(v) * k + v_offset
            # timestamp x y z qx qy qz qw velocity
            x, z = 0.0, 0.0
            qx, qy, qz, = 0.0, 0.0, 0.0
            qw = 1.0
            gndt_line = ('{0: .4f} {1: .4f} {2: .4f} {3: .4f} {4: .4f}'
                         ' {5: .4f} {6: .4f} {7: .4f} {8: .4f}').format(
                        gndt_t, x, y, z, qx, qy, qz, qw, v)
            file.write(gndt_preffix + '\t' + gndt_line + '\n')
            odom_t = gndt_t + np.random.uniform(0, t_sigma)
            # add some noise to odom position
            mu = 0.0
            x += np.random.normal(mu, pos_sigma)
            y += np.random.normal(mu, pos_sigma)
            z += np.random.normal(mu, pos_sigma)
            # ax, ay, az = (np.random.normal(mu, pos_sigma) for k in range(3))
            # q = tf.transformations.quaternion_from_euler(float(ax),
            #                             float(ay), float(az))
            # qx = q[0]
            # qy = q[1]
            # qz = q[2]
            # qw = q[3]
            odom_line = ('{0: .4f} {1: .4f} {2: .4f} {3: .4f} {4: .4f}'
                         ' {5: .4f} {6: .4f} {7: .4f}').format(
                         odom_t, x, y, z, qx, qy, qz, qw)
            file.write(odom_preffix + '\t' + odom_line + '\n')
        file.flush()

    def _genConfigFiles(self, timestamps, pids, file_suffix):
        """Generate a list of configuration file paths, as well as creates those
        files.

        File name syntax:
            [_]$bagname_$timestamp_[$pids]_$file_suffix,
        where:
            bag_name -- Name of the respective bag file (without .bag suffix)
            timestamp -- YYYYMMDDHHMMSS
            pids -- pid[_pid], where pid is a 4-5 digit number
            file_suffix -- 'rtab_config.ini'

        Arguments:
            timestamps {list} -- List containing timestamps for respective 
                                 entries.
            pids {list} -- List of pid identificators. Determines number of 
                           subprocessess.
            file_suffix {str} -- Each file name suffix (with file extension).
        """
        file_paths = list()
        for i, t in enumerate(timestamps):
            idx = i % len(pids)
            path = (self.config_files_dir + '/' + self.bag_filename + '_' +
                    t + '_' + pids[idx] + '_' + file_suffix)
            f = open(path, 'w')
            f.close()
            file_paths.append(path)
        return file_paths

    def _genStatFiles(self, timestamps, pids, file_suffix):
        """Generates a list of statistics file paths, as well as creates 
        those files.

        File name syntax:
            $bag_name_$pids_$file_suffix,
        where:
            bag_name -- Name of the respective bag file (without .bag suffix)
            pids -- pid[_pid], where pid is a 4-5 digit number
            file_suffix -- 'cfg_stat.log'

        Arguments:
            timestamps {list} -- List containing timestamps for respective 
                                 entries.
            pids {list} -- List of pid identificators. Determines number of 
                           subprocessess.
            file_suffix {str} -- Each file name suffix (with file extension).
        """
        stat_files = dict()
        for i, t in enumerate(timestamps):
            pidx = i % len(pids)
            path = (self.stat_files_dir + '/' + self.bag_filename + '_' +
                    pids[pidx] + '_' + file_suffix)
            if not stat_files.has_key(path):
                stat_files[path] = dict()
            stat_files[path][t] = self._genStatFileContent()

        for p in stat_files.keys():
            with open(p, 'w+') as f:
                json.dump(stat_files[p], f, indent=2, separators=(',', ': '),
                          sort_keys=True)
                f.flush()
        return stat_files.keys()

    def _genStatFileContent(self):
        config = {
            "Group1\\Param1": np.random.random_sample(),
            "Group1\\Param2": np.random.random_sample()-1,
            "Group2\\Param1": "false",
            "Group2\\Param2": "true",
            "Group3\\Param1": 2*np.random.random_sample()+1,
        }
        stat = {
            "min":    list(np.random.rand(7)),
            "max":    list(np.random.rand(7)),
            "mean":   list(np.random.rand(7)),
            "median": list(np.random.rand(7)),
            "stddev": list(np.random.rand(7)),
        }
        return [config, stat]

    def tearDown(self):
        for k in self.trajectory_file_paths:
            os.remove(k)
        for k in self.config_file_paths:
            os.remove(k)
        for k in self.stat_file_paths:
            os.remove(k)

        os.removedirs(self.trajectory_files_dir)
        os.removedirs(self.config_files_dir)
        os.removedirs(self.stat_files_dir)

    def _testPathsGenerators(self):
        print '------------ trajectory files ----------------'
        for k in self.trajectory_file_paths:
            print k
        print '------------ config files ----------------'
        for k in self.config_file_paths:
            print k
        # print '------------ stat files ----------------'
        # for k in self.stat_file_paths:
        #     print k
        #     with open(k, 'r') as f:
        #         lines = f.readlines()
        #         for l in lines:
        #             print l
        # print '- - - - - - - - - - - - - - - - - - - - - - - - - - - -'

    def testMatches(self):
        tpaths = list(self.trajectory_file_paths)
        cpaths = list(self.config_file_paths)
        spaths = list(self.stat_file_paths)

        self.assertEqual(len(tpaths), self.entries_count)
        self.assertEqual(len(cpaths), self.entries_count)

        stat_data = JSONStatParser.parseBagData(self.stat_files_dir,
                                                self.bag_filename)
        self.assertEqual(len(stat_data), self.entries_count)

        matches_count = 0
        dd = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        rm_btr = tresults.RtabmapBagTestResult('bag', dd, dd, dd)
        zf_btr = tresults.ZEDfuBagTestResult('bag', dd, dd)

        for r in rm_btr._matches(tpaths, stat_data, cpaths):
            self.assertRegexpMatches(r[0], self.re_timestamp)
            self.assertRegexpMatches(r[1], self.re_timestamp)
            self.assertRegexpMatches(r[3], self.re_timestamp + self.re_pid_pid)
            self.assertIn(r[2] + (r[3],), stat_data)
            matches_count += 1
        
        self.assertEqual(matches_count, self.entries_count)
        matches_count = 0

        for r in zf_btr._matches(tpaths, stat_data):
            self.assertRegexpMatches(r[0], self.re_timestamp)
            self.assertRegexpMatches(r[2], self.re_timestamp + self.re_pid_pid)
            self.assertIn(r[1] + (r[2],), stat_data)
            matches_count += 1

        self.assertEqual(matches_count, self.entries_count)

    def testCorrectData(self):
        rm_br = tresults.RtabmapBagTestResult(self.bag_filename,
                                    self.trajectory_files_dir,
                                    self.config_files_dir,
                                    self.stat_files_dir)

        self.assertEqual(len(rm_br._results), self.entries_count)
        for tr in rm_br._results:
            self.assertRegexpMatches(tr._full_config_path, self.re_timestamp)
            self.assertRegexpMatches(tr._full_config_path, tr._test_id)

#-------------------------------------------------------------------------
#  MAIN
#-------------------------------------------------------------------------

if __name__ == '__main__':
    unittest.main()
