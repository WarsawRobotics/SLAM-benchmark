#!/usr/bin/env python
# vim:fileencoding=utf-8


def warningStr(s):
    return '\x1b[5;33m' + s + '\x1b[0m'

def errorStr(s):
    return '\x1b[2;31m' + s + '\x1b[0m'

def infoStr(s):
    return '\x1b[2;32m' + s + '\x1b[0m'

def debugStr(s):
    return '\x1b[2;36m' + s + '\x1b[0m'

def criticalStr(s):
    return '\x1b[1;31m' + s + '\x1b[0m'
