# vim:fileencoding=utf-8

import sys

import rospy

def getNodeParam(key, node_name, def_val=None):
    try:
        if def_val is not None:
            value = rospy.get_param(key, def_val)
        else:
            if not rospy.has_param(key):
                rospy.logerr('\"%s\" doesn\'t have \"%s\" '
                             'parameter!', node_name, key)
                raw_input('------press any key to exit------')
                sys.exit()
            else:
                rospy.logdebug('Has param: %s!', key)
            value = rospy.get_param(key)
    except KeyError:
        rospy.logerr('Couldn\'t get \"%s\" parameter value!', key)
        raw_input('------press any key to exit------')
        sys.exit()
    rospy.logdebug('Successfully get param: %s, value: %s', key, str(value))
    return value