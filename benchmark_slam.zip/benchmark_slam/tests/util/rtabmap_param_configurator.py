# vim:fileencoding=utf-8

import copy
# for arange
import numpy as np

#-----------------------------------------------------------------------
#   CONSTANTS
#-----------------------------------------------------------------------


class Kinect2CameraParams(object):
    max_depth = 8
    max_reliable_depth = 4.5
    min_depth = 0.5


class KinectCameraParams(object):
    max_depth = 4.5
    max_reliable_depth = 4
    min_depth = 0.4


class ZEDCameraParams(object):
    max_depth = 20
    max_reliable_depth = 4
    min_depth = 0.7

#-----------------------------------------------------------------------
#   PARAMETERS SET CONFIGURATORS
#-----------------------------------------------------------------------


def getParamSet(camera):
    s = dict()
    # Using database in the memory instead of a file on the hard disk.
    s['DbSqlite3\InMemory'] = 'true'
    # Bytes is a length of descriptor in bytes. It can be equal 
    # 16, 32 or 64 bytes. For small environments use smallest available value.
    s['BRIEF\Bytes'] = 16
    # [[Grid/FromDepth=true] Maximum cloud's depth from sensor. 0=inf.]
    s['Grid\DepthMax'] = camera.max_reliable_depth
    # [[Grid/FromDepth=true] Minimum cloud's depth from sensor.]
    s['Grid\DepthMin'] = camera.min_depth
    # [Noise filtering minimum neighbors.]
    s['Grid\NoiseFilteringMinNeighbors'] = 5
    # [Noise filtering radius (0=disabled)
    s['Grid\NoiseFilteringRadius'] = 0.1
    # Maximum features extracted from the images (0 means not bounded, 
    # <0 means no extraction).
    s['Kp\MaxFeatures'] = 400
    # [0=SURF 1=SIFT 2=ORB 3=FAST/FREAK 4=FAST/BRIEF 5=GFTT/FREAK 6=GFTT/BRIEF
    # 7=BRISK 8=GFTT/ORB 9=FREAK.]
    s['Kp\DetectorStrategy'] = 8
    # filter extracted points by depth
    s['Kp\MaxDepth'] = camera.max_reliable_depth
    #  min kinect v1 depth
    s['Kp\MinDepth'] = camera.min_depth
    # kNNFlannNaive=0, kNNFlannKdTree=1, kNNFlannLSH=2, kNNBruteForce=3,
    # kNNBruteForceGPU=4
    s['Kp\NNStrategy'] = 3
    s['Mem\BadSignaturesIgnored'] = 'false'
    s['Mem\ImagePostDecimation'] = -2
    s['Mem\ImagePreDecimation'] = -2
    # Keep raw images in RAM
    s['Mem\ImageKept'] = 'true'
    # Short-term memory
    s['Mem\STMSize'] = 15
    # Keep not linked nodes in db (rehearsed nodes and deleted nodes).
    s['Mem\NotLinkedNodesKept'] = 'false'
    # convert data to 16-bit depth format
    # s['Mem\SaveDepth16Format'] = 'true'
    # 0=No filtering 1=Kalman filtering 2=Particle filtering
    # s['Odom\FilteringStrategy'] = 1
    s['Odom\ImageBufferSize'] = 1
    s['Odom\ImageDecimation'] = -2
    s['Odom\ResetCountdown'] = 4
    # 0=Frame-to-Map (F2M) 1=Frame-to-Frame
    s['Odom\Strategy'] = 0

    # Local bundle adjustment: 0=disabled, 1=g2o, 2=cvsba.
    s['OdomF2M\BundleAdjustment'] = 1
    # Maximum frames used for bundle adjustment (0=inf or all current frames
    # in the local map).
    # s['OdomF2M\BundleAdjustmentMaxFrames'] = 0

    # [Robust graph optimization using Vertigo (only work for g2o and GTSAM
    # optimization strategies). Not compatible with "RGBD\OptimizeMaxError" if
    # enabled.]
    s['Optimizer\Robust'] = 'true'
    s['RGBD\OptimizeMaxError'] = 0
    # [Graph optimization strategy: 0=TORO, 1=g2o and 2=GTSAM.]
    s['Optimizer\Strategy'] = 1

    s['RGBD\OptimizeFromGraphEnd'] = 'true'
    s['Rtabmap\DetectionRate'] = 2
    s['Rtabmap\ImageBufferSize'] = 1
    # Maximum time allowed for the detector (ms) (0 means infinity).
    # s['Rtabmap\TimeThr'] = 300
    s['Rtabmap\PublishStats'] = 'false'

    # [0=Vis, 1=Icp, 2=VisIcp]
    s['Reg\Strategy'] = 0

    # Optimization with bundle adjustment: 0=disabled, 1=g2o, 2=cvsba.
    s['Vis\BundleAdjustment'] = 1
    # [[Vis/CorType=0] Matching window size (pixels) around projected points
    # when a guess transform is provided to find correspondences. 0 means
    # disabled.]
    s['Vis\CorGuessWinSize'] = 20
    # [[Vis/CorType=0] NNDR: nearest neighbor distance ratio. Used for features
    # matching approach.]
    s['Vis\CorNNDR'] = 0.6
    # [[Vis/CorType=0] kNNFlannNaive=0, kNNFlannKdTree=1, kNNFlannLSH=2,
    # kNNBruteForce=3, kNNBruteForceGPU=4. Used for features matching
    # approach.]
    s['Vis\CorNNType'] = 3
    # [Correspondences computation approach: 0=Features Matching, 
    # 1=Optical Flow]
    s['Vis\CorType'] = 0
    # [Motion estimation approach: 0:3D->3D, 1:3D->2D (PnP), 2:2D->2D (Epipolar
    # Geometry)]
    s['Vis\EstimationType'] = 0
    # [0=SURF 1=SIFT 2=ORB 3=FAST/FREAK 4=FAST/BRIEF 5=GFTT/FREAK 6=GFTT/BRIEF
    # 7=BRISK 8=GFTT/ORB 9=FREAK.]
    s['Vis\FeatureType'] = 8
    # [[Vis/EstimationType = 0] Maximum distance (in meters) for feature
    # correspondences. Used by 3D->3D estimation approach.]
    s['Vis\InlierDistance'] = 0.07
    # [Max depth of the features (0 means no limit).]
    s['Vis\MaxDepth'] = camera.max_reliable_depth
    # [Min depth of the features (0 means no limit).]
    s['Vis\MinDepth'] = camera.min_depth
    s['Vis\MinInliers'] = 15
    return s


def getParamRangeSet():
    rs = dict()
    # [0=SURF 1=SIFT 2=ORB 3=FAST/FREAK 4=FAST/BRIEF 5=GFTT/FREAK 
    # 6=GFTT/BRIEF 7=BRISK 8=GFTT/ORB 9=FREAK.]
    rs['Kp\DetectorStrategy'] = (2, 10, 1)
    rs['Vis\FeatureType'] = (2, 10, 1)
    # [Correspondences computation approach: 0=Features Matching, 
    # 1=Optical Flow]
    rs['Vis\CorType'] = (0, 2, 1)
    # 0=Frame-to-Map (F2M) 1=Frame-to-Frame
    rs['Odom\Strategy'] = (0, 2, 1)

    rs['Vis\MinInliers'] = (5, 30, 5)
    # [Feature matching window size (pixels) around projected points
    # when a guess transform is provided to find correspondences. 0 means
    # disabled.]
    rs['Vis\CorGuessWinSize'] = (10, 75, 5)
    # [[Vis/CorType=0] NNDR: nearest neighbor distance ratio. Used for features
    # matching approach.]
    rs['Vis\CorNNDR'] = (0.1, 1.0, 0.2)
    # [Maximum distance (in meters) for feature correspondences. Used by 
    #  3D->3D estimation approach.]
    rs['Vis\InlierDistance'] = (0.02, 0.14, 0.01)

    # [Image decimation (>=1) of saved data in created signatures
    # (after features extraction). Decimation is done from the original image.
    # Negative decimation is done from RGB size instead of depth size (if depth
    # is smaller than RGB, it may be interpolated depending of the decimation
    # value).]
    rs['Mem\ImagePostDecimation'] = (-1, -5, -1)
    # [Image decimation (>=1) before features extraction.
    rs['Mem\ImagePreDecimation'] = (-1, -5, -1)

    # [Decimation of the images before registration. Negative decimation is 
    # done from RGB size instead of depth size (if depth is smaller than RGB,
    # it may be interpolated depending of the decimation value).]
    rs['Odom\ImageDecimation'] = (-1, -5, -1)
    return rs

#-----------------------------------------------------------------------
#   PARAMETERS SET BUILDER
#-----------------------------------------------------------------------


class ParamSetBuilder(object):
    """
      Class ParamSetBuilder is a tool for generating rtabmap parameters set
    """

    def __init__(self, base_set):
        self._base_set = base_set
        self._param_sets = list()

    def generate(self, param_range_set):
        """Generates a list of set of RtabMap configuration parameters.
        
        Based on provided base_set of parameters, we create one new entry for 
        each key value in param_range_set dictionary.

        Arguments:
            param_range_set {dict} -- Dictionary with keys (parameter names) 
            and values as tuples defining parameter value range to test.
        """
        self._param_range_set = param_range_set
        self._param_sets = list()
        self.testParamRangeValues(self._base_set)

    def generateCascade(self, param_range_set):
        """Generates a list of set of RtabMap configuration parameters.
        
        Build a cartesian product of some specified paramters and their 
        corresponding values with provided param_range_set parameters and their
        values.
        
        Arguments:
            param_range_set {dict} -- Dictionary with keys (parameter names) 
            and values as tuples defining parameter value range to test.
        """
        self._param_range_set = param_range_set
        self._param_sets = list()
        self._param_sets.append(self._base_set)
        self.testOdomStrategy(self._base_set)

    def testOdomStrategy(self, base_set):
        # print '---------- test OdomStrategy'
        # 0=Frame-to-Map (F2M) 1=Frame-to-Frame
        key = 'Odom\Strategy'
        test = copy.deepcopy(base_set)

        for v in [0, 1]:
            # print 'add: %s[%d]' % (key, v)
            test[key] = v
            self.testCorType(copy.deepcopy(test))

    def testCorType(self, base_set):
        # print '---------- test CorType'
        # [Correspondences computation approach: 0=Features Matching, 
        # 1=Optical Flow]
        key = 'Vis\CorType'
        test = copy.deepcopy(base_set)

        for v in [0, 1]:
            # print 'add: %s[%d]' % (key, v)
            test[key] = v
            self.testFeatureType(copy.deepcopy(test))

    def testFeatureType(self, base_set):
        # print '---------- test FeatureType'
        # [0=SURF 1=SIFT 2=ORB 3=FAST/FREAK 4=FAST/BRIEF 5=GFTT/FREAK 
        # 6=GFTT/BRIEF 7=BRISK 8=GFTT/ORB 9=FREAK.]
        key1 = 'Kp\DetectorStrategy'
        key2 = 'Vis\FeatureType'
        test = copy.deepcopy(base_set)

        for v in xrange(2, 10, 1):
            # print 'add: %s[%d]' % (key1, v)
            # print 'add: %s[%d]' % (key2, v)
            test[key1] = v
            test[key2] = v
            self.testNNStrategy(copy.deepcopy(test))

    def testNNStrategy(self, base_set):
        # print '---------- test NNStrategy'
        # kNNFlannNaive=0, kNNFlannKdTree=1, kNNFlannLSH=2, kNNBruteForce=3,
        # kNNBruteForceGPU=4
        key = 'Kp\NNStrategy'
        test = copy.deepcopy(base_set)

        for v in xrange(0, 4, 1):
            # print 'add: %s[%d]' % (key, v)
            test[key] = v
            self.testParamRangeValues(copy.deepcopy(test))

    def testParamRangeValues(self, base_set):
        """
        Create copy of base_set parameters, and for each entry in
        self._param_range_set create a new set with new key[val] and append 
        it to the the self._param_sets
        """
        if len(self._param_range_set) == 0:
            self._param_sets.append(copy.deepcopy(base_set))
        for k,(minv, maxv, step) in self._param_range_set.iteritems():
            test = copy.deepcopy(base_set)
            for v in np.arange(minv, maxv, step):
                test[k] = v
                # print 'add: %s[%.2f]' % (k, float(v))
                self._param_sets.append(copy.deepcopy(test))

    def getParamSets(self):
        return self._param_sets
