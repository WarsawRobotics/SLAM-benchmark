# vim:fileencoding=utf-8

import numpy


def align(model, data):
    """Align two trajectories using the method of Horn (closed-form).

    Input:
    model -- first trajectory (3xn)
    data -- second trajectory (3xn)

    Output:
    rot -- rotation matrix (3x3)
    trans -- translation vector (3x1)
    trans_error -- translational error per point (1xn)

    """
    numpy.set_printoptions(precision=3, suppress=True)
    model_zerocentered = model - model.mean(1)
    data_zerocentered = data - data.mean(1)

    W = numpy.zeros((3, 3))
    for column in range(model.shape[1]):
        W += numpy.outer(model_zerocentered[:, column], 
                          data_zerocentered[:, column])
    U, d, Vh = numpy.linalg.linalg.svd(W.transpose())
    S = numpy.matrix(numpy.identity(3))
    if(numpy.linalg.det(U) * numpy.linalg.det(Vh) < 0):
        S[2, 2] = -1
    rot = U*S*Vh
    trans = data.mean(1) - rot * model.mean(1)

    model_aligned = rot * model + trans
    alignment_error = model_aligned - data

    trans_error = numpy.sqrt(numpy.sum(numpy.multiply(
        alignment_error, alignment_error), 0)).A[0]

    return rot, trans, trans_error


def associate(first_list, second_list, offset, max_difference):
    """
    Associate two dictionaries of (stamp,data). As the time stamps never 
    match exactly, we aim to find the closest match for every input tuple.

    Input:
    first_list -- first dictionary of (stamp,data) tuples
    second_list -- second dictionary of (stamp,data) tuples
    offset -- time offset between both dictionaries (e.g., to model the 
              delay between the sensors)
    max_difference -- search radius for candidate generation (in seconds)

    Output:
    matches -- list of matched tuples ((stamp1,data1),(stamp2,data2))
    """
    first_keys = first_list.keys()
    second_keys = second_list.keys()
    potential_matches = [(abs(a - (b + offset)), a, b)
                         for a in first_keys
                         for b in second_keys
                         if abs(a - (b + offset)) < max_difference]
    potential_matches.sort()
    matches = []
    for diff, a, b in potential_matches:
        if a in first_keys and b in second_keys:
            first_keys.remove(a)
            second_keys.remove(b)
            matches.append((a, b))

    matches.sort()
    return matches


def uniqueKeys(data):
    """Extract all unique keys from dictionaries of parameters.
    
    Arguments:
        data {list} -- List of dictionaries

    Output:
        List of all uniqe keys across all entries in input data.
    """
    d = dict()
    for k in data:
        d.update(k)
    return d.keys()


def uniqueKeyValues(data, key):
    """Extract unique values for specified `key`
    
    Assume that input data are in format described in `JSONStatParser`

    Arguments:
        data {list} -- List of tuples (config=dict(),stat=dict())
        key {str} -- A string key, we gather values for

    Output:
        List of all uniqe key values.
    """
    res = list()
    for t in data:
        if t[0].has_key(key):
            val = t[0][key]
            n = len(res)
            for i in range(0,n-1):
                if res[i] < val and res[i+1] > val:
                    res.insert(i+1,val)
                    break
            if len(res) > 0 and res[n-1] < val:
                res.append(val)
            elif len(res) == 0:
                res.append(val)
    return res


def uniqueValues(data):
    """Constructs a sorted (ascending) list of unique values from input data.
    
    Arguments:
        data {iterable object} -- Container with comparable objects.
    
    Returns:
        [list] -- List with object sorted in ascending order.
    """
    res = list()
    for val in data:
        n = len(res)
        for i in range(0,n):
            if res[i] > val:
                if i > 0 and res[i-1] < val or i == 0:
                    res.insert(i, val)
                    break
        if len(res) > 0 and res[n-1] < val:
            res.append(val)
        elif len(res) == 0:
            res.append(val)
    return res   


def val2numeric(v):
    if isinstance(v, bool):
        if v:
            return 1
        else:
            return 0
    if isinstance(v, (str, unicode)):
        if v == 'True' or v == 'true':
            return 1
        elif v == 'False' or v == 'false':
            return 0
        else:
            raise ValueError('Unrecognized value!')
    return v
