# vim:fileencoding=utf-8

import numpy as np
import json

from tests.util.utilities import associate
from tests.util.colored_str import *


class BaseStatistics(object):

    metrics = [
        u'max',
        u'min',
        u'mean',
        u'median',
        u'stddev',
    ]

    def __init__(self, data):
        """Calculate metrics within each column

        Arguments:
            data {numpy.array} -- N dimensional array, where least changing 
            dimension (i.e. Z for 3D) corresponds to separate data samples, 
            and most frequently changing dimension (i.e.: X for 3D) corresponds 
            to individual features.
        """
        # compute metrics along multiple samples, for separate metrics and
        # features
        if len(data) > 0:
            self.min = np.min(data, axis=0)
            self.max = np.max(data, axis=0)
            self.mean = np.mean(data, axis=0)
            self.median = np.median(data, axis=0)
            self.stddev = np.std(data, axis=0)
        else:
            self.min = []
            self.max = []
            self.mean = []
            self.median = []
            self.stddev = []

class TrajectoryErrorStatistics(BaseStatistics):
    """
        Computes basic statistics from given data.
    """

    def __init__(self, est, gndt, offset=0.0, max_diff=0.4):
        """
            Input data are of the following form:
            est: {timestamp:[x,y,z,qx,qy,qz,qw],...},
            gndt: {timestamp:[x,y,z,qx,qy,qz,qw,[vel]],...},
            where:
            timestamp - ROS timestamp
            (x,y,z) - absolute 3D pose
            (qx,qy,qz,qw) - quaternion for 3D rotation
            vel - current velocity [m/s] (optional)
        """
        err = np.empty(0)
        matches = associate(gndt, est, offset, max_diff)
        if len(matches) > 0:
            ar_gndt = np.array([gndt[a] for a, b in matches])
            ar_est = np.array([est[b] for a, b in matches])
            err = abs(ar_gndt[:, 0:7] - ar_est)
        else:
            print(warningStr('No corresponding entries between estimated ' +
                             'and ground truth trajectories found!'))

        # FIXME: w tej chwili wartości dla błędu rotacji (qx,qy,qz,qw)
        # będą prawdopodobnie bezezesesesesensu...
        super(TrajectoryErrorStatistics, self).__init__(err)


class TrajectoryErrStatJSONEncoder(json.JSONEncoder):
    """Class for serialization of TrajectoryErrorStatistics objects
    """

    def default(self, obj):
        if isinstance(obj, TrajectoryErrorStatistics):
            stats = dict()
            stats['min'] = list(obj.min)
            stats['max'] = list(obj.max)
            stats['mean'] = list(obj.mean)
            stats['median'] = list(obj.median)
            stats['stddev'] = list(obj.stddev)
            return stats
        # Let the base class default method raise the TypeError
        else:
            return json.JSONEncoder.default(self, obj)


def statDict2NumpyArray(data):
    """Extract and convert statistics data to numpy array.

    Assume that input data are in format described in `JSONStatParser`

    Arguments:
        data {list} -- List of tuples (config=dict(),stat=dict())

    Output:
        Numpy Array with first dimension equal to number of samples,
        second dimension equal to number of specifed metrics (min, max, mean,
        median, stddev), and third dimension equal to specifed features for 
        each metric (x,y,z,qx,qy,qz,qw)
    """
    l = list()
    for k in data:
        l.append([k[1][m] for m in BaseStatistics.metrics])
    return np.array(l)
