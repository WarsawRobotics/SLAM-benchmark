# vim:fileencoding=utf-8

import os
import sys
import errno
import json

class JsonLogger(object):
    """
        Simple class for loading and storing data in JSON format in log file.
    """
    def __init__(self, filepath):
        if os.path.exists(filepath):
            self._logfile = open(filepath, 'r+')
        else:
            print('Specified log file doesn\'t exist! path: ' + filepath +
                  ' Exiting!')
            sys.exit()

        self._data = dict()

    def addTestEntry(self, key, config, stats):
        if self._data.has_key(key):
            print 'ERROR: There is already key: ' + str(key) + ' in data!'
            raise ValueError('Logging dupplicate key!')
        self._data[key] = (config, stats)

    def addTestStats(self, key, stats):
        if not self._data.has_key(key):
            print 'ERROR: There is no key: ' + str(key) + ' in data!'
            raise ValueError('Logging data for not existing key!')
        else:
            self._data[key][1] = stats

    def load(self):
        self._data = json.load(self._logfile)

    def store(self):
        # FIXME: this is ugly! We constatly read whole file, clean it, and
        # write whole file again, innecessary repeating many writes!
        # This can be dangerous! If sth goes wrong in beetween truncating and
        # dumping, then we will lose whole file!
        self._logfile.seek(0)
        self._logfile.truncate()
        json.dump(self._data, self._logfile, indent=2, separators=(',', ': '),
                  sort_keys=True)
        self._logfile.flush()

    def __enter__(self):
        self.load()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.store()
        self._logfile.close()