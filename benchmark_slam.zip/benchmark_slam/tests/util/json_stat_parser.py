#!/usr/bin/env python
# vim:fileencoding=utf-8

import os
import sys
import json
import re

from tests.util.colored_str import warningStr

class JSONStatParser(object):
    """Class used to aggregate data from mulitple json *.log files.

    We can pass to it directory, within which it will aggregate data from 
    files having common suffix (bagname). It stores a list of aggregated 
    data, where each entry corresponds to single test configuration.

    There is a following file naming convetion assumed: 
        `bag_file_name_pid[_subproc_pid]_cfg_stat.log` 
    pid - process id, consists only from digits {4-5 digits??}.

    re_pid_pid {str} -- Regular expression used match file identificators.
    """
    re_pid_pid = '_\d+(_\d+)?'

    @classmethod
    def parseBagData(cls, dir_path, bag_filename):
        """Parse data available inside given directory and group them by name.

        Arguments:
            dir_path {str} -- A path to directory, where to find log files.

        Output have a following structure:
        [
            (cfg=dict(),stat=dict(), test_id),
            (cfg=dict(),stat=dict(), test_id),
            (...),
        ],
        where test_id is: 'timestamp_pid[_pid]'

        Returns:
            list -- A list of data corresponding to test carried out on 
            `bag_filename` bag.
        """
        stat_files = [f for f in os.listdir(dir_path) if
                      os.path.isfile(os.path.join(dir_path, f)) and
                      re.match(bag_filename + cls.re_pid_pid + 
                               '_cfg_stat.log', f)
                      is not None]
        return cls._aggregate(stat_files, dir_path)

    @classmethod
    def _aggregate(cls, stat_files, dir_path):
        bag_data = list()
        for filename in stat_files:
            with open(os.path.join(dir_path, filename), 'r') as f:
                new_data = json.load(f)
                test_id = re.search(cls.re_pid_pid, filename).group()
                cls._updateBagData(bag_data, new_data, test_id)
        return bag_data

    @classmethod
    def _updateBagData(cls, bd, new_data, test_id):
        """Append all data to the bag's list.
        
        Arguments:
            bd {list} -- A list for this data's bag
            new_data {dict} -- A dictionary containing pairs timestamp:data
        """
        for k in new_data.keys():
            # consider only entries with some computed statistics
            if len(new_data[k][1]) > 0:
                tid = str(k) + test_id
                new_data[k].append(tid)
                bd.append(tuple(new_data[k]))
            else:
                print(warningStr('No statistics within test entry!'))
