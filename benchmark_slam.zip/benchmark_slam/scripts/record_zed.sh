#!/usr/bin/env bash

zed_namespace='zed'
zed_camera_rgb_topic=/${zed_namespace}/rgb/image_rect_color
zed_camera_depth_topic=/${zed_namespace}/depth/depth_registered
zed_camera_cam_info_topic=/${zed_namespace}/rgb/camera_info
zed_camera_odom_topic=/${zed_namespace}/odom

if [ "$#" -ne 1 ]; then
  echo "usage: 'record_zed bagname'"
fi

# -n -- check whether parameter is not a null string
if [ -n $1 ]; then
  bagname=$1
fi

WORKSPACE=${HOME}/invenco/playground/zed_ws
BAG_DIR=src/benchmark_slam/data/bags

rosbag record -O ${WORKSPACE}/${BAG_DIR}/${bagname} -j ${zed_camera_rgb_topic} \
                                          ${zed_camera_cam_info_topic} \
                                          ${zed_camera_depth_topic} \
                                          ${zed_camera_odom_topic} \
                                          /${zed_namespace}/zed_wrapper_node/parameter_descriptions \
                                          /${zed_namespace}/zed_wrapper_node/parameter_updates \
                                          /${zed_namespace}/joint_states \
                                          /tf /tf_static

