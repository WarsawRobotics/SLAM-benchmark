#!/usr/bin/env python
# vim:fileencoding=utf-8
# Software License Agreement (BSD License)
#
# Copyright (c) 2013, Juergen Sturm, TUM
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above
#    copyright notice, this list of conditions and the following
#    disclaimer in the documentation and/or other materials provided
#    with the distribution.
#  * Neither the name of TUM nor the names of its
#    contributors may be used to endorse or promote products derived
#    from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
#
# Copyright (c) 2017, Adam Rogowiec, Invenco
# All rights reserved.
# Modified original files for use in private project.

"""
This script computes the absolute trajectory error from the ground truth
trajectory and the estimated trajectory.
"""

import numpy
import associate

class ATEMetric(object):
  def __init__(self, er_rmse, er_mean, er_median, er_std, er_min, er_max):
    super(ATEMetric, self).__init__()
    self.ate_rmse   = er_rmse
    self.ate_mean   = er_mean
    self.ate_median = er_median
    self.ate_std    = er_std
    self.ate_min    = er_min
    self.ate_max    = er_max

def align(model,data):
  """Align two trajectories using the method of Horn (closed-form).
  
  Input:
  model -- first trajectory (3xn)
  data -- second trajectory (3xn)
  
  Output:
  rot -- rotation matrix (3x3)
  trans -- translation vector (3x1)
  trans_error -- translational error per point (1xn)
  
  """
  numpy.set_printoptions(precision=3,suppress=True)
  model_zerocentered = model - model.mean(1)
  data_zerocentered = data - data.mean(1)
  
  W = numpy.zeros( (3,3) )
  for column in range(model.shape[1]):
    W += numpy.outer(model_zerocentered[:,column],data_zerocentered[:,column])
  U,d,Vh = numpy.linalg.linalg.svd(W.transpose())
  S = numpy.matrix(numpy.identity( 3 ))
  if(numpy.linalg.det(U) * numpy.linalg.det(Vh)<0):
    S[2,2] = -1
  rot = U*S*Vh
  trans = data.mean(1) - rot * model.mean(1)
  
  model_aligned = rot * model + trans
  alignment_error = model_aligned - data
  
  trans_error = numpy.sqrt(numpy.sum(numpy.multiply(alignment_error,alignment_error),0)).A[0]
      
  return rot,trans,trans_error

def plot_traj(ax,stamps,traj,style,color,label):
  """
  Plot a trajectory using matplotlib. 
  
  Input:
  ax -- the plot
  stamps -- time stamps (1xn)
  traj -- trajectory (3xn)
  style -- line style
  color -- line color
  label -- plot legend
  
  """
  stamps.sort()
  interval = numpy.median([s-t for s,t in zip(stamps[1:],stamps[:-1])])
  x = []
  y = []
  last = stamps[0]
  for i in range(len(stamps)):
    if stamps[i]-last < 2*interval:
      x.append(traj[i][0])
      y.append(traj[i][1])
    elif len(x)>0:
      ax.plot(x,y,style,color=color,label=label)
      label=""
      x=[]
      y=[]
    last= stamps[i]
  if len(x)>0:
    ax.plot(x,y,style,color=color,label=label)

def evaluateATE(gnd_truth, est_pose, offset=0.0, scale=1.0, max_diff=0.02,
        plot_file='ate_err.png'):
  
  matches = associate.associate(gnd_truth, est_pose, float(offset), 
        float(max_diff))    
  if len(matches) < 2:
      raise Exception("Couldn't find matching timestamp pairs between groundtruth and"
          " estimated trajectory!")

  first_xyz = numpy.matrix([[float(value) for value in gnd_truth[a][0:3]] for a,b in matches]).transpose()
  second_xyz = numpy.matrix([[float(value)*float(scale) for value in est_pose[b][0:3]] for a,b in matches]).transpose()
  rot,trans,trans_error = align(second_xyz,first_xyz)
  
  second_xyz_aligned = rot * second_xyz + trans
  
  first_stamps = gnd_truth.keys()
  first_stamps.sort()
  first_xyz_full = numpy.matrix([[float(value) for value in gnd_truth[b][0:3]] for b in first_stamps]).transpose()
  
  second_stamps = est_pose.keys()
  second_stamps.sort()
  second_xyz_full = numpy.matrix([[float(value)*float(scale) for value in est_pose[b][0:3]] for b in second_stamps]).transpose()
  second_xyz_full_aligned = rot * second_xyz_full + trans
  
  ate_rmse = numpy.sqrt(numpy.dot(trans_error,trans_error) / len(trans_error))
  ate_mean = numpy.mean(trans_error)
  ate_median = numpy.median(trans_error)
  ate_std = numpy.std(trans_error)
  ate_min = numpy.min(trans_error)
  ate_max = numpy.max(trans_error)

  ate_metric = ATEMetric(ate_rmse, ate_mean, ate_median, ate_std, ate_min, ate_max)
      
  if len(plot_file) > 0:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.pylab as pylab
    from matplotlib.patches import Ellipse
    
    fig = plt.figure()
    ax = fig.add_subplot(111)
    plot_traj(ax, first_stamps, first_xyz_full.transpose().A, '-', "black",
        "ground truth")
    plot_traj(ax, second_stamps, second_xyz_full_aligned.transpose().A, '-', 
      "blue", "estimated")

    # label="difference"
    # for (a,b),(x1,y1,z1),(x2,y2,z2) in zip(matches,first_xyz.transpose().A,second_xyz_aligned.transpose().A):
    #     ax.plot([x1,x2],[y1,y2],'-',color="red",label=label)
    #     label=""
        
    ax.legend()
    ax.set_xlabel('x [m]')
    ax.set_ylabel('y [m]')
    plt.savefig(plot_file, dpi=90)

  return ate_metric