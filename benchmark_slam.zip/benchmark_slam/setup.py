from distutils.core import setup
from catkin_pkg.python_setup import generate_distutils_setup

# package_dir['': 'directory'] - changes convention for where to search for 
# packages listed in `packages=[]`. The `''` - stands for 'root dir', which 
# default location is at the level of this (setup.py) file.
# The below configuration tells that, there is a `tests` package at the `global`
# (root_dir) level, and there is a `err_metrics` package at 
# `'root_dir'/scritps/err_metrics`. Inside each package directory there must be
#  `__init__.py` file.
setup(**generate_distutils_setup(
    packages=['err_metrics','tests'],
    package_dir={'err_metrics': 'scripts/err_metrics',}
))
